/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

/*!40000 DROP DATABASE IF EXISTS `ciaecl_ciae`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ciaecl_ciae` /*!40100 DEFAULT CHARACTER SET latin1 COLLATE latin1_general_ci */;

USE `ciaecl_ciae`;
DROP TABLE IF EXISTS `auth_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `opcion` varchar(500) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `tipo_menu` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `link` varchar(255) COLLATE latin1_general_ci DEFAULT ' ',
  `tipo_archivo` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `sitio` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `archivo` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `publicar` int(10) unsigned NOT NULL,
  `menu_padre` int(11) NOT NULL DEFAULT '0',
  `orden` int(11) NOT NULL DEFAULT '0',
  `acceso` varchar(10) COLLATE latin1_general_ci NOT NULL DEFAULT 'publico' COMMENT 'privado o publico',
  `tipo` varchar(15) COLLATE latin1_general_ci NOT NULL DEFAULT 'principal' COMMENT 'principal o secundario',
  `titulo_es` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `titulo_en` varchar(255) COLLATE latin1_general_ci DEFAULT ' ',
  `contenido_es` text COLLATE latin1_general_ci,
  `contenido_en` text COLLATE latin1_general_ci,
  `idioma` varchar(10) COLLATE latin1_general_ci NOT NULL DEFAULT 'nn',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1345 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `auth_menu_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_menu_access` (
  `id` int(11) NOT NULL,
  `permiso` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '0' COMMENT 'si es 0, significa que todos tienen acceso',
  PRIMARY KEY (`id`,`permiso`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `auth_menu_lang`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_menu_lang` (
  `id_menu` int(11) NOT NULL,
  `idioma` varchar(3) NOT NULL,
  `nombre` varchar(150) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `titulo` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `texto` text CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_menu`,`idioma`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `auth_rol`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_rol` (
  `id_permiso` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `descripcion` text COLLATE latin1_general_ci NOT NULL,
  `alias` varchar(100) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_permiso`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `auth_rol_permisos_particulares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_rol_permisos_particulares` (
  `permiso` varchar(255) NOT NULL,
  `modulo` varchar(255) NOT NULL,
  `permiso_especifico` varchar(255) NOT NULL,
  PRIMARY KEY (`permiso`,`modulo`,`permiso_especifico`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `auth_user_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_info` (
  `id_persona` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `nombre` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `apellido_paterno` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `apellido_materno` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(255) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_persona`)
) ENGINE=MyISAM AUTO_INCREMENT=497 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `auth_user_md5`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_md5` (
  `user_id` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `username` varchar(200) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `password` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `perms` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `permisos_extras` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `activo` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`user_id`,`username`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `auth_user_md5_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_md5_site` (
  `user_id` varchar(200) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `id_site` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`id_site`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `common_comuna`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `common_comuna` (
  `comuna_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `region_id` int(10) unsigned NOT NULL,
  `comuna` varchar(255) NOT NULL,
  `orden` int(11) DEFAULT '10',
  PRIMARY KEY (`comuna_id`)
) ENGINE=MyISAM AUTO_INCREMENT=13606 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `common_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `common_logs` (
  `time_log` int(11) NOT NULL,
  `ip` varchar(100) NOT NULL,
  `ip_extra` varchar(100) NOT NULL,
  `sitio` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `action` varchar(255) NOT NULL,
  `msg` text NOT NULL,
  `post` text NOT NULL,
  PRIMARY KEY (`time_log`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `common_logs_download`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `common_logs_download` (
  `id_visit` int(11) NOT NULL AUTO_INCREMENT,
  `sitio` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `fecha` int(11) NOT NULL,
  `ip_address` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `ip_address_extra` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `documento` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `estado` varchar(150) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_visit`)
) ENGINE=MyISAM AUTO_INCREMENT=1995087 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `common_logs_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `common_logs_history` (
  `fecha` int(10) unsigned NOT NULL,
  `alerta` int(11) NOT NULL DEFAULT '0',
  `total` int(10) unsigned NOT NULL,
  PRIMARY KEY (`fecha`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `common_logs_imagen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `common_logs_imagen` (
  `id_visita` int(11) NOT NULL AUTO_INCREMENT,
  `sitio` varchar(200) COLLATE latin1_general_ci DEFAULT NULL,
  `fecha` int(11) DEFAULT NULL,
  `tipo_visita` varchar(550) COLLATE latin1_general_ci NOT NULL DEFAULT 'local',
  `email` varchar(300) COLLATE latin1_general_ci DEFAULT NULL,
  `caso_envio` varchar(300) COLLATE latin1_general_ci DEFAULT NULL,
  `ip_address` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `url` varchar(500) COLLATE latin1_general_ci DEFAULT NULL,
  `fecha_completa` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_visita`)
) ENGINE=MyISAM AUTO_INCREMENT=2886081 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `common_logs_ip_block`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `common_logs_ip_block` (
  `ip` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `bloqueado` varchar(20) COLLATE latin1_general_ci NOT NULL DEFAULT 'no',
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sitio` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `url` varchar(350) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`ip`),
  KEY `fecha` (`fecha`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `common_logs_url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `common_logs_url` (
  `id_visit` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `uri` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `browser` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `fecha` int(11) NOT NULL,
  `username` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `ip_address` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `ip_address_extra` varchar(100) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_visit`)
) ENGINE=MyISAM AUTO_INCREMENT=30570161 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `common_paises`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `common_paises` (
  `pais_id` int(11) NOT NULL AUTO_INCREMENT,
  `pais` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `orden` int(11) NOT NULL,
  PRIMARY KEY (`pais_id`)
) ENGINE=MyISAM AUTO_INCREMENT=1001 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `common_region`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `common_region` (
  `region_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `region` varchar(255) NOT NULL,
  `orden` int(11) NOT NULL,
  PRIMARY KEY (`region_id`)
) ENGINE=MyISAM AUTO_INCREMENT=101 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_actos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_actos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `denominacion` longtext COLLATE utf8_unicode_ci NOT NULL,
  `nombre_titulo` longtext COLLATE utf8_unicode_ci NOT NULL,
  `tipo_norma` longtext COLLATE utf8_unicode_ci NOT NULL,
  `numero` longtext COLLATE utf8_unicode_ci NOT NULL,
  `fecha` longtext COLLATE utf8_unicode_ci NOT NULL,
  `fecha_medio_publicacion` longtext COLLATE utf8_unicode_ci NOT NULL,
  `efecto_general` longtext COLLATE utf8_unicode_ci NOT NULL,
  `fecha_ultima_actualizacion` longtext COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` longtext COLLATE utf8_unicode_ci NOT NULL,
  `enlace` longtext COLLATE utf8_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_areas` (
  `id_area` int(11) NOT NULL AUTO_INCREMENT,
  `area_es` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `area_en` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `clave` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `orden` int(11) NOT NULL,
  `activo` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_area`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_banner`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_banner` (
  `id_banner` int(11) NOT NULL AUTO_INCREMENT,
  `imagen` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `titulo` varchar(500) COLLATE latin1_general_ci NOT NULL,
  `bajada` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `orden` int(11) NOT NULL,
  `link` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `activo` int(11) NOT NULL DEFAULT '1',
  `idioma` varchar(2) COLLATE latin1_general_ci NOT NULL DEFAULT 'es' COMMENT 'nn neutro',
  `tipo` varchar(20) COLLATE latin1_general_ci NOT NULL COMMENT 'principal / pie',
  `id_site` int(4) NOT NULL,
  `fecha_caducidad` date NOT NULL,
  PRIMARY KEY (`id_banner`)
) ENGINE=MyISAM AUTO_INCREMENT=288 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_boletin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_boletin` (
  `id_boletin` int(11) NOT NULL AUTO_INCREMENT,
  `agno` int(11) NOT NULL,
  `mes` int(11) NOT NULL,
  `archivo` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `id_site` int(11) NOT NULL,
  PRIMARY KEY (`id_boletin`,`id_site`)
) ENGINE=MyISAM AUTO_INCREMENT=102 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_boletin_especiales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_boletin_especiales` (
  `id_boletin` int(11) NOT NULL AUTO_INCREMENT,
  `agno` int(11) NOT NULL,
  `mes` int(11) NOT NULL,
  `titulo` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `id_noticia` int(11) NOT NULL,
  `id_site` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_boletin`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_boletin_foco`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_boletin_foco` (
  `id_boletin` int(11) NOT NULL AUTO_INCREMENT,
  `agno` int(11) NOT NULL,
  `mes` int(11) NOT NULL,
  `archivo` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `titulo` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `id_noticia` int(11) NOT NULL,
  PRIMARY KEY (`id_boletin`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_certificado_detalle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_certificado_detalle` (
  `id_certificado` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `nombre` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `apellidos` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `rut` int(10) NOT NULL,
  `rut_dv` varchar(2) COLLATE latin1_general_ci NOT NULL,
  `texto_extra` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_certificado`,`email`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_compras_adquisiciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_compras_adquisiciones` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `concepto` text COLLATE latin1_general_ci,
  `cantidad` text COLLATE latin1_general_ci,
  `valor` text COLLATE latin1_general_ci,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_compras_adquisiciones_menores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_compras_adquisiciones_menores` (
  `id_compra` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `concepto_tipo_gasto` longtext COLLATE utf8_unicode_ci NOT NULL,
  `cantidad` longtext COLLATE utf8_unicode_ci NOT NULL,
  `valor` longtext COLLATE utf8_unicode_ci NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_compra`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_contacto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_contacto` (
  `id_contacto` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(150) COLLATE latin1_general_ci NOT NULL DEFAULT 'contacto',
  `fecha` int(11) NOT NULL,
  `nombre` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `mensaje` text COLLATE latin1_general_ci NOT NULL,
  `respuesta_fecha` int(11) NOT NULL,
  `respuesta` text COLLATE latin1_general_ci NOT NULL,
  `respuesta_username` varchar(150) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_contacto`)
) ENGINE=MyISAM AUTO_INCREMENT=6946 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_email_webmaster_envio`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_email_webmaster_envio` (
  `fecha` date NOT NULL,
  `email` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `orden` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  PRIMARY KEY (`fecha`,`email`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_eventos_informe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_eventos_informe` (
  `id_evento` int(11) NOT NULL AUTO_INCREMENT,
  `id_noticia` int(11) NOT NULL,
  `id_inscripcion` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_termino` date NOT NULL,
  `info_completa` varchar(2) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'no',
  `nombre` text CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `tipo_evento` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `total_inscritos_presencial` int(11) NOT NULL DEFAULT '0',
  `total_inscritos_online` int(11) NOT NULL DEFAULT '0',
  `total_asistencia` int(11) NOT NULL DEFAULT '0',
  `institucion_co_organizadora` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `link_inscripcion` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'http://www.ciae.uchile.cl/index.php?langSite=es&page=view_inscripcion_',
  `inscripcion_opcion_menu` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'view_inscripcion_',
  `inscripcion_fecha_cierre` date NOT NULL,
  `inscripcion_cupos_maximo` int(11) NOT NULL,
  `email` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'contacto@ciae.uchile.cl',
  `ubicacion` varchar(500) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'Centro de Investigación Avanzada en Educación, Universidad de Chile. Calle Periodista José Carrasco Tapia 75, Santiago',
  `ubicacion_email` text CHARACTER SET latin1 COLLATE latin1_general_ci,
  `ubicacion_email_online` text CHARACTER SET latin1 COLLATE latin1_general_ci,
  `date_texto` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `date_texto_email` varchar(500) CHARACTER SET latin1 COLLATE latin1_general_ci DEFAULT NULL,
  `programa` text CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `costo_texto_extras` text CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `listas` text CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `logos` text CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `tipo_formulario_confirmacion` varchar(255) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL DEFAULT 'simple',
  `mensaje_extra_notificacion` text NOT NULL,
  `link_online` varchar(255) NOT NULL,
  `certificado_encabezado_fech` varchar(250) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `certificado_fec` varchar(250) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `certificado_horas` varchar(250) NOT NULL,
  `certificado_ubicacion` varchar(250) NOT NULL,
  `certificado_organizadores` varchar(550) NOT NULL DEFAULT 'Centro de Investigación Avanzada en Educación, Universidad de Chile',
  PRIMARY KEY (`id_evento`)
) ENGINE=MyISAM AUTO_INCREMENT=376 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_fecha_actualizacion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_fecha_actualizacion` (
  `fecha` date NOT NULL,
  `id_site` int(11) NOT NULL,
  PRIMARY KEY (`fecha`,`id_site`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_gestion_actas_ie`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_gestion_actas_ie` (
  `id_acta` int(11) NOT NULL,
  `agno` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `tipo` varchar(50) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_acta`,`agno`,`tipo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_gestion_honorarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_gestion_honorarios` (
  `id_honorario` int(11) NOT NULL AUTO_INCREMENT,
  `id_persona` int(11) NOT NULL,
  `numero_convenio` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `numero_decreto` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `numero_memo` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `fecha_creacion` datetime NOT NULL,
  `fecha_termino` date NOT NULL,
  `id_centro_costo` int(11) NOT NULL,
  `centro_costo` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `proyecto` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `id_investigador_responsable` int(11) NOT NULL,
  `id_investigador_supervidor` int(11) NOT NULL,
  `monto_comprometido` int(11) NOT NULL,
  `numero_cuotas` int(11) NOT NULL,
  `fecha_desde` date NOT NULL,
  `fecha_hasta` date NOT NULL,
  `fecha_convenio` date NOT NULL,
  `fecha_firma` date NOT NULL,
  `fecha_compromiso` date NOT NULL,
  `fecha_aprobacion` date NOT NULL,
  `id_tipo_estados_honorarios` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `id_tipo_honorarios_calidad` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `horas_jornada` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `comentario_horas_jornada` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `labor` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `labor_resumida` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `proyecto_corto` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `observacion` text COLLATE latin1_general_ci NOT NULL,
  `envio_correo_general` int(11) NOT NULL,
  PRIMARY KEY (`id_honorario`)
) ENGINE=MyISAM AUTO_INCREMENT=157 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_gestion_honorarios_cuotas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_gestion_honorarios_cuotas` (
  `id_honorario` int(11) NOT NULL,
  `numero_cuota` int(11) NOT NULL,
  `numero_agno` int(11) NOT NULL,
  `numero_mes` int(11) NOT NULL,
  `monto_cuota` int(11) NOT NULL,
  `estado` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT 'pendiente',
  `tipo` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT 'mensual',
  `fecha_pago` date NOT NULL,
  `boleta_enviada` int(11) NOT NULL DEFAULT '0',
  `informe_enviado` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_honorario`,`numero_agno`,`numero_mes`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_gestion_inventario_libros_libros`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_gestion_inventario_libros_libros` (
  `id_libro` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `id_uchile` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `estado` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT 'activo',
  `numero_copias` int(2) NOT NULL DEFAULT '1',
  `autores` text COLLATE latin1_general_ci NOT NULL,
  `titulo` text COLLATE latin1_general_ci NOT NULL,
  `editorial` text COLLATE latin1_general_ci NOT NULL,
  `fecha_ingreso_base` date NOT NULL,
  `agno_publicacion` int(11) NOT NULL,
  `isbn` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `doi` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `tipo_libro` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT 'libro',
  `proyecto` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `centro_costo` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `investigador_acargo` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `palabra_clave` text COLLATE latin1_general_ci NOT NULL,
  `precio_unitario` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `precio_iva` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `precio_total` varchar(20) COLLATE latin1_general_ci NOT NULL,
  `proveedor` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `orden_compra` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `factura` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `fecha_factura` date NOT NULL,
  `comentarios` text COLLATE latin1_general_ci NOT NULL,
  `fecha_actualizacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_libro`),
  KEY `estado` (`estado`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_gestion_inventario_libros_prestamos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_gestion_inventario_libros_prestamos` (
  `id_prestamo` int(11) NOT NULL AUTO_INCREMENT,
  `numero_memo` int(11) NOT NULL,
  `fecha_prestamo` date NOT NULL,
  `fecha_solicitud` date NOT NULL,
  `fecha_devolucion_estimada` date NOT NULL,
  `fecha_devolucion` date NOT NULL,
  `estado` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT 'solicitud',
  `id_usuario_solicitante` int(11) NOT NULL,
  `id_usuario_gestiona` int(11) NOT NULL,
  `archivo_prestamo_firmado` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `archivo_devolucion_firmado` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `comentario` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_prestamo`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_gestion_inventario_libros_prestamos_detalle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_gestion_inventario_libros_prestamos_detalle` (
  `id_prestamo` int(11) NOT NULL,
  `id_libro` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fecha_devolucion_estimada` date NOT NULL,
  `fecha_devolucion` date NOT NULL,
  `estado` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT 'solicitud',
  PRIMARY KEY (`id_prestamo`,`id_libro`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_gestion_resoluciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_gestion_resoluciones` (
  `id_resolucion` int(10) NOT NULL,
  `agno` int(4) NOT NULL,
  `fecha_resolucion` date DEFAULT NULL,
  `fecha_aprobacion` date DEFAULT NULL,
  `denominacion` text COLLATE latin1_general_ci NOT NULL,
  `detalle` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_resolucion`,`agno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_gestion_solicitudes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_gestion_solicitudes` (
  `id_solicitud` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_solicitud` datetime NOT NULL,
  `id_persona_solicitante` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `id_persona_beneficiario` int(11) NOT NULL,
  `observacion` text COLLATE latin1_general_ci NOT NULL,
  `id_tipo_solicitudes` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `id_solicitud_estado` varchar(100) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_solicitud`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_gestion_solicitudes_estados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_gestion_solicitudes_estados` (
  `id_solicitud` int(11) NOT NULL,
  `id_solicitud_estado` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fecha` datetime NOT NULL,
  `fecha_cierre` datetime NOT NULL,
  `user_id_responsable` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `comentarios` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_solicitud`,`id_solicitud_estado`,`fecha`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_gestion_solicitudes_estados_archivos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_gestion_solicitudes_estados_archivos` (
  `id_solicitud` int(11) NOT NULL,
  `id_solicitud_estado` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fecha` datetime NOT NULL,
  `archivo` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `nombre` varchar(255) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_solicitud`,`id_solicitud_estado`,`fecha`,`archivo`,`nombre`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_gestion_solicitudes_viaticos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_gestion_solicitudes_viaticos` (
  `id_solicitud` int(11) NOT NULL,
  `orden` int(11) NOT NULL,
  `objetivo` text COLLATE latin1_general_ci NOT NULL,
  `fecha_inicio` date NOT NULL,
  `fecha_fin` date NOT NULL,
  `origen` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `destino` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `motivo_viaje_institucion` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `motivo_viaje_otro` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `motivo_actividad_otro` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `viatico_si` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `viatico_si_paga` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `viatico_dias` int(10) NOT NULL,
  `pasajes_si` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `pasajes_si_paga` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `inscripcion_si` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `reembolsos_si_paga` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `tipo_actividad` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `motivo_viaje` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `archivo_reembolsos` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `archivo_invitaciones` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `publico_objetivo_texto` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_solicitud`,`orden`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_honorario_personas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_honorario_personas` (
  `rut` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `email` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `nombre` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `apellidos` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `telefono` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `telefono_movil` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `direccion` text COLLATE latin1_general_ci NOT NULL,
  `comuna` int(11) NOT NULL DEFAULT '1',
  `fecha_nacimiento` date NOT NULL,
  `genero` varchar(1) COLLATE latin1_general_ci NOT NULL,
  `archivo_cv` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `archivo_ci` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `area` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `fecha_actualizacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`rut`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_honorario_personas_honorario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_honorario_personas_honorario` (
  `rut` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `orden` int(11) NOT NULL,
  `supervision` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `labor` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `proyecto` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `cargo` varchar(255) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`rut`,`orden`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_honorario_personas_labores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_honorario_personas_labores` (
  `rut` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `orden` int(11) NOT NULL,
  `cargo` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `institucion` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `monto` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `periodo_inicio_mes` varchar(5) COLLATE latin1_general_ci NOT NULL,
  `periodo_inicio_agno` int(11) NOT NULL,
  `periodo_termino_mes` varchar(5) COLLATE latin1_general_ci NOT NULL,
  `periodo_termino_agno` int(11) NOT NULL,
  `tipo_contrato` varchar(100) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`rut`,`orden`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_honorario_personas_titulo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_honorario_personas_titulo` (
  `rut` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `tipo` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `orden` int(11) NOT NULL,
  `titulo` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `institucion` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `archivo` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ciudad` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `pais` int(11) NOT NULL,
  `fecha` date NOT NULL,
  PRIMARY KEY (`rut`,`orden`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_inscripcion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_inscripcion` (
  `email` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `tipo_inscripcion` varchar(500) COLLATE latin1_general_ci NOT NULL,
  `fecha_actualizacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `tratamiento` varchar(1) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `nombre` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `apellidos` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `edad` int(11) NOT NULL DEFAULT '0',
  `institucion` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `cargo` varchar(250) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `cargo_otro` varchar(200) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `actividad` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `telefono` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `telefono_movil` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `direccion` text COLLATE latin1_general_ci,
  `comuna` int(11) NOT NULL DEFAULT '1',
  `ciudad` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `region` int(11) NOT NULL DEFAULT '0',
  `pais` int(11) NOT NULL DEFAULT '43',
  `rut` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `rut_dv` varchar(1) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `rbd` varchar(8) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `rbd_dv` varchar(1) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `fecha_nacimiento` varchar(10) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `nacionalidad` int(11) NOT NULL DEFAULT '0',
  `genero` varchar(1) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `profesion` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `comentario` text COLLATE latin1_general_ci,
  `comentario_interno` text COLLATE latin1_general_ci,
  `campo_extra1` text COLLATE latin1_general_ci,
  `campo_extra2` text COLLATE latin1_general_ci,
  `campo_extra3` text COLLATE latin1_general_ci,
  `campo_extra4` text COLLATE latin1_general_ci,
  `campo_extra5` text COLLATE latin1_general_ci,
  `campo_extra6` text COLLATE latin1_general_ci,
  `archivo_extra1` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `archivo_extra2` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `archivo_extra3` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `archivo_extra4` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `archivo_extra5` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `archivo_extra6` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `campo_extra7` text COLLATE latin1_general_ci,
  `campo_extra8` text COLLATE latin1_general_ci,
  `campo_extra9` text COLLATE latin1_general_ci,
  `campo_extra10` text COLLATE latin1_general_ci,
  `campo_extra11` text COLLATE latin1_general_ci,
  `campo_extra12` text COLLATE latin1_general_ci,
  `campo_extra13` text COLLATE latin1_general_ci,
  `campo_extra14` text COLLATE latin1_general_ci,
  `campo_extra15` text COLLATE latin1_general_ci,
  `campo_extra16` text COLLATE latin1_general_ci,
  `campo_extra17` text COLLATE latin1_general_ci,
  `campo_extra18` text COLLATE latin1_general_ci,
  `campo_extra19` text COLLATE latin1_general_ci,
  `campo_extra20` text COLLATE latin1_general_ci,
  `inicia_situacion_academica` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `inicia_situacion_academica_carrera` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `inicia_situacion_academica_agno_egreso` int(11) NOT NULL DEFAULT '0',
  `inicia_situacion_academica_agno_ingreso` int(11) NOT NULL DEFAULT '0',
  `inicia_situacion_academica_agno_titulo` int(11) NOT NULL DEFAULT '0',
  `inicia_situacion_academica_institucion` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `inicia_situacion_laboral` varchar(2) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `inicia_situacion_laboral_colegio` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `inicia_situacion_laboral_colegio_telefono` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `inicia_situacion_laboral_colegio_tipo` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `inicia_transferencia_titular` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `inicia_transferencia_banco` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `inicia_transferencia_tipo` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `inicia_transferencia_rut` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `inicia_transferencia_cuenta` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `inicia_rendicion_sede` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `inicia_rendicion_fecha` varchar(250) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `inicia_rendicion_fecha_extra` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `inicia_rendicion_forma_1` int(11) NOT NULL DEFAULT '0',
  `inicia_rendicion_folio_1` int(11) NOT NULL DEFAULT '0',
  `inicia_rendicion_forma_2` int(11) NOT NULL DEFAULT '0',
  `inicia_rendicion_folio_2` int(11) NOT NULL DEFAULT '0',
  `inicia_rendicion_forma_3` int(11) NOT NULL DEFAULT '0',
  `inicia_rendicion_folio_3` int(11) NOT NULL DEFAULT '0',
  `inicia_rendicion_forma_4` int(11) NOT NULL DEFAULT '0',
  `inicia_rendicion_folio_4` int(11) NOT NULL DEFAULT '0',
  `inicia_rendicion_folio_pendiente_1` int(11) NOT NULL DEFAULT '0',
  `inicia_rendicion_folio_pendiente_2` int(11) NOT NULL DEFAULT '0',
  `inicia_rendicion_estado_asistencia` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT 'pendiente',
  `inicia_rendicion_pago_version` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `inicia_rendicion_pago_monto` int(11) NOT NULL DEFAULT '0',
  `inicia_honorario_calidad` varchar(150) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `inicia_honorario_agno` int(4) NOT NULL DEFAULT '0',
  `inicia_honorario_dia` int(11) NOT NULL DEFAULT '0',
  `inicia_honorario_mes` int(11) NOT NULL DEFAULT '0',
  `inicia_honorario_grado_academico` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `inicia_honorario_grado_academico_institucion` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `inicia_honorario_grado_academico_agno` int(4) NOT NULL DEFAULT '0',
  `inicia_honorario_grado_academico_mes` int(11) NOT NULL DEFAULT '0',
  `inicia_honorario_grado_academico_dia` int(11) NOT NULL DEFAULT '0',
  `inicia_honorario_institucion_publica` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `inicia_honorario_inst_publica_cargo` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `inicia_honorario_tipo_contrato` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `inicia_honorario_renta` varchar(11) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `inicia_honorario_honorario` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `inicia_honorario_honorario_cargo` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `inicia_honorario_honorario_periodo` varchar(255) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `inicia_honorario_honorario_monto` varchar(11) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `inicia_honorario_nacionalidad` varchar(200) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `fecha` int(11) NOT NULL DEFAULT '0',
  `preinscripcion` int(11) NOT NULL DEFAULT '1',
  `asistencia` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT 'no',
  `activo` int(11) NOT NULL DEFAULT '1',
  `confirmacion` varchar(5) COLLATE latin1_general_ci NOT NULL DEFAULT 'no',
  `egresado_diplomado` varchar(25) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `egresado_curso` varchar(25) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`email`,`tipo_inscripcion`),
  KEY `fecha_actualizacion` (`fecha_actualizacion`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_noticias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_noticias` (
  `id_noticia` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date DEFAULT NULL,
  `titulo` text COLLATE latin1_general_ci,
  `bajada` text COLLATE latin1_general_ci,
  `noticia` text COLLATE latin1_general_ci,
  `autor` varchar(250) COLLATE latin1_general_ci DEFAULT 'Comunicaciones CIAE',
  `imagen` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `imagen_bajada` text COLLATE latin1_general_ci,
  `imagen2` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `imagen2_bajada` text COLLATE latin1_general_ci,
  `imagen3` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `imagen3_bajada` text COLLATE latin1_general_ci,
  `tipo` varchar(15) COLLATE latin1_general_ci DEFAULT 'noticia',
  `trabajo` int(11) DEFAULT '0',
  `investigaciones_ie` int(11) DEFAULT NULL,
  `cursos_ie` int(11) DEFAULT NULL,
  `tipo_curso` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `noticia_tipo` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `idioma` varchar(2) COLLATE latin1_general_ci DEFAULT 'es',
  `tiene_galeria` int(11) DEFAULT '0',
  `palabra_clave` text COLLATE latin1_general_ci,
  `time_ingreso` int(11) DEFAULT '1302724952' COMMENT 'fecha de ingreso o ultima edicion',
  `calendario_curso` text COLLATE latin1_general_ci,
  `fecha_evento` varchar(250) COLLATE latin1_general_ci DEFAULT NULL,
  `lugar_evento` varchar(250) COLLATE latin1_general_ci DEFAULT NULL,
  `costo_evento` text COLLATE latin1_general_ci,
  `modalidad_evento` varchar(200) COLLATE latin1_general_ci DEFAULT NULL,
  `lugar_curso` varchar(300) COLLATE latin1_general_ci DEFAULT NULL,
  `dirigido` text COLLATE latin1_general_ci,
  `perfil_egreso` text COLLATE latin1_general_ci,
  `plan_estudio` text COLLATE latin1_general_ci,
  `requisitos` text COLLATE latin1_general_ci,
  `certificado_evento` text COLLATE latin1_general_ci,
  `traduccion_evento` text COLLATE latin1_general_ci,
  `contacto_evento` varchar(250) COLLATE latin1_general_ci DEFAULT NULL,
  `web_externo_evento` varchar(250) COLLATE latin1_general_ci DEFAULT NULL,
  `inscripcion_evento` varchar(250) COLLATE latin1_general_ci DEFAULT NULL,
  `organizadores_evento` varchar(250) COLLATE latin1_general_ci DEFAULT NULL,
  `usuario` varchar(250) COLLATE latin1_general_ci DEFAULT 'f59e09345d8de9056d9a89634c8420fb' COMMENT 'usuario creador o ultima modificacion',
  `descuento_evento` text COLLATE latin1_general_ci,
  `origen_id` varchar(11) COLLATE latin1_general_ci DEFAULT NULL,
  `origen_slug` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `origen_url` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`id_noticia`),
  UNIQUE KEY `id_noticia` (`id_noticia`),
  FULLTEXT KEY `titulo` (`titulo`),
  FULLTEXT KEY `bajada` (`bajada`),
  FULLTEXT KEY `titulo_bajada` (`titulo`,`bajada`)
) ENGINE=MyISAM AUTO_INCREMENT=3465 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_noticias_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_noticias_link` (
  `id_link` int(11) NOT NULL AUTO_INCREMENT,
  `id_noticia` int(11) NOT NULL,
  `link` text COLLATE latin1_general_ci NOT NULL,
  `texto` text COLLATE latin1_general_ci NOT NULL,
  `orden` int(11) NOT NULL DEFAULT '1',
  `tipo` varchar(5) COLLATE latin1_general_ci NOT NULL DEFAULT 'doc',
  PRIMARY KEY (`id_link`)
) ENGINE=MyISAM AUTO_INCREMENT=8758 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_noticias_persona`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_noticias_persona` (
  `id_noticia` int(11) NOT NULL,
  `id_persona` int(11) NOT NULL DEFAULT '1',
  `persona_nombre` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `orden` int(11) NOT NULL,
  `destacado` int(1) NOT NULL DEFAULT '0',
  `tipo` text COLLATE latin1_general_ci,
  `id_tipo` int(11) NOT NULL,
  PRIMARY KEY (`id_noticia`,`id_persona`,`id_tipo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_noticias_prensa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_noticias_prensa` (
  `id_prensa` int(11) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `bajada` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `url` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `pdf` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `fecha` date NOT NULL,
  `medio` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `tema` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `tipo_medio` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `tipo_cobertura` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `investigador` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `tipo_aparicion` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `palabras_clave` text COLLATE latin1_general_ci NOT NULL,
  `id_area` int(11) NOT NULL,
  PRIMARY KEY (`id_prensa`),
  FULLTEXT KEY `titulo` (`titulo`),
  FULLTEXT KEY `bajada` (`bajada`),
  FULLTEXT KEY `titulo_bajada` (`titulo`,`bajada`)
) ENGINE=MyISAM AUTO_INCREMENT=2214 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_noticias_prensa_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_noticias_prensa_site` (
  `id_prensa` int(6) NOT NULL,
  `id_site` int(4) NOT NULL,
  UNIQUE KEY `id_prensa` (`id_prensa`,`id_site`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_noticias_profesores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_noticias_profesores` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `id_noticia` int(11) NOT NULL,
  `id_persona` int(11) NOT NULL,
  `persona_nombre` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `orden` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_noticias_profesores_academicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_noticias_profesores_academicos` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `id_noticia` int(11) NOT NULL,
  `id_persona` int(11) NOT NULL,
  `persona_nombre` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `orden` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_noticias_profesores_comite`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_noticias_profesores_comite` (
  `id_noticia` int(11) NOT NULL,
  `id_persona` int(11) NOT NULL DEFAULT '1',
  `persona_nombre` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `orden` int(11) NOT NULL,
  `destacado` int(1) NOT NULL DEFAULT '0',
  `tipo` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_noticia`,`id_persona`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_noticias_profesores_invitados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_noticias_profesores_invitados` (
  `id_noticia` int(11) NOT NULL,
  `id_persona` int(11) NOT NULL,
  `persona_nombre` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `orden` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_noticias_profesores_visitantes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_noticias_profesores_visitantes` (
  `id` int(4) NOT NULL AUTO_INCREMENT,
  `id_noticia` int(11) NOT NULL,
  `id_persona` int(11) NOT NULL,
  `persona_nombre` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `orden` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_noticias_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_noticias_site` (
  `id_noticia` int(6) NOT NULL,
  `id_site` int(4) NOT NULL DEFAULT '100',
  `activo` int(1) NOT NULL DEFAULT '0',
  `destacado` int(1) NOT NULL DEFAULT '0',
  `destacado_forzado` int(1) NOT NULL DEFAULT '0',
  UNIQUE KEY `id_noticia` (`id_noticia`,`id_site`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_noticias_visita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_noticias_visita` (
  `id_visita` int(11) NOT NULL AUTO_INCREMENT,
  `sitio` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `id_noticia` int(11) NOT NULL,
  `tipo_visita` varchar(550) COLLATE latin1_general_ci NOT NULL,
  `ip_address` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `url` varchar(500) COLLATE latin1_general_ci DEFAULT NULL,
  `fecha` int(11) NOT NULL,
  `fecha_completa` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id_visita`)
) ENGINE=MyISAM AUTO_INCREMENT=6379328 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_palabra_clave`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_palabra_clave` (
  `id_palabra_clave` int(5) NOT NULL AUTO_INCREMENT,
  `palabra_clave` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `suma` int(6) NOT NULL DEFAULT '1',
  `tipo_palabra` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `desactivar` int(2) NOT NULL DEFAULT '0',
  `id_site` int(4) NOT NULL,
  PRIMARY KEY (`id_palabra_clave`),
  UNIQUE KEY `palabra_clave` (`palabra_clave`,`tipo_palabra`,`id_site`),
  FULLTEXT KEY `palabra_clave_2` (`palabra_clave`)
) ENGINE=MyISAM AUTO_INCREMENT=1423 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_personas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_personas` (
  `id_persona` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `nombre` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `apellido_paterno` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `apellido_materno` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `nombre_publicacion` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `genero` varchar(1) COLLATE latin1_general_ci NOT NULL,
  `rut` varchar(8) COLLATE latin1_general_ci NOT NULL,
  `rut_dv` varchar(1) COLLATE latin1_general_ci NOT NULL,
  `pasaporte` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `afiliacion` text COLLATE latin1_general_ci NOT NULL,
  `id_tipo_contrato` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `facultad_externa` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `id_tipo_contrato_facultad` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `id_universidad` int(11) NOT NULL DEFAULT '1',
  `direccion` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `comuna_id` int(11) NOT NULL DEFAULT '1',
  `pais_id` int(11) NOT NULL DEFAULT '43',
  `telefono_personal` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `grado` text COLLATE latin1_general_ci NOT NULL,
  `grado_academico_honorarios` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `cargo_gestion` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `cargo` varchar(350) COLLATE latin1_general_ci NOT NULL,
  `cargo_en` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `activo` varchar(11) COLLATE latin1_general_ci NOT NULL DEFAULT '1',
  `telefono` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `url` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `imagen` varchar(150) COLLATE latin1_general_ci NOT NULL DEFAULT 'blanco.jpg',
  `email` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `email_alternativo` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `archivo_rut` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `cv` text COLLATE latin1_general_ci NOT NULL,
  `perfil` text COLLATE latin1_general_ci NOT NULL,
  `anexo` varchar(2) COLLATE latin1_general_ci NOT NULL DEFAULT 'no',
  `anexo_numero` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `archivo_pasaporte` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `archivo_cv` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `archivo_titulo` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `datos_honorarios_completo` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_persona`)
) ENGINE=MyISAM AUTO_INCREMENT=505 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_personas_areas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_personas_areas` (
  `id_persona` int(11) NOT NULL,
  `id_area` int(11) NOT NULL,
  PRIMARY KEY (`id_persona`,`id_area`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_personas_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_personas_site` (
  `id_persona` int(4) NOT NULL,
  `id_site` int(4) NOT NULL,
  `cargo` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `orden` int(3) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_persona`,`id_site`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_personas_tipo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_personas_tipo` (
  `id_persona` int(11) NOT NULL,
  `id_tipo` int(11) NOT NULL,
  `id_site` int(4) NOT NULL,
  PRIMARY KEY (`id_persona`,`id_tipo`,`id_site`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_personas_titulos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_personas_titulos` (
  `id_titulo` int(11) NOT NULL AUTO_INCREMENT,
  `id_persona` int(11) NOT NULL,
  `tipo` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `titulo` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `institucion` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `archivo` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `ciudad` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `pais` int(11) NOT NULL,
  `fecha` date NOT NULL,
  PRIMARY KEY (`id_titulo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_postulaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_postulaciones` (
  `email` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `email_md5` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `postulacion` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `fecha` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `nombre` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `apellidos` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `campo_investigacion` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `institucion` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `agno` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `informacion_adicional` text COLLATE latin1_general_ci NOT NULL,
  `archivo_motivacion` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `archivo_propuesta` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `archivo_cv` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `archivo_titulo` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `carta1_archivo` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `carta1_nombre` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `carta1_email` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `carta1_descripcion` text COLLATE latin1_general_ci NOT NULL,
  `carta2_archivo` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `carta2_nombre` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `carta2_email` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `carta2_descripcion` text COLLATE latin1_general_ci NOT NULL,
  `carta3_archivo` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `carta3_nombre` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `carta3_email` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `carta3_descripcion` text COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`email`,`postulacion`),
  KEY `fecha` (`fecha`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_proyectos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_proyectos` (
  `id_proyecto` int(11) NOT NULL AUTO_INCREMENT,
  `activo` int(11) NOT NULL DEFAULT '1',
  `proyecto` text COLLATE latin1_general_ci NOT NULL,
  `proyecto_en` text COLLATE latin1_general_ci,
  `codigo` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `imagen` varchar(150) COLLATE latin1_general_ci NOT NULL DEFAULT 'blanco.jpg',
  `id_tipo` int(11) NOT NULL DEFAULT '12',
  `id_tipo_area_proyecto` int(11) NOT NULL,
  `agno_inicio` varchar(11) COLLATE latin1_general_ci DEFAULT NULL,
  `agno_termino` varchar(11) COLLATE latin1_general_ci DEFAULT NULL,
  `mes_inicio` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `url` varchar(250) COLLATE latin1_general_ci DEFAULT NULL,
  `antecedentes` text COLLATE latin1_general_ci,
  `objetivos` text COLLATE latin1_general_ci,
  `metodologia` text COLLATE latin1_general_ci,
  `periodo` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `financiamiento` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `productos` text COLLATE latin1_general_ci,
  `mandante` varchar(250) COLLATE latin1_general_ci DEFAULT NULL,
  `cooperacion_nacional` text COLLATE latin1_general_ci,
  `cooperacion_internacional` text COLLATE latin1_general_ci,
  `seleccionado_area` varchar(4) COLLATE latin1_general_ci DEFAULT NULL COMMENT 'id_area',
  `palabras_clave` text COLLATE latin1_general_ci,
  `id_usuario_responsable` varchar(250) COLLATE latin1_general_ci DEFAULT NULL,
  `centro_costo` varchar(150) COLLATE latin1_general_ci DEFAULT NULL,
  `id_persona_responsable` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_proyecto`),
  FULLTEXT KEY `proyecto` (`proyecto`),
  FULLTEXT KEY `antecedentes` (`antecedentes`),
  FULLTEXT KEY `financiamiento` (`financiamiento`),
  FULLTEXT KEY `proyecto_ant_finan` (`proyecto`,`antecedentes`,`financiamiento`)
) ENGINE=MyISAM AUTO_INCREMENT=382 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_proyectos_personas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_proyectos_personas` (
  `id_proyecto` int(11) NOT NULL,
  `id_persona` int(11) NOT NULL DEFAULT '1',
  `cargo` varchar(250) COLLATE latin1_general_ci DEFAULT NULL,
  `orden` int(11) NOT NULL DEFAULT '100',
  `nombre_extra` varchar(250) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `destacado` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_proyecto`,`id_persona`,`nombre_extra`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_proyectos_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_proyectos_site` (
  `id_proyecto` int(4) NOT NULL,
  `id_site` int(4) NOT NULL,
  `vigente` tinyint(2) NOT NULL DEFAULT '1',
  UNIQUE KEY `id_proyecto` (`id_proyecto`,`id_site`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_publicaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_publicaciones` (
  `id_publicaciones` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` int(11) NOT NULL DEFAULT '1305012453',
  `titulo` text COLLATE latin1_general_ci,
  `resumen` text COLLATE latin1_general_ci,
  `titulo_en` text COLLATE latin1_general_ci,
  `doi` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `isi` varchar(11) COLLATE latin1_general_ci NOT NULL DEFAULT 'no',
  `mes` varchar(50) COLLATE latin1_general_ci DEFAULT NULL,
  `mes_numero` int(11) DEFAULT NULL,
  `agno` varchar(20) COLLATE latin1_general_ci DEFAULT NULL,
  `factor_Q` int(11) DEFAULT NULL,
  `cooperacion_internacional` varchar(250) COLLATE latin1_general_ci DEFAULT NULL,
  `cooperacion_nacional` varchar(250) COLLATE latin1_general_ci DEFAULT NULL,
  `texto` text COLLATE latin1_general_ci,
  `documento` varchar(250) COLLATE latin1_general_ci DEFAULT NULL,
  `documento_publico` varchar(2) COLLATE latin1_general_ci NOT NULL DEFAULT 'no' COMMENT 'si, si el documento se pude ver publicamente y no si es privado',
  `link` varchar(250) COLLATE latin1_general_ci DEFAULT NULL,
  `numero` int(11) DEFAULT NULL,
  `id_tipo` int(11) DEFAULT NULL,
  `id_area` int(11) DEFAULT NULL,
  `activo` int(11) NOT NULL DEFAULT '1',
  `destacado` int(11) NOT NULL DEFAULT '0',
  `ver_detalle` int(11) NOT NULL DEFAULT '0',
  `seleccionado` varchar(4) COLLATE latin1_general_ci DEFAULT NULL COMMENT 'si/no',
  `palabras_clave` text COLLATE latin1_general_ci,
  `bib_palabra_clave` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `bib_ubicacion` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `bib_ciudad` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `bib_pais` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `bib_edicion` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `bib_editor` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `bib_editorial` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `bib_institucion` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `bib_revista` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `bib_libro` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `bib_capitulo` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `bib_numero` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `bib_paginas` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `bib_series` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `bib_volume` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `bib_escuela` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `bib_tipo_estudio` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `bib_respaldo_tipo_ingreso` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `bib_respaldo_comentario` text COLLATE latin1_general_ci,
  `bib_respaldo_autor` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `bib_respaldo_archivo` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`id_publicaciones`),
  FULLTEXT KEY `titulo` (`titulo`),
  FULLTEXT KEY `resumen` (`resumen`),
  FULLTEXT KEY `titulo_resumen` (`titulo`,`resumen`)
) ENGINE=MyISAM AUTO_INCREMENT=901 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_publicaciones_persona`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_publicaciones_persona` (
  `id_publicaciones` int(11) NOT NULL,
  `id_persona` int(11) NOT NULL DEFAULT '1',
  `persona_nombre` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `orden` int(11) NOT NULL,
  `destacado` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_publicaciones`,`id_persona`,`persona_nombre`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_publicaciones_proyecto`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_publicaciones_proyecto` (
  `id_publicaciones` int(11) NOT NULL,
  `id_proyecto` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_publicaciones_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_publicaciones_site` (
  `id_publicaciones` int(4) NOT NULL,
  `id_site` int(4) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_recursos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_recursos` (
  `id_recurso` int(11) NOT NULL AUTO_INCREMENT,
  `fecha` date NOT NULL,
  `titulo` text COLLATE latin1_general_ci NOT NULL,
  `bajada` text COLLATE latin1_general_ci NOT NULL,
  `descripcion` text COLLATE latin1_general_ci NOT NULL,
  `autor` varchar(250) COLLATE latin1_general_ci NOT NULL DEFAULT 'CIAE',
  `editorial` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `paginas` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `isbn` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `extra` text COLLATE latin1_general_ci NOT NULL,
  `imagen` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `agno` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT '0',
  `archivo` varchar(400) COLLATE latin1_general_ci NOT NULL,
  `video` varchar(300) COLLATE latin1_general_ci NOT NULL,
  `video_lista` varchar(300) COLLATE latin1_general_ci NOT NULL,
  `libro_digital` varchar(300) COLLATE latin1_general_ci NOT NULL,
  `iframe` text COLLATE latin1_general_ci NOT NULL,
  `link_externo` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `link_externo_texto` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `idioma` varchar(2) COLLATE latin1_general_ci NOT NULL DEFAULT 'es',
  `palabras_clave` text COLLATE latin1_general_ci NOT NULL,
  `time_ingreso` int(11) NOT NULL DEFAULT '1302724952' COMMENT 'fecha de ingreso o ultima edicion',
  `usuario` varchar(250) COLLATE latin1_general_ci NOT NULL DEFAULT 'f59e09345d8de9056d9a89634c8420fb' COMMENT 'usuario creador o ultima modificacion',
  `origen_id` int(11) DEFAULT NULL,
  `origen_slug` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `origen_url` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`id_recurso`),
  FULLTEXT KEY `titulo` (`titulo`),
  FULLTEXT KEY `bajada` (`bajada`),
  FULLTEXT KEY `titulo_bajada` (`titulo`,`bajada`)
) ENGINE=MyISAM AUTO_INCREMENT=1115 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_recursos_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_recursos_site` (
  `id_recurso` int(6) NOT NULL,
  `id_site` int(4) NOT NULL,
  `id_tipo` int(4) NOT NULL,
  `id_tipo_estructura` int(11) NOT NULL,
  `activo` int(1) NOT NULL,
  `destacado` tinyint(1) NOT NULL,
  PRIMARY KEY (`id_recurso`,`id_site`,`id_tipo_estructura`),
  UNIQUE KEY `id_recurso` (`id_recurso`,`id_site`,`id_tipo_estructura`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_site` (
  `id_site` int(4) NOT NULL AUTO_INCREMENT,
  `nombre_site` varchar(256) COLLATE latin1_general_ci NOT NULL,
  `titulo_site` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `url_site` varchar(255) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_site`,`nombre_site`,`titulo_site`)
) ENGINE=MyISAM AUTO_INCREMENT=101 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_tadi_pedido`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_tadi_pedido` (
  `id_pedido` int(11) NOT NULL AUTO_INCREMENT,
  `estado` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT 'activo',
  `fecha` date NOT NULL,
  `nombre` varchar(255) CHARACTER SET utf8 NOT NULL,
  `rut` varchar(50) CHARACTER SET utf8 NOT NULL,
  `razon_social` varchar(255) CHARACTER SET utf8 NOT NULL,
  `giro` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `cantidad` int(11) NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 NOT NULL,
  `institucion` varchar(255) CHARACTER SET utf8 NOT NULL,
  `direccion` varchar(255) CHARACTER SET utf8 NOT NULL,
  `ciudad` varchar(255) CHARACTER SET utf8 NOT NULL,
  `region` varchar(250) CHARACTER SET utf8 NOT NULL,
  `pais` varchar(255) CHARACTER SET utf8 NOT NULL,
  `telefono_fijo` varchar(255) CHARACTER SET utf8 NOT NULL,
  `telefono_celular` varchar(255) CHARACTER SET utf8 NOT NULL,
  `tipo_envio` varchar(150) CHARACTER SET utf8 NOT NULL,
  `contrato_sistema` varchar(255) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_pedido`)
) ENGINE=MyISAM AUTO_INCREMENT=1461 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_textos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_textos` (
  `id_texto` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `texto_es` text COLLATE latin1_general_ci NOT NULL,
  `texto_en` text COLLATE latin1_general_ci NOT NULL,
  `imagen` varchar(255) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_texto`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_tipo_centro_costos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_tipo_centro_costos` (
  `id_centro_costo` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `proyecto` text COLLATE latin1_general_ci NOT NULL,
  `usuario_responsable` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `cuenta_corriente` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `activo` int(11) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id_centro_costo`)
) ENGINE=MyISAM AUTO_INCREMENT=10002 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_tipo_contrato`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_tipo_contrato` (
  `id_tipo_contrato` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `tipo_contrato` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `cumple_contrato` varchar(2) COLLATE latin1_general_ci NOT NULL DEFAULT 'si',
  PRIMARY KEY (`id_tipo_contrato`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_tipo_honorarios_calidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_tipo_honorarios_calidad` (
  `id_tipo_honorarios_calidad` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `tipo_honorarios_calidad` varchar(255) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_tipo_honorarios_calidad`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_tipo_honorarios_estados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_tipo_honorarios_estados` (
  `id_tipo_honorarios_estados` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `tipo_honorarios_estados` varchar(255) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_tipo_honorarios_estados`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_tipo_personas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_tipo_personas` (
  `id_tipo` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `tipo_en` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `grupo` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `orden` int(11) NOT NULL,
  `descripcion` text COLLATE latin1_general_ci NOT NULL,
  `descripcion_en` text COLLATE latin1_general_ci NOT NULL,
  `mostrar_universidad` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_tipo`)
) ENGINE=MyISAM AUTO_INCREMENT=59 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_tipo_proyectos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_tipo_proyectos` (
  `id_tipo` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `orden` int(11) NOT NULL,
  PRIMARY KEY (`id_tipo`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_tipo_proyectos_area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_tipo_proyectos_area` (
  `id_tipo` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `orden` int(11) NOT NULL,
  PRIMARY KEY (`id_tipo`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_tipo_publicaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_tipo_publicaciones` (
  `id_tipo` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `orden` int(11) NOT NULL,
  `estado` varchar(150) COLLATE latin1_general_ci NOT NULL DEFAULT 'publico',
  `tipo_academico` varchar(255) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_tipo`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_tipo_recursos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_tipo_recursos` (
  `id_tipo` int(4) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(256) COLLATE latin1_general_ci NOT NULL,
  `orden` int(4) NOT NULL,
  `id_site` int(2) NOT NULL,
  PRIMARY KEY (`id_tipo`)
) ENGINE=MyISAM AUTO_INCREMENT=53 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_tipo_recursos_estructura`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_tipo_recursos_estructura` (
  `id_tipo_estructura` int(4) NOT NULL AUTO_INCREMENT,
  `tipo_estructura` varchar(256) COLLATE latin1_general_ci NOT NULL,
  `orden` int(4) NOT NULL,
  `id_site` int(2) NOT NULL,
  `opcion_site` varchar(250) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_tipo_estructura`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_tipo_solicitudes_estados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_tipo_solicitudes_estados` (
  `id_tipo_estado` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `tipo_estado` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `temporalidad` varchar(100) COLLATE latin1_general_ci NOT NULL DEFAULT 'revision',
  `funcionalidad` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `orden` int(11) NOT NULL,
  `id_usuario_responsable` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `user_id_responsable` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `estado_siguiente_aprobado` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `estado_siguiente_rechazado` varchar(200) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_tipo_estado`,`funcionalidad`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_tipo_solicitudes_gestion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_tipo_solicitudes_gestion` (
  `id_tipo_solicitud` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `tipo_solicitud` varchar(255) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_tipo_solicitud`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `site_universidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `site_universidad` (
  `id_universidad` int(11) NOT NULL AUTO_INCREMENT,
  `universidad` varchar(250) COLLATE latin1_general_ci NOT NULL,
  `orden` int(11) NOT NULL,
  PRIMARY KEY (`id_universidad`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `view_areas_proyecto`;
/*!50001 DROP VIEW IF EXISTS `view_areas_proyecto`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_areas_proyecto` AS SELECT 
 1 AS `id_proyecto`,
 1 AS `id_area`,
 1 AS `area_es`,
 1 AS `area_en`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_auth_menu_access`;
/*!50001 DROP VIEW IF EXISTS `view_auth_menu_access`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_auth_menu_access` AS SELECT 
 1 AS `id`,
 1 AS `permiso`,
 1 AS `opcion`,
 1 AS `titulo_es`,
 1 AS `tipo_menu`,
 1 AS `link`,
 1 AS `tipo_archivo`,
 1 AS `sitio`,
 1 AS `archivo`,
 1 AS `publicar`,
 1 AS `menu_padre`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_auth_persona`;
/*!50001 DROP VIEW IF EXISTS `view_auth_persona`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_auth_persona` AS SELECT 
 1 AS `username`,
 1 AS `perms`,
 1 AS `permisos_extras`,
 1 AS `activo_usuario`,
 1 AS `alias`,
 1 AS `id_persona`,
 1 AS `user_id`,
 1 AS `nombre`,
 1 AS `apellido_paterno`,
 1 AS `apellido_materno`,
 1 AS `nombre_publicacion`,
 1 AS `rut`,
 1 AS `rut_dv`,
 1 AS `pasaporte`,
 1 AS `afiliacion`,
 1 AS `id_tipo_contrato`,
 1 AS `facultad_externa`,
 1 AS `id_tipo_contrato_facultad`,
 1 AS `id_universidad`,
 1 AS `direccion`,
 1 AS `telefono_personal`,
 1 AS `grado`,
 1 AS `cargo_gestion`,
 1 AS `cargo`,
 1 AS `cargo_en`,
 1 AS `activo`,
 1 AS `telefono`,
 1 AS `url`,
 1 AS `imagen`,
 1 AS `email`,
 1 AS `email_alternativo`,
 1 AS `archivo_rut`,
 1 AS `cv`,
 1 AS `perfil`,
 1 AS `anexo`,
 1 AS `anexo_numero`,
 1 AS `fecha`,
 1 AS `archivo_pasaporte`,
 1 AS `archivo_cv`,
 1 AS `archivo_titulo`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_auth_site`;
/*!50001 DROP VIEW IF EXISTS `view_auth_site`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_auth_site` AS SELECT 
 1 AS `user_id`,
 1 AS `nombre`,
 1 AS `apellido_paterno`,
 1 AS `username`,
 1 AS `permiso`,
 1 AS `id_site`,
 1 AS `nombre_site`,
 1 AS `titulo_site`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_bannner_site`;
/*!50001 DROP VIEW IF EXISTS `view_bannner_site`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_bannner_site` AS SELECT 
 1 AS `id_banner`,
 1 AS `imagen`,
 1 AS `titulo`,
 1 AS `bajada`,
 1 AS `orden`,
 1 AS `link`,
 1 AS `activo`,
 1 AS `idioma`,
 1 AS `tipo`,
 1 AS `id_site`,
 1 AS `fecha_caducidad`,
 1 AS `fecha_caducidad_html`,
 1 AS `nombre_site`,
 1 AS `titulo_site`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_boletin_especiales_site`;
/*!50001 DROP VIEW IF EXISTS `view_boletin_especiales_site`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_boletin_especiales_site` AS SELECT 
 1 AS `id_boletin`,
 1 AS `agno`,
 1 AS `mes`,
 1 AS `titulo`,
 1 AS `id_noticia`,
 1 AS `id_site`,
 1 AS `nombre_site`,
 1 AS `titulo_site`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_boletin_site`;
/*!50001 DROP VIEW IF EXISTS `view_boletin_site`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_boletin_site` AS SELECT 
 1 AS `id_boletin`,
 1 AS `agno`,
 1 AS `mes`,
 1 AS `archivo`,
 1 AS `id_site`,
 1 AS `nombre_site`,
 1 AS `titulo_site`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_certificado_detalle_tipo`;
/*!50001 DROP VIEW IF EXISTS `view_certificado_detalle_tipo`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_certificado_detalle_tipo` AS SELECT 
 1 AS `id_certificado`,
 1 AS `total`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_common_logs_download_fecha`;
/*!50001 DROP VIEW IF EXISTS `view_common_logs_download_fecha`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_common_logs_download_fecha` AS SELECT 
 1 AS `id_visit`,
 1 AS `sitio`,
 1 AS `fecha_html`,
 1 AS `ip_address`,
 1 AS `documento`,
 1 AS `estado`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_common_logs_download_fecha_error`;
/*!50001 DROP VIEW IF EXISTS `view_common_logs_download_fecha_error`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_common_logs_download_fecha_error` AS SELECT 
 1 AS `id_visit`,
 1 AS `sitio`,
 1 AS `fecha_html`,
 1 AS `ip_address`,
 1 AS `documento`,
 1 AS `estado`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_common_logs_download_resumen`;
/*!50001 DROP VIEW IF EXISTS `view_common_logs_download_resumen`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_common_logs_download_resumen` AS SELECT 
 1 AS `total`,
 1 AS `documento`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_common_logs_fecha`;
/*!50001 DROP VIEW IF EXISTS `view_common_logs_fecha`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_common_logs_fecha` AS SELECT 
 1 AS `time_log`,
 1 AS `ip`,
 1 AS `ip_extra`,
 1 AS `sitio`,
 1 AS `username`,
 1 AS `action`,
 1 AS `msg`,
 1 AS `post`,
 1 AS `fecha`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_common_logs_fecha_sin_visita`;
/*!50001 DROP VIEW IF EXISTS `view_common_logs_fecha_sin_visita`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_common_logs_fecha_sin_visita` AS SELECT 
 1 AS `time_log`,
 1 AS `fecha_html`,
 1 AS `ip`,
 1 AS `sitio`,
 1 AS `username`,
 1 AS `action`,
 1 AS `msg`,
 1 AS `post`,
 1 AS `ip_extra`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_common_logs_fecha_sin_visita_usuario`;
/*!50001 DROP VIEW IF EXISTS `view_common_logs_fecha_sin_visita_usuario`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_common_logs_fecha_sin_visita_usuario` AS SELECT 
 1 AS `time_log`,
 1 AS `fecha_html`,
 1 AS `ip`,
 1 AS `sitio`,
 1 AS `username`,
 1 AS `action`,
 1 AS `msg`,
 1 AS `post`,
 1 AS `ip_extra`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_common_logs_fecha_sin_visita_usuario_login`;
/*!50001 DROP VIEW IF EXISTS `view_common_logs_fecha_sin_visita_usuario_login`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_common_logs_fecha_sin_visita_usuario_login` AS SELECT 
 1 AS `time_log`,
 1 AS `fecha_html`,
 1 AS `ip`,
 1 AS `sitio`,
 1 AS `username`,
 1 AS `action`,
 1 AS `msg`,
 1 AS `post`,
 1 AS `ip_extra`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_common_logs_ip`;
/*!50001 DROP VIEW IF EXISTS `view_common_logs_ip`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_common_logs_ip` AS SELECT 
 1 AS `ip`,
 1 AS `bloqueado`,
 1 AS `fecha`,
 1 AS `sitio`,
 1 AS `url`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_common_logs_noticias_visitas`;
/*!50001 DROP VIEW IF EXISTS `view_common_logs_noticias_visitas`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_common_logs_noticias_visitas` AS SELECT 
 1 AS `id_noticia`,
 1 AS `total_apariciones`,
 1 AS `tipo_visita`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_common_logs_url_fecha`;
/*!50001 DROP VIEW IF EXISTS `view_common_logs_url_fecha`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_common_logs_url_fecha` AS SELECT 
 1 AS `id_visit`,
 1 AS `fecha_html`,
 1 AS `ip_address`,
 1 AS `username`,
 1 AS `url`,
 1 AS `uri`,
 1 AS `browser`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_common_logs_url_fecha_error`;
/*!50001 DROP VIEW IF EXISTS `view_common_logs_url_fecha_error`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_common_logs_url_fecha_error` AS SELECT 
 1 AS `id_visit`,
 1 AS `fecha_html`,
 1 AS `ip_address`,
 1 AS `username`,
 1 AS `url`,
 1 AS `uri`,
 1 AS `browser`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_common_logs_url_fecha_usuario`;
/*!50001 DROP VIEW IF EXISTS `view_common_logs_url_fecha_usuario`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_common_logs_url_fecha_usuario` AS SELECT 
 1 AS `id_visit`,
 1 AS `fecha_html`,
 1 AS `ip_address`,
 1 AS `username`,
 1 AS `url`,
 1 AS `uri`,
 1 AS `browser`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_common_logs_visitas_uri`;
/*!50001 DROP VIEW IF EXISTS `view_common_logs_visitas_uri`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_common_logs_visitas_uri` AS SELECT 
 1 AS `url`,
 1 AS `uri`,
 1 AS `total`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_compras_adquisiciones`;
/*!50001 DROP VIEW IF EXISTS `view_compras_adquisiciones`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_compras_adquisiciones` AS SELECT 
 1 AS `id_compra`,
 1 AS `concepto_tipo_gasto`,
 1 AS `cantidad`,
 1 AS `valor`,
 1 AS `deleted_at`,
 1 AS `created_at`,
 1 AS `updated_at`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_email_webmaster_envio_orden`;
/*!50001 DROP VIEW IF EXISTS `view_email_webmaster_envio_orden`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_email_webmaster_envio_orden` AS SELECT 
 1 AS `fecha`,
 1 AS `email`,
 1 AS `orden`,
 1 AS `total`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_email_webmaster_envio_total`;
/*!50001 DROP VIEW IF EXISTS `view_email_webmaster_envio_total`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_email_webmaster_envio_total` AS SELECT 
 1 AS `fecha`,
 1 AS `dia`,
 1 AS `total`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_gestion_centro_costo_responsable`;
/*!50001 DROP VIEW IF EXISTS `view_gestion_centro_costo_responsable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_gestion_centro_costo_responsable` AS SELECT 
 1 AS `id_centro_costo`,
 1 AS `codigo`,
 1 AS `centro_costo`,
 1 AS `cuenta_corriente`,
 1 AS `activo`,
 1 AS `activo_html`,
 1 AS `usuario`,
 1 AS `nombre`,
 1 AS `apellido_paterno`,
 1 AS `usuario_responsable`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_gestion_destinos`;
/*!50001 DROP VIEW IF EXISTS `view_gestion_destinos`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_gestion_destinos` AS SELECT 
 1 AS `destino`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_gestion_honorarios_personas`;
/*!50001 DROP VIEW IF EXISTS `view_gestion_honorarios_personas`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_gestion_honorarios_personas` AS SELECT 
 1 AS `id_honorario`,
 1 AS `id_persona`,
 1 AS `numero_convenio`,
 1 AS `numero_decreto`,
 1 AS `numero_memo`,
 1 AS `fecha_creacion`,
 1 AS `fecha_termino`,
 1 AS `id_centro_costo`,
 1 AS `centro_costo`,
 1 AS `proyecto`,
 1 AS `id_investigador_responsable`,
 1 AS `id_investigador_supervidor`,
 1 AS `monto_comprometido`,
 1 AS `numero_cuotas`,
 1 AS `fecha_desde`,
 1 AS `fecha_hasta`,
 1 AS `fecha_convenio`,
 1 AS `fecha_firma`,
 1 AS `fecha_compromiso`,
 1 AS `fecha_aprobacion`,
 1 AS `id_tipo_estados_honorarios`,
 1 AS `id_tipo_honorarios_calidad`,
 1 AS `horas_jornada`,
 1 AS `comentario_horas_jornada`,
 1 AS `labor`,
 1 AS `labor_resumida`,
 1 AS `proyecto_corto`,
 1 AS `observacion`,
 1 AS `envio_correo_general`,
 1 AS `monto_comprometido_html`,
 1 AS `investigador_responsable`,
 1 AS `investigador_supervisor`,
 1 AS `user_id`,
 1 AS `nombre`,
 1 AS `apellido_paterno`,
 1 AS `apellido_materno`,
 1 AS `nombre_publicacion`,
 1 AS `fecha_nacimiento`,
 1 AS `fecha_nacimiento_html`,
 1 AS `genero`,
 1 AS `rut`,
 1 AS `rut_html`,
 1 AS `rut_dv`,
 1 AS `pasaporte`,
 1 AS `afiliacion`,
 1 AS `id_tipo_contrato`,
 1 AS `tipo_contrato`,
 1 AS `cumple_contrato`,
 1 AS `facultad_externa`,
 1 AS `id_tipo_contrato_facultad`,
 1 AS `id_universidad`,
 1 AS `universidad`,
 1 AS `direccion`,
 1 AS `comuna_id`,
 1 AS `comuna`,
 1 AS `region`,
 1 AS `pais_id`,
 1 AS `pais`,
 1 AS `telefono_personal`,
 1 AS `grado`,
 1 AS `grado_academico_honorarios`,
 1 AS `cargo_gestion`,
 1 AS `cargo`,
 1 AS `cargo_en`,
 1 AS `activo`,
 1 AS `telefono`,
 1 AS `url`,
 1 AS `imagen`,
 1 AS `email`,
 1 AS `email_alternativo`,
 1 AS `archivo_rut`,
 1 AS `cv`,
 1 AS `perfil`,
 1 AS `anexo`,
 1 AS `anexo_numero`,
 1 AS `fecha_actualizacion`,
 1 AS `archivo_pasaporte`,
 1 AS `archivo_cv`,
 1 AS `archivo_titulo`,
 1 AS `datos_honorarios_completo`,
 1 AS `fecha_creacion_html`,
 1 AS `fecha_termino_html`,
 1 AS `fecha_desde_html`,
 1 AS `fecha_hasta_html`,
 1 AS `fecha_convenio_html`,
 1 AS `fecha_firma_html`,
 1 AS `fecha_compromiso_html`,
 1 AS `fecha_aprobacion_html`,
 1 AS `centro_costo_codigo`,
 1 AS `centro_costo_proyecto`,
 1 AS `estado_convenio`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_gestion_honorarios_personas_cuotas`;
/*!50001 DROP VIEW IF EXISTS `view_gestion_honorarios_personas_cuotas`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_gestion_honorarios_personas_cuotas` AS SELECT 
 1 AS `id_honorario`,
 1 AS `id_persona`,
 1 AS `numero_convenio`,
 1 AS `numero_decreto`,
 1 AS `numero_memo`,
 1 AS `fecha_creacion`,
 1 AS `fecha_termino`,
 1 AS `id_centro_costo`,
 1 AS `centro_costo`,
 1 AS `proyecto`,
 1 AS `id_investigador_responsable`,
 1 AS `id_investigador_supervidor`,
 1 AS `monto_comprometido`,
 1 AS `numero_cuotas`,
 1 AS `fecha_desde`,
 1 AS `fecha_hasta`,
 1 AS `fecha_convenio`,
 1 AS `fecha_firma`,
 1 AS `fecha_compromiso`,
 1 AS `fecha_aprobacion`,
 1 AS `id_tipo_estados_honorarios`,
 1 AS `id_tipo_honorarios_calidad`,
 1 AS `horas_jornada`,
 1 AS `comentario_horas_jornada`,
 1 AS `labor`,
 1 AS `labor_resumida`,
 1 AS `proyecto_corto`,
 1 AS `observacion`,
 1 AS `envio_correo_general`,
 1 AS `monto_comprometido_html`,
 1 AS `investigador_responsable`,
 1 AS `investigador_supervisor`,
 1 AS `user_id`,
 1 AS `nombre`,
 1 AS `apellido_paterno`,
 1 AS `apellido_materno`,
 1 AS `nombre_publicacion`,
 1 AS `fecha_nacimiento`,
 1 AS `fecha_nacimiento_html`,
 1 AS `genero`,
 1 AS `rut`,
 1 AS `rut_html`,
 1 AS `rut_dv`,
 1 AS `pasaporte`,
 1 AS `afiliacion`,
 1 AS `id_tipo_contrato`,
 1 AS `tipo_contrato`,
 1 AS `cumple_contrato`,
 1 AS `facultad_externa`,
 1 AS `id_tipo_contrato_facultad`,
 1 AS `id_universidad`,
 1 AS `universidad`,
 1 AS `direccion`,
 1 AS `comuna_id`,
 1 AS `comuna`,
 1 AS `region`,
 1 AS `pais_id`,
 1 AS `pais`,
 1 AS `telefono_personal`,
 1 AS `grado`,
 1 AS `grado_academico_honorarios`,
 1 AS `cargo_gestion`,
 1 AS `cargo`,
 1 AS `cargo_en`,
 1 AS `activo`,
 1 AS `telefono`,
 1 AS `url`,
 1 AS `imagen`,
 1 AS `email`,
 1 AS `email_alternativo`,
 1 AS `archivo_rut`,
 1 AS `cv`,
 1 AS `perfil`,
 1 AS `anexo`,
 1 AS `anexo_numero`,
 1 AS `fecha_actualizacion`,
 1 AS `archivo_pasaporte`,
 1 AS `archivo_cv`,
 1 AS `archivo_titulo`,
 1 AS `datos_honorarios_completo`,
 1 AS `fecha_creacion_html`,
 1 AS `fecha_termino_html`,
 1 AS `fecha_desde_html`,
 1 AS `fecha_hasta_html`,
 1 AS `fecha_convenio_html`,
 1 AS `fecha_firma_html`,
 1 AS `fecha_compromiso_html`,
 1 AS `fecha_aprobacion_html`,
 1 AS `centro_costo_codigo`,
 1 AS `centro_costo_proyecto`,
 1 AS `estado_convenio`,
 1 AS `numero_cuota`,
 1 AS `numero_agno`,
 1 AS `numero_mes`,
 1 AS `monto_cuota`,
 1 AS `monto_cuota_html`,
 1 AS `estado`,
 1 AS `fecha_pago`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_gestion_inventario_libros_libros`;
/*!50001 DROP VIEW IF EXISTS `view_gestion_inventario_libros_libros`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_gestion_inventario_libros_libros` AS SELECT 
 1 AS `id_libro`,
 1 AS `id_uchile`,
 1 AS `estado`,
 1 AS `numero_copias`,
 1 AS `autores`,
 1 AS `titulo`,
 1 AS `editorial`,
 1 AS `fecha_ingreso_base`,
 1 AS `fecha_ingreso_base_html`,
 1 AS `agno_publicacion`,
 1 AS `isbn`,
 1 AS `doi`,
 1 AS `tipo_libro`,
 1 AS `proyecto`,
 1 AS `investigador_acargo`,
 1 AS `palabra_clave`,
 1 AS `precio_unitario`,
 1 AS `precio_iva`,
 1 AS `precio_total`,
 1 AS `proveedor`,
 1 AS `orden_compra`,
 1 AS `factura`,
 1 AS `fecha_factura`,
 1 AS `fecha_factura_html`,
 1 AS `comentarios`,
 1 AS `fecha_actualizacion`,
 1 AS `fecha_actualizacion_html`,
 1 AS `id_centro_costo`,
 1 AS `centro_costo_codigo`,
 1 AS `centro_costo`,
 1 AS `activo_centro_costo`,
 1 AS `activo_html_centro_costo`,
 1 AS `usuario_centro_costo`,
 1 AS `nombre_responsable_centro_costo`,
 1 AS `apellido_paterno_responsable_centro_costo`,
 1 AS `usuario_responsable_centro_costo`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_gestion_inventario_libros_prestamos`;
/*!50001 DROP VIEW IF EXISTS `view_gestion_inventario_libros_prestamos`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_gestion_inventario_libros_prestamos` AS SELECT 
 1 AS `id_prestamo`,
 1 AS `fecha_prestamo`,
 1 AS `fecha_prestamo_html`,
 1 AS `fecha_solicitud`,
 1 AS `fecha_solicitud_html`,
 1 AS `fecha_devolucion_estimada`,
 1 AS `fecha_devolucion_estimada_html`,
 1 AS `fecha_devolucion`,
 1 AS `fecha_devolucion_html`,
 1 AS `estado`,
 1 AS `id_usuario_solicitante`,
 1 AS `usuario_solicitante`,
 1 AS `id_usuario_gestiona`,
 1 AS `usuario_gestiona`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_gestion_inventario_libros_prestamos_detalle`;
/*!50001 DROP VIEW IF EXISTS `view_gestion_inventario_libros_prestamos_detalle`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_gestion_inventario_libros_prestamos_detalle` AS SELECT 
 1 AS `id_prestamo`,
 1 AS `fecha_prestamo`,
 1 AS `fecha_prestamo_html`,
 1 AS `fecha_solicitud`,
 1 AS `fecha_solicitud_html`,
 1 AS `fecha_devolucion_estimada`,
 1 AS `fecha_devolucion_estimada_html`,
 1 AS `fecha_devolucion`,
 1 AS `fecha_devolucion_html`,
 1 AS `estado`,
 1 AS `id_usuario_solicitante`,
 1 AS `usuario_solicitante`,
 1 AS `id_usuario_gestiona`,
 1 AS `usuario_gestiona`,
 1 AS `archivo_prestamo_firmado`,
 1 AS `archivo_devolucion_firmado`,
 1 AS `comentario`,
 1 AS `id_libro`,
 1 AS `titulo_libro`,
 1 AS `autores_libro`,
 1 AS `editorial_libro`,
 1 AS `agno_publicacion_libro`,
 1 AS `tipo_libro`,
 1 AS `fecha_devolucion_estimada_libro`,
 1 AS `fecha_devolucion_estimada_libro_html`,
 1 AS `fecha_devolucion_libro`,
 1 AS `fecha_devolucion_libro_html`,
 1 AS `estado_libro`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_gestion_solicitudes_encargados`;
/*!50001 DROP VIEW IF EXISTS `view_gestion_solicitudes_encargados`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_gestion_solicitudes_encargados` AS SELECT 
 1 AS `id_tipo_estado`,
 1 AS `tipo_estado`,
 1 AS `funcionalidad`,
 1 AS `orden`,
 1 AS `id_usuario_responsable`,
 1 AS `user_id_responsable`,
 1 AS `estado_siguiente_aprobado`,
 1 AS `estado_siguiente_rechazado`,
 1 AS `email`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_gestion_solicitudes_estados`;
/*!50001 DROP VIEW IF EXISTS `view_gestion_solicitudes_estados`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_gestion_solicitudes_estados` AS SELECT 
 1 AS `id_solicitud`,
 1 AS `fecha_solicitud`,
 1 AS `id_persona_solicitante`,
 1 AS `id_persona_beneficiario`,
 1 AS `observacion`,
 1 AS `id_tipo_solicitudes`,
 1 AS `id_solicitud_estado`,
 1 AS `id_tipo_estado`,
 1 AS `tipo_estado`,
 1 AS `funcionalidad`,
 1 AS `orden`,
 1 AS `id_usuario_responsable`,
 1 AS `user_id_responsable`,
 1 AS `solicitantes`,
 1 AS `beneficiario`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_gestion_solicitudes_estados_historial`;
/*!50001 DROP VIEW IF EXISTS `view_gestion_solicitudes_estados_historial`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_gestion_solicitudes_estados_historial` AS SELECT 
 1 AS `id_solicitud`,
 1 AS `id_solicitud_estado`,
 1 AS `fecha`,
 1 AS `fecha_cierre`,
 1 AS `user_id_responsable`,
 1 AS `comentarios`,
 1 AS `id_tipo_estado`,
 1 AS `tipo_estado`,
 1 AS `funcionalidad`,
 1 AS `orden`,
 1 AS `id_usuario_responsable`,
 1 AS `tipo_solicitud`,
 1 AS `fecha_solicitud`,
 1 AS `id_persona_solicitante`,
 1 AS `id_persona_beneficiario`,
 1 AS `id_tipo_solicitudes`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_inscripcion_total`;
/*!50001 DROP VIEW IF EXISTS `view_inscripcion_total`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_inscripcion_total` AS SELECT 
 1 AS `total`,
 1 AS `tipo_inscripcion`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_inscripciones_diplomado_lenguaje_2022`;
/*!50001 DROP VIEW IF EXISTS `view_inscripciones_diplomado_lenguaje_2022`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_inscripciones_diplomado_lenguaje_2022` AS SELECT 
 1 AS `email`,
 1 AS `tipo_inscripcion`,
 1 AS `fecha_actualizacion`,
 1 AS `nombre`,
 1 AS `apellidos`,
 1 AS `edad`,
 1 AS `institucion`,
 1 AS `cargo`,
 1 AS `actividad`,
 1 AS `telefono_movil`,
 1 AS `ciudad`,
 1 AS `profesion`,
 1 AS `comentario`,
 1 AS `descargar_archivo_extra1`,
 1 AS `descargar_archivo_extra2`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_inscripciones_diplomado_mejoramiento_2022`;
/*!50001 DROP VIEW IF EXISTS `view_inscripciones_diplomado_mejoramiento_2022`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_inscripciones_diplomado_mejoramiento_2022` AS SELECT 
 1 AS `email`,
 1 AS `tipo_inscripcion`,
 1 AS `fecha_actualizacion`,
 1 AS `nombre`,
 1 AS `apellidos`,
 1 AS `edad`,
 1 AS `institucion`,
 1 AS `cargo`,
 1 AS `actividad`,
 1 AS `telefono_movil`,
 1 AS `ciudad`,
 1 AS `profesion`,
 1 AS `comentario`,
 1 AS `descargar_archivo_extra1`,
 1 AS `descargar_archivo_extra2`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_noticias_prensa_site`;
/*!50001 DROP VIEW IF EXISTS `view_noticias_prensa_site`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_noticias_prensa_site` AS SELECT 
 1 AS `id_prensa`,
 1 AS `titulo`,
 1 AS `bajada`,
 1 AS `url`,
 1 AS `pdf`,
 1 AS `fecha`,
 1 AS `medio`,
 1 AS `tema`,
 1 AS `tipo_medio`,
 1 AS `tipo_cobertura`,
 1 AS `investigador`,
 1 AS `tipo_aparicion`,
 1 AS `palabras_clave`,
 1 AS `palabra_clave`,
 1 AS `id_site`,
 1 AS `nombre_site`,
 1 AS `titulo_site`,
 1 AS `id_area`,
 1 AS `area`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_noticias_site`;
/*!50001 DROP VIEW IF EXISTS `view_noticias_site`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_noticias_site` AS SELECT 
 1 AS `id_noticia`,
 1 AS `fecha`,
 1 AS `titulo`,
 1 AS `bajada`,
 1 AS `noticia`,
 1 AS `autor`,
 1 AS `imagen`,
 1 AS `imagen_bajada`,
 1 AS `imagen2`,
 1 AS `imagen2_bajada`,
 1 AS `imagen3`,
 1 AS `imagen3_bajada`,
 1 AS `tipo`,
 1 AS `trabajo`,
 1 AS `investigaciones_ie`,
 1 AS `cursos_ie`,
 1 AS `tipo_curso`,
 1 AS `noticia_tipo`,
 1 AS `idioma`,
 1 AS `activo`,
 1 AS `destacado`,
 1 AS `destacado_forzado`,
 1 AS `tiene_galeria`,
 1 AS `palabra_clave`,
 1 AS `palabras_clave`,
 1 AS `time_ingreso`,
 1 AS `fecha_evento`,
 1 AS `lugar_evento`,
 1 AS `lugar_curso`,
 1 AS `calendario_curso`,
 1 AS `plan_estudio`,
 1 AS `requisitos`,
 1 AS `perfil_egreso`,
 1 AS `costo_evento`,
 1 AS `modalidad_evento`,
 1 AS `dirigido`,
 1 AS `certificado_evento`,
 1 AS `traduccion_evento`,
 1 AS `contacto_evento`,
 1 AS `web_externo_evento`,
 1 AS `inscripcion_evento`,
 1 AS `organizadores_evento`,
 1 AS `usuario`,
 1 AS `id_site`,
 1 AS `nombre_site`,
 1 AS `url_site`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_personas`;
/*!50001 DROP VIEW IF EXISTS `view_personas`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_personas` AS SELECT 
 1 AS `id_persona`,
 1 AS `user_id`,
 1 AS `nombre`,
 1 AS `apellido_paterno`,
 1 AS `apellido_materno`,
 1 AS `nombre_publicacion`,
 1 AS `fecha_nacimiento`,
 1 AS `fecha_nacimiento_html`,
 1 AS `genero`,
 1 AS `rut`,
 1 AS `rut_html`,
 1 AS `rut_dv`,
 1 AS `pasaporte`,
 1 AS `afiliacion`,
 1 AS `id_tipo_contrato`,
 1 AS `tipo_contrato`,
 1 AS `cumple_contrato`,
 1 AS `facultad_externa`,
 1 AS `id_tipo_contrato_facultad`,
 1 AS `id_universidad`,
 1 AS `universidad`,
 1 AS `direccion`,
 1 AS `comuna_id`,
 1 AS `comuna`,
 1 AS `region`,
 1 AS `pais_id`,
 1 AS `pais`,
 1 AS `telefono_personal`,
 1 AS `grado`,
 1 AS `grado_academico_honorarios`,
 1 AS `cargo_gestion`,
 1 AS `cargo`,
 1 AS `cargo_en`,
 1 AS `activo`,
 1 AS `telefono`,
 1 AS `url`,
 1 AS `imagen`,
 1 AS `email`,
 1 AS `email_alternativo`,
 1 AS `archivo_rut`,
 1 AS `cv`,
 1 AS `perfil`,
 1 AS `anexo`,
 1 AS `anexo_numero`,
 1 AS `fecha_actualizacion`,
 1 AS `archivo_pasaporte`,
 1 AS `archivo_cv`,
 1 AS `archivo_titulo`,
 1 AS `datos_honorarios_completo`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_personas_areas`;
/*!50001 DROP VIEW IF EXISTS `view_personas_areas`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_personas_areas` AS SELECT 
 1 AS `id_persona`,
 1 AS `user_id`,
 1 AS `nombre`,
 1 AS `apellido_paterno`,
 1 AS `apellido_materno`,
 1 AS `nombre_publicacion`,
 1 AS `afiliacion`,
 1 AS `id_universidad`,
 1 AS `grado`,
 1 AS `cargo`,
 1 AS `cargo_en`,
 1 AS `telefono`,
 1 AS `url`,
 1 AS `imagen`,
 1 AS `email`,
 1 AS `cv_archivo`,
 1 AS `cv`,
 1 AS `perfil`,
 1 AS `id_area`,
 1 AS `area`,
 1 AS `area_clave`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_personas_areas_simple`;
/*!50001 DROP VIEW IF EXISTS `view_personas_areas_simple`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_personas_areas_simple` AS SELECT 
 1 AS `id_persona`,
 1 AS `id_area`,
 1 AS `area`,
 1 AS `area_clave`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_personas_noticias`;
/*!50001 DROP VIEW IF EXISTS `view_personas_noticias`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_personas_noticias` AS SELECT 
 1 AS `id_noticia`,
 1 AS `id_persona`,
 1 AS `id_tipo_persona`,
 1 AS `tipo_persona`,
 1 AS `user_id`,
 1 AS `nombre`,
 1 AS `apellido_paterno`,
 1 AS `apellido_materno`,
 1 AS `nombre_publicacion`,
 1 AS `rut`,
 1 AS `rut_dv`,
 1 AS `pasaporte`,
 1 AS `afiliacion`,
 1 AS `id_tipo_contrato`,
 1 AS `facultad_externa`,
 1 AS `id_tipo_contrato_facultad`,
 1 AS `id_universidad`,
 1 AS `direccion`,
 1 AS `telefono_personal`,
 1 AS `grado`,
 1 AS `cargo_gestion`,
 1 AS `cargo`,
 1 AS `cargo_en`,
 1 AS `activo`,
 1 AS `telefono`,
 1 AS `url`,
 1 AS `imagen`,
 1 AS `email`,
 1 AS `archivo_rut`,
 1 AS `cv`,
 1 AS `perfil`,
 1 AS `anexo`,
 1 AS `anexo_numero`,
 1 AS `fecha`,
 1 AS `archivo_pasaporte`,
 1 AS `archivo_cv`,
 1 AS `archivo_titulo`,
 1 AS `orden`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_personas_site`;
/*!50001 DROP VIEW IF EXISTS `view_personas_site`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_personas_site` AS SELECT 
 1 AS `id_persona`,
 1 AS `user_id`,
 1 AS `nombre`,
 1 AS `apellido_paterno`,
 1 AS `apellido_materno`,
 1 AS `nombre_publicacion`,
 1 AS `rut`,
 1 AS `rut_dv`,
 1 AS `pasaporte`,
 1 AS `afiliacion`,
 1 AS `id_tipo_contrato`,
 1 AS `facultad_externa`,
 1 AS `id_tipo_contrato_facultad`,
 1 AS `id_universidad`,
 1 AS `direccion`,
 1 AS `telefono_personal`,
 1 AS `grado`,
 1 AS `cargo_gestion`,
 1 AS `cargo`,
 1 AS `cargo_en`,
 1 AS `activo`,
 1 AS `telefono`,
 1 AS `url`,
 1 AS `imagen`,
 1 AS `email`,
 1 AS `archivo_rut`,
 1 AS `cv`,
 1 AS `perfil`,
 1 AS `anexo`,
 1 AS `anexo_numero`,
 1 AS `fecha`,
 1 AS `archivo_pasaporte`,
 1 AS `archivo_cv`,
 1 AS `archivo_titulo`,
 1 AS `id_site`,
 1 AS `nombre_site`,
 1 AS `cargo_site`,
 1 AS `orden_site`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_personas_site_tipo`;
/*!50001 DROP VIEW IF EXISTS `view_personas_site_tipo`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_personas_site_tipo` AS SELECT 
 1 AS `id_persona`,
 1 AS `user_id`,
 1 AS `nombre`,
 1 AS `apellido_paterno`,
 1 AS `apellido_materno`,
 1 AS `nombre_publicacion`,
 1 AS `afiliacion`,
 1 AS `id_universidad`,
 1 AS `grado`,
 1 AS `cargo`,
 1 AS `cargo_en`,
 1 AS `telefono`,
 1 AS `url`,
 1 AS `imagen`,
 1 AS `email`,
 1 AS `cv_archivo`,
 1 AS `cv`,
 1 AS `perfil`,
 1 AS `id_tipo`,
 1 AS `tipo`,
 1 AS `id_site`,
 1 AS `nombre_site`,
 1 AS `cargo_site`,
 1 AS `orden_site`,
 1 AS `anexo`,
 1 AS `anexo_numero`,
 1 AS `activo`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_personas_tipo`;
/*!50001 DROP VIEW IF EXISTS `view_personas_tipo`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_personas_tipo` AS SELECT 
 1 AS `id_persona`,
 1 AS `user_id`,
 1 AS `nombre`,
 1 AS `apellido_paterno`,
 1 AS `apellido_materno`,
 1 AS `nombre_publicacion`,
 1 AS `afiliacion`,
 1 AS `id_universidad`,
 1 AS `grado`,
 1 AS `cargo`,
 1 AS `cargo_en`,
 1 AS `telefono`,
 1 AS `url`,
 1 AS `imagen`,
 1 AS `email`,
 1 AS `cv_archivo`,
 1 AS `cv`,
 1 AS `perfil`,
 1 AS `id_tipo`,
 1 AS `tipo`,
 1 AS `id_site`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_postulaciones`;
/*!50001 DROP VIEW IF EXISTS `view_postulaciones`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_postulaciones` AS SELECT 
 1 AS `email`,
 1 AS `doctorado_postulacion`,
 1 AS `nombre`,
 1 AS `apellidos`,
 1 AS `campo_investigacion`,
 1 AS `institucion`,
 1 AS `agno`,
 1 AS `informacion_adicional`,
 1 AS `descargar_archivo_motivacion`,
 1 AS `descargar_archivo_propuesta`,
 1 AS `descargar_archivo_cv`,
 1 AS `descargar_archivo_titulo`,
 1 AS `descargar_archivo_carta_recomendacion1`,
 1 AS `carta_recomendacion1_persona`,
 1 AS `carta_recomendacion1_email_persona`,
 1 AS `carta_recomendacion1_afiliacion_persona`,
 1 AS `descargar_archivo_carta_recomendacion2`,
 1 AS `carta_recomendacion2_persona`,
 1 AS `carta_recomendacion2_email_persona`,
 1 AS `carta_recomendacion2_afiliacion_persona`,
 1 AS `descargar_archivo_carta_recomendacion3`,
 1 AS `carta_recomendacion3_persona`,
 1 AS `carta_recomendacion3_email_persona`,
 1 AS `carta_recomendacion3_afiliacion_persona`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_profesores_academicos_noticias`;
/*!50001 DROP VIEW IF EXISTS `view_profesores_academicos_noticias`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_profesores_academicos_noticias` AS SELECT 
 1 AS `id_noticia`,
 1 AS `id_persona`,
 1 AS `user_id`,
 1 AS `nombrePA`,
 1 AS `apellido_paternoPA`,
 1 AS `apellido_maternoPA`,
 1 AS `nombre_publicacionPA`,
 1 AS `rutPA`,
 1 AS `rut_dvPA`,
 1 AS `pasaportePA`,
 1 AS `afiliacionPA`,
 1 AS `id_tipo_contratoPA`,
 1 AS `facultad_externaPA`,
 1 AS `id_tipo_contrato_facultadPA`,
 1 AS `id_universidad`,
 1 AS `direccionPA`,
 1 AS `telefono_personalPA`,
 1 AS `gradoPA`,
 1 AS `cargo_gestionPA`,
 1 AS `cargoPA`,
 1 AS `cargo_enPA`,
 1 AS `activoPA`,
 1 AS `telefonoPA`,
 1 AS `urlPA`,
 1 AS `imagenPA`,
 1 AS `emailPA`,
 1 AS `archivo_rutPA`,
 1 AS `cv`,
 1 AS `perfilPA`,
 1 AS `anexoP`,
 1 AS `anexo_numeroPA`,
 1 AS `fechaPA`,
 1 AS `archivo_pasaportePA`,
 1 AS `archivo_cvPA`,
 1 AS `archivo_tituloPA`,
 1 AS `orden`,
 1 AS `area_aca`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_profesores_comite_noticias`;
/*!50001 DROP VIEW IF EXISTS `view_profesores_comite_noticias`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_profesores_comite_noticias` AS SELECT 
 1 AS `id_noticia`,
 1 AS `id_persona`,
 1 AS `user_id`,
 1 AS `nombre`,
 1 AS `apellido_paterno`,
 1 AS `apellido_materno`,
 1 AS `nombre_publicacion`,
 1 AS `rut`,
 1 AS `rut_dv`,
 1 AS `pasaporte`,
 1 AS `afiliacion`,
 1 AS `id_tipo_contrato`,
 1 AS `facultad_externa`,
 1 AS `id_tipo_contrato_facultad`,
 1 AS `id_universidad`,
 1 AS `direccion`,
 1 AS `telefono_personal`,
 1 AS `grado`,
 1 AS `cargo_gestion`,
 1 AS `cargo`,
 1 AS `cargo_en`,
 1 AS `activo`,
 1 AS `telefono`,
 1 AS `url`,
 1 AS `imagen`,
 1 AS `email`,
 1 AS `archivo_rut`,
 1 AS `cv`,
 1 AS `perfil`,
 1 AS `anexo`,
 1 AS `anexo_numero`,
 1 AS `fecha`,
 1 AS `archivo_pasaporte`,
 1 AS `archivo_cv`,
 1 AS `archivo_titulo`,
 1 AS `orden`,
 1 AS `area_es`,
 1 AS `tipo`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_profesores_comite_site`;
/*!50001 DROP VIEW IF EXISTS `view_profesores_comite_site`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_profesores_comite_site` AS SELECT 
 1 AS `id_persona`,
 1 AS `user_id`,
 1 AS `nombre`,
 1 AS `apellido_paterno`,
 1 AS `apellido_materno`,
 1 AS `nombre_publicacion`,
 1 AS `rut`,
 1 AS `rut_dv`,
 1 AS `pasaporte`,
 1 AS `afiliacion`,
 1 AS `id_tipo_contrato`,
 1 AS `facultad_externa`,
 1 AS `id_tipo_contrato_facultad`,
 1 AS `id_universidad`,
 1 AS `direccion`,
 1 AS `telefono_personal`,
 1 AS `grado`,
 1 AS `cargo_gestion`,
 1 AS `cargo`,
 1 AS `cargo_en`,
 1 AS `activo`,
 1 AS `telefono`,
 1 AS `url`,
 1 AS `imagen`,
 1 AS `email`,
 1 AS `archivo_rut`,
 1 AS `cv`,
 1 AS `perfil`,
 1 AS `anexo`,
 1 AS `anexo_numero`,
 1 AS `fecha`,
 1 AS `archivo_pasaporte`,
 1 AS `archivo_cv`,
 1 AS `archivo_titulo`,
 1 AS `id_site`,
 1 AS `nombre_site`,
 1 AS `cargo_site`,
 1 AS `orden_site`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_profesores_noticias`;
/*!50001 DROP VIEW IF EXISTS `view_profesores_noticias`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_profesores_noticias` AS SELECT 
 1 AS `id_noticia`,
 1 AS `id_persona`,
 1 AS `user_id`,
 1 AS `nombreP`,
 1 AS `apellido_paternoP`,
 1 AS `apellido_maternoP`,
 1 AS `nombre_publicacionP`,
 1 AS `rutP`,
 1 AS `rut_dvP`,
 1 AS `pasaporteP`,
 1 AS `afiliacionP`,
 1 AS `id_tipo_contratoP`,
 1 AS `facultad_externaP`,
 1 AS `id_tipo_contrato_facultadP`,
 1 AS `id_universidad`,
 1 AS `direccionP`,
 1 AS `telefono_personalP`,
 1 AS `gradoP`,
 1 AS `cargo_gestionP`,
 1 AS `cargoP`,
 1 AS `cargo_enP`,
 1 AS `activoP`,
 1 AS `telefonoP`,
 1 AS `urlP`,
 1 AS `imagenP`,
 1 AS `emailP`,
 1 AS `archivo_rutP`,
 1 AS `cv`,
 1 AS `perfilP`,
 1 AS `anexoP`,
 1 AS `anexo_numeroP`,
 1 AS `fechaP`,
 1 AS `archivo_pasaporteP`,
 1 AS `archivo_cvP`,
 1 AS `archivo_tituloP`,
 1 AS `orden`,
 1 AS `area_pro`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_profesores_visitantes_noticias`;
/*!50001 DROP VIEW IF EXISTS `view_profesores_visitantes_noticias`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_profesores_visitantes_noticias` AS SELECT 
 1 AS `id_noticia`,
 1 AS `id_persona`,
 1 AS `user_id`,
 1 AS `nombrePV`,
 1 AS `apellido_paternoPV`,
 1 AS `apellido_maternoPV`,
 1 AS `nombre_publicacionPV`,
 1 AS `rutPV`,
 1 AS `rut_dvPV`,
 1 AS `pasaportePV`,
 1 AS `afiliacionPV`,
 1 AS `id_tipo_contratoPV`,
 1 AS `facultad_externaPV`,
 1 AS `id_tipo_contrato_facultadPV`,
 1 AS `id_universidad`,
 1 AS `direccionPV`,
 1 AS `telefono_personalPV`,
 1 AS `gradoPV`,
 1 AS `cargo_gestionPV`,
 1 AS `cargoPV`,
 1 AS `cargo_enPV`,
 1 AS `activoPV`,
 1 AS `telefonoPV`,
 1 AS `urlPV`,
 1 AS `imagenPV`,
 1 AS `emailPV`,
 1 AS `archivo_rutPV`,
 1 AS `cv`,
 1 AS `perfilPV`,
 1 AS `anexoP`,
 1 AS `anexo_numeroPV`,
 1 AS `fechaPV`,
 1 AS `archivo_pasaportePV`,
 1 AS `archivo_cvPV`,
 1 AS `archivo_tituloPV`,
 1 AS `orden`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_proyecto_detalle`;
/*!50001 DROP VIEW IF EXISTS `view_proyecto_detalle`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_proyecto_detalle` AS SELECT 
 1 AS `id_proyecto`,
 1 AS `activo`,
 1 AS `proyecto`,
 1 AS `proyecto_en`,
 1 AS `codigo`,
 1 AS `id_tipo`,
 1 AS `id_tipo_area_proyecto`,
 1 AS `agno_inicio`,
 1 AS `mes_inicio`,
 1 AS `url`,
 1 AS `antecedentes`,
 1 AS `objetivos`,
 1 AS `metodologia`,
 1 AS `periodo`,
 1 AS `financiamiento`,
 1 AS `productos`,
 1 AS `mandante`,
 1 AS `cooperacion_nacional`,
 1 AS `cooperacion_internacional`,
 1 AS `tipo_proyecto`,
 1 AS `tipo_area_proyecto`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_proyecto_tipo`;
/*!50001 DROP VIEW IF EXISTS `view_proyecto_tipo`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_proyecto_tipo` AS SELECT 
 1 AS `id_proyecto`,
 1 AS `activo`,
 1 AS `proyecto`,
 1 AS `proyecto_en`,
 1 AS `codigo`,
 1 AS `id_tipo`,
 1 AS `id_tipo_area_proyecto`,
 1 AS `agno_inicio`,
 1 AS `url`,
 1 AS `antecedentes`,
 1 AS `objetivos`,
 1 AS `metodologia`,
 1 AS `periodo`,
 1 AS `financiamiento`,
 1 AS `productos`,
 1 AS `mandante`,
 1 AS `cooperacion_nacional`,
 1 AS `cooperacion_internacional`,
 1 AS `tipo_proyecto`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_proyecto_tipo_area`;
/*!50001 DROP VIEW IF EXISTS `view_proyecto_tipo_area`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_proyecto_tipo_area` AS SELECT 
 1 AS `id_proyecto`,
 1 AS `activo`,
 1 AS `proyecto`,
 1 AS `proyecto_en`,
 1 AS `codigo`,
 1 AS `id_tipo`,
 1 AS `id_tipo_area_proyecto`,
 1 AS `agno_inicio`,
 1 AS `mes_inicio`,
 1 AS `url`,
 1 AS `antecedentes`,
 1 AS `objetivos`,
 1 AS `metodologia`,
 1 AS `periodo`,
 1 AS `financiamiento`,
 1 AS `productos`,
 1 AS `mandante`,
 1 AS `cooperacion_nacional`,
 1 AS `cooperacion_internacional`,
 1 AS `tipo_area_proyecto`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_proyectos_personas`;
/*!50001 DROP VIEW IF EXISTS `view_proyectos_personas`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_proyectos_personas` AS SELECT 
 1 AS `id_proyecto`,
 1 AS `proyecto`,
 1 AS `id_persona`,
 1 AS `nombre`,
 1 AS `apellido_paterno`,
 1 AS `apellido_materno`,
 1 AS `cargo`,
 1 AS `orden`,
 1 AS `nombre_extra`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_proyectos_site`;
/*!50001 DROP VIEW IF EXISTS `view_proyectos_site`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_proyectos_site` AS SELECT 
 1 AS `id_proyecto`,
 1 AS `activo`,
 1 AS `proyecto`,
 1 AS `proyecto_en`,
 1 AS `codigo`,
 1 AS `imagen`,
 1 AS `id_tipo`,
 1 AS `id_tipo_area_proyecto`,
 1 AS `agno_inicio`,
 1 AS `mes_inicio`,
 1 AS `agno_termino`,
 1 AS `url`,
 1 AS `antecedentes`,
 1 AS `objetivos`,
 1 AS `metodologia`,
 1 AS `periodo`,
 1 AS `financiamiento`,
 1 AS `productos`,
 1 AS `palabras_clave`,
 1 AS `mandante`,
 1 AS `cooperacion_nacional`,
 1 AS `cooperacion_internacional`,
 1 AS `seleccionado_area`,
 1 AS `id_site`,
 1 AS `nombre_site`,
 1 AS `vigente`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_publicacion_persona`;
/*!50001 DROP VIEW IF EXISTS `view_publicacion_persona`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_publicacion_persona` AS SELECT 
 1 AS `id_publicaciones`,
 1 AS `id_persona`,
 1 AS `persona_nombre`,
 1 AS `orden`,
 1 AS `nombre`,
 1 AS `apellido_paterno`,
 1 AS `apellido_materno`,
 1 AS `nombre_publicacion`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_publicaciones_area`;
/*!50001 DROP VIEW IF EXISTS `view_publicaciones_area`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_publicaciones_area` AS SELECT 
 1 AS `id_publicaciones`,
 1 AS `fecha`,
 1 AS `titulo`,
 1 AS `resumen`,
 1 AS `titulo_en`,
 1 AS `doi`,
 1 AS `isi`,
 1 AS `mes`,
 1 AS `mes_numero`,
 1 AS `agno`,
 1 AS `texto`,
 1 AS `documento`,
 1 AS `link`,
 1 AS `numero`,
 1 AS `id_tipo`,
 1 AS `id_area`,
 1 AS `activo`,
 1 AS `destacado`,
 1 AS `ver_detalle`,
 1 AS `area`,
 1 AS `area_en`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_publicaciones_detalle`;
/*!50001 DROP VIEW IF EXISTS `view_publicaciones_detalle`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_publicaciones_detalle` AS SELECT 
 1 AS `id_publicaciones`,
 1 AS `fecha`,
 1 AS `titulo`,
 1 AS `resumen`,
 1 AS `titulo_en`,
 1 AS `doi`,
 1 AS `isi`,
 1 AS `mes`,
 1 AS `mes_numero`,
 1 AS `agno`,
 1 AS `texto`,
 1 AS `documento`,
 1 AS `link`,
 1 AS `numero`,
 1 AS `id_tipo`,
 1 AS `id_area`,
 1 AS `activo`,
 1 AS `destacado`,
 1 AS `ver_detalle`,
 1 AS `tipo_publicacion`,
 1 AS `area`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_publicaciones_persona`;
/*!50001 DROP VIEW IF EXISTS `view_publicaciones_persona`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_publicaciones_persona` AS SELECT 
 1 AS `id_publicaciones`,
 1 AS `id_persona`,
 1 AS `persona_nombre`,
 1 AS `orden`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_publicaciones_site`;
/*!50001 DROP VIEW IF EXISTS `view_publicaciones_site`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_publicaciones_site` AS SELECT 
 1 AS `id_publicaciones`,
 1 AS `fecha`,
 1 AS `titulo`,
 1 AS `resumen`,
 1 AS `titulo_en`,
 1 AS `doi`,
 1 AS `isi`,
 1 AS `mes`,
 1 AS `mes_numero`,
 1 AS `agno`,
 1 AS `factor_Q`,
 1 AS `cooperacion_internacional`,
 1 AS `cooperacion_nacional`,
 1 AS `texto`,
 1 AS `documento`,
 1 AS `documento_publico`,
 1 AS `link`,
 1 AS `numero`,
 1 AS `id_tipo`,
 1 AS `id_area`,
 1 AS `activo`,
 1 AS `destacado`,
 1 AS `ver_detalle`,
 1 AS `seleccionado`,
 1 AS `palabras_clave`,
 1 AS `bib_palabra_clave`,
 1 AS `bib_ubicacion`,
 1 AS `bib_ciudad`,
 1 AS `bib_pais`,
 1 AS `bib_edicion`,
 1 AS `bib_editor`,
 1 AS `bib_editorial`,
 1 AS `bib_institucion`,
 1 AS `bib_revista`,
 1 AS `bib_libro`,
 1 AS `bib_capitulo`,
 1 AS `bib_numero`,
 1 AS `bib_paginas`,
 1 AS `bib_series`,
 1 AS `bib_volume`,
 1 AS `bib_escuela`,
 1 AS `bib_tipo_estudio`,
 1 AS `bib_respaldo_tipo_ingreso`,
 1 AS `bib_respaldo_comentario`,
 1 AS `bib_respaldo_autor`,
 1 AS `bib_respaldo_archivo`,
 1 AS `id_site`,
 1 AS `nombre_site`,
 1 AS `titulo_site`,
 1 AS `url_site`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_publicaciones_tipo`;
/*!50001 DROP VIEW IF EXISTS `view_publicaciones_tipo`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_publicaciones_tipo` AS SELECT 
 1 AS `id_publicaciones`,
 1 AS `fecha`,
 1 AS `titulo`,
 1 AS `resumen`,
 1 AS `titulo_en`,
 1 AS `doi`,
 1 AS `isi`,
 1 AS `mes`,
 1 AS `mes_numero`,
 1 AS `agno`,
 1 AS `texto`,
 1 AS `documento`,
 1 AS `link`,
 1 AS `numero`,
 1 AS `id_tipo`,
 1 AS `id_area`,
 1 AS `activo`,
 1 AS `destacado`,
 1 AS `ver_detalle`,
 1 AS `tipo_publicacion`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_recursos_site`;
/*!50001 DROP VIEW IF EXISTS `view_recursos_site`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_recursos_site` AS SELECT 
 1 AS `id_recurso`,
 1 AS `fecha`,
 1 AS `titulo`,
 1 AS `bajada`,
 1 AS `descripcion`,
 1 AS `autor`,
 1 AS `editorial`,
 1 AS `paginas`,
 1 AS `isbn`,
 1 AS `extra`,
 1 AS `imagen`,
 1 AS `id_tipo`,
 1 AS `tipo`,
 1 AS `tipo_orden`,
 1 AS `agno`,
 1 AS `archivo`,
 1 AS `video`,
 1 AS `video_lista`,
 1 AS `libro_digital`,
 1 AS `iframe`,
 1 AS `link_externo`,
 1 AS `link_externo_texto`,
 1 AS `idioma`,
 1 AS `activo`,
 1 AS `destacado`,
 1 AS `id_tipo_estructura`,
 1 AS `tipo_estructura`,
 1 AS `tipo_estructura_orden`,
 1 AS `tipo_estructura_opcion_site`,
 1 AS `opcion_site`,
 1 AS `palabras_clave`,
 1 AS `time_ingreso`,
 1 AS `usuario`,
 1 AS `id_site`,
 1 AS `nombre_site`,
 1 AS `titulo_site`,
 1 AS `url_site`,
 1 AS `tipo_estructura_combinada`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_regiones_comunas`;
/*!50001 DROP VIEW IF EXISTS `view_regiones_comunas`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_regiones_comunas` AS SELECT 
 1 AS `comuna_id`,
 1 AS `comuna`,
 1 AS `orden_comuna`,
 1 AS `region_id`,
 1 AS `region`,
 1 AS `orden_region`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_site_eventos_informe`;
/*!50001 DROP VIEW IF EXISTS `view_site_eventos_informe`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_site_eventos_informe` AS SELECT 
 1 AS `id_evento`,
 1 AS `id_noticia`,
 1 AS `id_inscripcion`,
 1 AS `fecha_inicio`,
 1 AS `fecha_termino`,
 1 AS `info_completa`,
 1 AS `nombre`,
 1 AS `tipo_evento`,
 1 AS `total_inscritos_presencial`,
 1 AS `total_inscritos_online`,
 1 AS `total_asistencia`,
 1 AS `institucion_co_organizadora`,
 1 AS `link_inscripcion`,
 1 AS `inscripcion_opcion_menu`,
 1 AS `inscripcion_fecha_cierre`,
 1 AS `inscripcion_cupos_maximo`,
 1 AS `email`,
 1 AS `ubicacion`,
 1 AS `ubicacion_email`,
 1 AS `ubicacion_email_online`,
 1 AS `date_texto`,
 1 AS `date_texto_email`,
 1 AS `programa`,
 1 AS `costo_texto_extras`,
 1 AS `listas`,
 1 AS `logos`,
 1 AS `tipo_formulario_confirmacion`,
 1 AS `mensaje_extra_notificacion`,
 1 AS `link_online`,
 1 AS `certificado_encabezado_fech`,
 1 AS `certificado_fec`,
 1 AS `certificado_horas`,
 1 AS `certificado_ubicacion`,
 1 AS `certificado_organizadores`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_201804_argumentacion_oral_escrita`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_201804_argumentacion_oral_escrita`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_201804_argumentacion_oral_escrita` AS SELECT 
 1 AS `fecha postulación`,
 1 AS `nombre`,
 1 AS `apellidos`,
 1 AS `genero`,
 1 AS `correo electrónico`,
 1 AS `comuna residencia`,
 1 AS `ciudad residencia`,
 1 AS `region residencia`,
 1 AS `telefono contacto`,
 1 AS `actividad`,
 1 AS `profesion`,
 1 AS `institución donde trabaja`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_201804_seminario_juego_infancia_priv`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_201804_seminario_juego_infancia_priv`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_201804_seminario_juego_infancia_priv` AS SELECT 
 1 AS `fecha postulación`,
 1 AS `nombre`,
 1 AS `apellidos`,
 1 AS `genero`,
 1 AS `correo electrónico`,
 1 AS `comuna residencia`,
 1 AS `ciudad residencia`,
 1 AS `region residencia`,
 1 AS `telefono contacto`,
 1 AS `actividad`,
 1 AS `profesion`,
 1 AS `institución donde trabaja`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_202204_concurso_postdoc`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_202204_concurso_postdoc`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_202204_concurso_postdoc` AS SELECT 
 1 AS `fecha postulación`,
 1 AS `correo electrónico`,
 1 AS `nombre`,
 1 AS `apellido_paterno`,
 1 AS `apellido_materno`,
 1 AS `rut-pasaporte`,
 1 AS `fecha nacimiento`,
 1 AS `genero`,
 1 AS `correo electrónico alternativo`,
 1 AS `telefono contacto`,
 1 AS `direccion`,
 1 AS `pais`,
 1 AS `profesion`,
 1 AS `institución donde trabaja`,
 1 AS `area postulacion`,
 1 AS `archivo_cv`,
 1 AS `archivo titulos y grados (1)`,
 1 AS `carta recomendacion (1)`,
 1 AS `carta recomendacion (2)`,
 1 AS `proyecto`,
 1 AS `carta de intención`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_202206_concurso_academicos`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_202206_concurso_academicos`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_202206_concurso_academicos` AS SELECT 
 1 AS `fecha postulación`,
 1 AS `nombre`,
 1 AS `apellido_paterno`,
 1 AS `apellido_materno`,
 1 AS `rut`,
 1 AS `rut_digito`,
 1 AS `fecha nacimiento`,
 1 AS `genero`,
 1 AS `correo electrónico`,
 1 AS `correo electrónico alternativo`,
 1 AS `dirección residencia`,
 1 AS `ciudad residencia`,
 1 AS `telefono contacto`,
 1 AS `profesion`,
 1 AS `archivo_cv`,
 1 AS `archivo titulos y grados (1)`,
 1 AS `archivo declaración inhabilidades`,
 1 AS `archivo declaracion cumplimiento b) y c)`,
 1 AS `archivo declaracion salud`,
 1 AS `carta motivacion`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_202208_taller_constitucion`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_202208_taller_constitucion`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_202208_taller_constitucion` AS SELECT 
 1 AS `fecha inscripcion`,
 1 AS `email`,
 1 AS `nombre`,
 1 AS `apellido_paterno`,
 1 AS `actividad`,
 1 AS `profesion`,
 1 AS `institución`,
 1 AS `Nivel que enseña`,
 1 AS `Intereses`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_202209_concurso_postdoc`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_202209_concurso_postdoc`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_202209_concurso_postdoc` AS SELECT 
 1 AS `fecha postulación`,
 1 AS `correo electrónico`,
 1 AS `nombre`,
 1 AS `apellido_paterno`,
 1 AS `rut-pasaporte`,
 1 AS `fecha nacimiento`,
 1 AS `genero`,
 1 AS `correo electrónico alternativo`,
 1 AS `telefono contacto`,
 1 AS `direccion`,
 1 AS `pais`,
 1 AS `profesion`,
 1 AS `institución donde trabaja`,
 1 AS `area postulacion`,
 1 AS `archivo_cv`,
 1 AS `archivo titulos y grados (1)`,
 1 AS `carta recomendacion (1)`,
 1 AS `carta recomendacion (2)`,
 1 AS `proyecto`,
 1 AS `carta de intención`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_2022_concurso_academicos`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_2022_concurso_academicos`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_2022_concurso_academicos` AS SELECT 
 1 AS `fecha postulación`,
 1 AS `nombre`,
 1 AS `apellido_paterno`,
 1 AS `apellido_materno`,
 1 AS `rut`,
 1 AS `rut_digito`,
 1 AS `fecha nacimiento`,
 1 AS `genero`,
 1 AS `correo electrónico`,
 1 AS `correo electrónico alternativo`,
 1 AS `dirección residencia`,
 1 AS `ciudad residencia`,
 1 AS `telefono contacto`,
 1 AS `profesion`,
 1 AS `archivo_cv`,
 1 AS `archivo titulos y grados (1)`,
 1 AS `archivo declaración inhabilidades`,
 1 AS `archivo declaracion cumplimiento b) y c)`,
 1 AS `archivo declaracion salud`,
 1 AS `carta motivacion`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_20231130_postdoctorado`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_20231130_postdoctorado`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_20231130_postdoctorado` AS SELECT 
 1 AS `fecha postulación`,
 1 AS `correo electrónico`,
 1 AS `nombre`,
 1 AS `apellido_paterno`,
 1 AS `rut-pasaporte`,
 1 AS `fecha nacimiento`,
 1 AS `genero`,
 1 AS `correo electrónico alternativo`,
 1 AS `telefono contacto`,
 1 AS `direccion`,
 1 AS `pais`,
 1 AS `profesion`,
 1 AS `institución donde trabaja`,
 1 AS `area postulacion`,
 1 AS `archivo_cv`,
 1 AS `archivo titulos y grados (1)`,
 1 AS `proyecto`,
 1 AS `carta recomendacion (1)`,
 1 AS `carta recomendacion (2)`,
 1 AS `carta de intención`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_202311_taller_arpa_ensenanza_matematica`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_202311_taller_arpa_ensenanza_matematica`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_202311_taller_arpa_ensenanza_matematica` AS SELECT 
 1 AS `email`,
 1 AS `fecha_actualizacion`,
 1 AS `nombre`,
 1 AS `apellidos`,
 1 AS `institucion`,
 1 AS `actividad`,
 1 AS `profesion`,
 1 AS `donde_enseña`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_ciae_anexos`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_ciae_anexos`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_ciae_anexos` AS SELECT 
 1 AS `Apellidos`,
 1 AS `Nombre`,
 1 AS `Email`,
 1 AS `Anexo`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_diplomado_investigacion_2022`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_diplomado_investigacion_2022`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_diplomado_investigacion_2022` AS SELECT 
 1 AS `fecha postulación`,
 1 AS `nombre`,
 1 AS `apellido_paterno`,
 1 AS `apellido_materno`,
 1 AS `rut`,
 1 AS `rut_digito`,
 1 AS `fecha nacimiento`,
 1 AS `genero`,
 1 AS `correo electrónico`,
 1 AS `correo electrónico alternativo`,
 1 AS `dirección residencia`,
 1 AS `comuna residencia`,
 1 AS `ciudad residencia`,
 1 AS `telefono contacto`,
 1 AS `actividad`,
 1 AS `profesion`,
 1 AS `institución donde trabaja`,
 1 AS `telefono institución`,
 1 AS `sitio web institución`,
 1 AS `años de servicio`,
 1 AS `dependencia`,
 1 AS `archivo_cv`,
 1 AS `archivo titulos y grados (1)`,
 1 AS `carta de intención`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_diplomado_lenguaje_2019`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_diplomado_lenguaje_2019`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_diplomado_lenguaje_2019` AS SELECT 
 1 AS `fecha postulación`,
 1 AS `nombre`,
 1 AS `apellidos`,
 1 AS `rut`,
 1 AS `rut_digito`,
 1 AS `fecha nacimiento`,
 1 AS `genero`,
 1 AS `correo electrónico`,
 1 AS `correo electrónico alternativo`,
 1 AS `comuna residencia`,
 1 AS `ciudad residencia`,
 1 AS `region residencia`,
 1 AS `telefono contacto`,
 1 AS `actividad`,
 1 AS `profesion`,
 1 AS `institución donde trabaja`,
 1 AS `dirección institución`,
 1 AS `telefono institución`,
 1 AS `sitio web institución`,
 1 AS `años de servicio`,
 1 AS `archivo cv`,
 1 AS `archivo titulos y grados`,
 1 AS `archivo liquidaciones`,
 1 AS `cert_participa_curso`,
 1 AS `carta de intención`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_diplomado_lenguaje_2020`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_diplomado_lenguaje_2020`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_diplomado_lenguaje_2020` AS SELECT 
 1 AS `fecha postulación`,
 1 AS `nombre`,
 1 AS `apellidos`,
 1 AS `rut`,
 1 AS `rut_digito`,
 1 AS `fecha nacimiento`,
 1 AS `genero`,
 1 AS `correo electrónico`,
 1 AS `correo electrónico alternativo`,
 1 AS `domicilio`,
 1 AS `ciudad residencia`,
 1 AS `region residencia`,
 1 AS `telefono contacto`,
 1 AS `actividad`,
 1 AS `profesion`,
 1 AS `institución donde trabaja`,
 1 AS `telefono institución`,
 1 AS `sitio web institución`,
 1 AS `años de servicio`,
 1 AS `archivo cv`,
 1 AS `archivo titulos y grados`,
 1 AS `archivo liquidaciones`,
 1 AS `cert_participa_curso`,
 1 AS `carta de intención`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_diplomado_lenguaje_2021`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_diplomado_lenguaje_2021`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_diplomado_lenguaje_2021` AS SELECT 
 1 AS `fecha postulación`,
 1 AS `nombre`,
 1 AS `apellidos`,
 1 AS `rut`,
 1 AS `rut_digito`,
 1 AS `fecha nacimiento`,
 1 AS `genero`,
 1 AS `correo electrónico`,
 1 AS `correo electrónico alternativo`,
 1 AS `comuna residencia`,
 1 AS `ciudad residencia`,
 1 AS `region residencia`,
 1 AS `telefono contacto`,
 1 AS `actividad`,
 1 AS `profesion`,
 1 AS `institución donde trabaja`,
 1 AS `dirección institución`,
 1 AS `telefono institución`,
 1 AS `sitio web institución`,
 1 AS `años de servicio`,
 1 AS `archivo_cv`,
 1 AS `archivo titulos y grados (1)`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_diplomado_lenguaje_2022`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_diplomado_lenguaje_2022`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_diplomado_lenguaje_2022` AS SELECT 
 1 AS `fecha postulación`,
 1 AS `nombre`,
 1 AS `apellido_paterno`,
 1 AS `apellido_materno`,
 1 AS `rut`,
 1 AS `rut_digito`,
 1 AS `fecha nacimiento`,
 1 AS `genero`,
 1 AS `correo electrónico`,
 1 AS `correo electrónico alternativo`,
 1 AS `dirección residencia`,
 1 AS `comuna residencia`,
 1 AS `ciudad residencia`,
 1 AS `telefono contacto`,
 1 AS `actividad`,
 1 AS `profesion`,
 1 AS `institución donde trabaja`,
 1 AS `telefono institución`,
 1 AS `sitio web institución`,
 1 AS `años de servicio`,
 1 AS `dependencia`,
 1 AS `archivo_cv`,
 1 AS `archivo titulos y grados (1)`,
 1 AS `carta de intención`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_diplomado_me_2018`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_diplomado_me_2018`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_diplomado_me_2018` AS SELECT 
 1 AS `fecha postulación`,
 1 AS `nombre`,
 1 AS `apellidos`,
 1 AS `rut`,
 1 AS `rut_digito`,
 1 AS `fecha nacimiento`,
 1 AS `genero`,
 1 AS `correo electrónico`,
 1 AS `correo electrónico alternativo`,
 1 AS `comuna residencia`,
 1 AS `ciudad residencia`,
 1 AS `region residencia`,
 1 AS `telefono contacto`,
 1 AS `actividad`,
 1 AS `profesion`,
 1 AS `institución donde trabaja`,
 1 AS `dirección institución`,
 1 AS `telefono institución`,
 1 AS `sitio web institución`,
 1 AS `años de servicio`,
 1 AS `archivo_cv`,
 1 AS `archivo titulos y grados (1)`,
 1 AS `archivo titulos y grados (2)`,
 1 AS `carta de intención`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_diplomado_me_2019`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_diplomado_me_2019`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_diplomado_me_2019` AS SELECT 
 1 AS `fecha postulación`,
 1 AS `nombre`,
 1 AS `apellidos`,
 1 AS `rut`,
 1 AS `rut_digito`,
 1 AS `fecha nacimiento`,
 1 AS `genero`,
 1 AS `correo electrónico`,
 1 AS `correo electrónico alternativo`,
 1 AS `comuna residencia`,
 1 AS `ciudad residencia`,
 1 AS `region residencia`,
 1 AS `telefono contacto`,
 1 AS `actividad`,
 1 AS `profesion`,
 1 AS `institución donde trabaja`,
 1 AS `dirección institución`,
 1 AS `telefono institución`,
 1 AS `sitio web institución`,
 1 AS `años de servicio`,
 1 AS `archivo_cv`,
 1 AS `archivo titulos y grados (1)`,
 1 AS `archivo titulos y grados (2)`,
 1 AS `carta de intención`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_diplomado_me_2020`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_diplomado_me_2020`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_diplomado_me_2020` AS SELECT 
 1 AS `fecha postulación`,
 1 AS `nombre`,
 1 AS `apellidos`,
 1 AS `rut`,
 1 AS `rut_digito`,
 1 AS `fecha nacimiento`,
 1 AS `genero`,
 1 AS `correo electrónico`,
 1 AS `correo electrónico alternativo`,
 1 AS `comuna residencia`,
 1 AS `ciudad residencia`,
 1 AS `region residencia`,
 1 AS `telefono contacto`,
 1 AS `actividad`,
 1 AS `profesion`,
 1 AS `institución donde trabaja`,
 1 AS `dirección institución`,
 1 AS `telefono institución`,
 1 AS `sitio web institución`,
 1 AS `años de servicio`,
 1 AS `archivo_cv`,
 1 AS `archivo titulos y grados (1)`,
 1 AS `archivo titulos y grados (2)`,
 1 AS `carta de intención`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_diplomado_me_2021`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_diplomado_me_2021`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_diplomado_me_2021` AS SELECT 
 1 AS `fecha postulación`,
 1 AS `nombre`,
 1 AS `apellidos`,
 1 AS `rut`,
 1 AS `rut_digito`,
 1 AS `fecha nacimiento`,
 1 AS `genero`,
 1 AS `correo electrónico`,
 1 AS `correo electrónico alternativo`,
 1 AS `comuna residencia`,
 1 AS `ciudad residencia`,
 1 AS `region residencia`,
 1 AS `telefono contacto`,
 1 AS `actividad`,
 1 AS `profesion`,
 1 AS `institución donde trabaja`,
 1 AS `dirección institución`,
 1 AS `telefono institución`,
 1 AS `sitio web institución`,
 1 AS `años de servicio`,
 1 AS `archivo_cv`,
 1 AS `archivo titulos y grados (1)`,
 1 AS `carta de intención`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_diplomado_me_2022`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_diplomado_me_2022`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_diplomado_me_2022` AS SELECT 
 1 AS `fecha postulación`,
 1 AS `nombre`,
 1 AS `apellido_paterno`,
 1 AS `apellido_materno`,
 1 AS `rut`,
 1 AS `rut_digito`,
 1 AS `fecha nacimiento`,
 1 AS `genero`,
 1 AS `correo electrónico`,
 1 AS `correo electrónico alternativo`,
 1 AS `dirección residencia`,
 1 AS `comuna residencia`,
 1 AS `ciudad residencia`,
 1 AS `telefono contacto`,
 1 AS `actividad`,
 1 AS `profesion`,
 1 AS `institución donde trabaja`,
 1 AS `telefono institución`,
 1 AS `sitio web institución`,
 1 AS `años de servicio`,
 1 AS `dependencia`,
 1 AS `archivo_cv`,
 1 AS `archivo titulos y grados (1)`,
 1 AS `carta de intención`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_diplomado_me_concep_2018`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_diplomado_me_concep_2018`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_diplomado_me_concep_2018` AS SELECT 
 1 AS `fecha postulación`,
 1 AS `nombre`,
 1 AS `apellidos`,
 1 AS `rut`,
 1 AS `rut_digito`,
 1 AS `fecha nacimiento`,
 1 AS `genero`,
 1 AS `correo electrónico`,
 1 AS `correo electrónico alternativo`,
 1 AS `comuna residencia`,
 1 AS `ciudad residencia`,
 1 AS `region residencia`,
 1 AS `telefono contacto`,
 1 AS `actividad`,
 1 AS `profesion`,
 1 AS `institución donde trabaja`,
 1 AS `dirección institución`,
 1 AS `telefono institución`,
 1 AS `sitio web institución`,
 1 AS `años de servicio`,
 1 AS `archivo_cv`,
 1 AS `archivo titulos y grados (1)`,
 1 AS `archivo titulos y grados (2)`,
 1 AS `carta de intención`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_graduacion_me_2018`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_graduacion_me_2018`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_graduacion_me_2018` AS SELECT 
 1 AS `fecha postulación`,
 1 AS `nombre`,
 1 AS `apellidos`,
 1 AS `correo electrónico`,
 1 AS `comuna residencia`,
 1 AS `region residencia`,
 1 AS `telefono contacto`,
 1 AS `acompañante 1`,
 1 AS `acompañante 2`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_graduacion_me_2019`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_graduacion_me_2019`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_graduacion_me_2019` AS SELECT 
 1 AS `fecha postulación`,
 1 AS `nombre`,
 1 AS `apellidos`,
 1 AS `correo electrónico`,
 1 AS `comuna residencia`,
 1 AS `region residencia`,
 1 AS `telefono contacto`,
 1 AS `acompañante 1`,
 1 AS `acompañante 2`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_honorarios`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_honorarios`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_honorarios` AS SELECT 
 1 AS `rut`,
 1 AS `email`,
 1 AS `nombre`,
 1 AS `apellidos`,
 1 AS `telefono`,
 1 AS `telefono_movil`,
 1 AS `direccion`,
 1 AS `comuna`,
 1 AS `fecha_nacimiento`,
 1 AS `genero`,
 1 AS `archivo_cv`,
 1 AS `archivo_ci`,
 1 AS `area`,
 1 AS `fecha_actualizacion`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_honorarios_labores`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_honorarios_labores`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_honorarios_labores` AS SELECT 
 1 AS `rut`,
 1 AS `orden`,
 1 AS `cargo`,
 1 AS `institucion`,
 1 AS `monto`,
 1 AS `periodo_inicio_mes`,
 1 AS `periodo_inicio_agno`,
 1 AS `periodo_termino_mes`,
 1 AS `periodo_termino_agno`,
 1 AS `tipo_contrato`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_honorarios_titulos`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_honorarios_titulos`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_honorarios_titulos` AS SELECT 
 1 AS `rut`,
 1 AS `tipo`,
 1 AS `orden`,
 1 AS `titulo`,
 1 AS `institucion`,
 1 AS `archivo`,
 1 AS `ciudad`,
 1 AS `pais`,
 1 AS `fecha`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_igeos_inventario`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_igeos_inventario`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_igeos_inventario` AS SELECT 
 1 AS `fecha`,
 1 AS `Número de inventario`,
 1 AS `Nombre del bien`,
 1 AS `Modelo`,
 1 AS `marca`,
 1 AS `N Serie`,
 1 AS `numero_interno_ciae`,
 1 AS `orden_compra`,
 1 AS `Proveedor`,
 1 AS `Rut Proveedor`,
 1 AS `N Factura`,
 1 AS `Organismo`,
 1 AS `Unidad`,
 1 AS `recinto`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_indagacion_en_aulas_2019`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_indagacion_en_aulas_2019`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_indagacion_en_aulas_2019` AS SELECT 
 1 AS `fecha postulación`,
 1 AS `email institución`,
 1 AS `institución/establecimiento`,
 1 AS `RBD`,
 1 AS `comuna residencia`,
 1 AS `ciudad residencia`,
 1 AS `region residencia`,
 1 AS `telefono institución`,
 1 AS `participante 1 Nombre`,
 1 AS `participante 1 Cargo`,
 1 AS `participante 1 Email`,
 1 AS `participante 1 teléfono`,
 1 AS `participante 2 Nombre`,
 1 AS `participante 2 Cargo`,
 1 AS `participante 2 Email`,
 1 AS `participante 2 teléfono`,
 1 AS `participante 3 Nombre`,
 1 AS `participante 3 Cargo`,
 1 AS `participante 3 Email`,
 1 AS `participante 3 teléfono`,
 1 AS `participante 4 Nombre`,
 1 AS `participante 4 Cargo`,
 1 AS `participante 4 Email`,
 1 AS `participante 4 teléfono`,
 1 AS `participante 5 Nombre`,
 1 AS `participante 5 Cargo`,
 1 AS `participante 5 Email`,
 1 AS `participante 5 teléfono`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_inventario_biblioteca`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_inventario_biblioteca`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_inventario_biblioteca` AS SELECT 
 1 AS `ID_CIAE`,
 1 AS `ID_UChile`,
 1 AS `titulo`,
 1 AS `autor`,
 1 AS `editorial`,
 1 AS `año`,
 1 AS `n_copias`,
 1 AS `isbn`,
 1 AS `doi`,
 1 AS `tipo_libro`,
 1 AS `precio_unitario_sin_iva`,
 1 AS `iva`,
 1 AS `total_con_iva`,
 1 AS `proveedor`,
 1 AS `n_orden_de_compra`,
 1 AS `n_factura`,
 1 AS `fecha_de_factura`,
 1 AS `centro_costo`,
 1 AS `proyecto`,
 1 AS `director_proyecto`,
 1 AS `fecha_ingreso_base`,
 1 AS `estado`,
 1 AS `comentarios_interno`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_inventario_biblioteca_formulario`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_inventario_biblioteca_formulario`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_inventario_biblioteca_formulario` AS SELECT 
 1 AS `titulo_del_libro`,
 1 AS `autor`,
 1 AS `editorial`,
 1 AS `agno`,
 1 AS `n_copias`,
 1 AS `isbn`,
 1 AS `precio_unitario_sin_iva`,
 1 AS `iva`,
 1 AS `total_con_iva`,
 1 AS `proveedor`,
 1 AS `n_orden_de_compra`,
 1 AS `n_factura`,
 1 AS `fecha_de_factura`,
 1 AS `n_correlativo_interno`,
 1 AS `proyecto`,
 1 AS `director_proyecto`,
 1 AS `agno_compra`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_inventario_biblioteca_prestamos`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_inventario_biblioteca_prestamos`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_inventario_biblioteca_prestamos` AS SELECT 
 1 AS `n_correlativo_interno`,
 1 AS `titulo_del_libro`,
 1 AS `autor`,
 1 AS `fecha_prestamo`,
 1 AS `fecha_devolucion_estimada`,
 1 AS `fecha_devolucion`,
 1 AS `persona_prestamo`,
 1 AS `director_proyecto_responsable_estimada`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_inventario_biblioteca_simple`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_inventario_biblioteca_simple`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_inventario_biblioteca_simple` AS SELECT 
 1 AS `ID_CIAE`,
 1 AS `titulo`,
 1 AS `autor`,
 1 AS `editorial`,
 1 AS `año`,
 1 AS `n_copias`,
 1 AS `isbn`,
 1 AS `doi`,
 1 AS `tipo_libro`,
 1 AS `proyecto`,
 1 AS `director_proyecto`,
 1 AS `estado`,
 1 AS `fecha_ingreso_base`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_pedidos_tadi`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_pedidos_tadi`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_pedidos_tadi` AS SELECT 
 1 AS `id_pedido`,
 1 AS `estado`,
 1 AS `fecha`,
 1 AS `nombre`,
 1 AS `rut`,
 1 AS `cantidad`,
 1 AS `email`,
 1 AS `institucion`,
 1 AS `direccion`,
 1 AS `ciudad`,
 1 AS `region`,
 1 AS `pais`,
 1 AS `telefono_fijo`,
 1 AS `telefono_celular`,
 1 AS `tipo_envio`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_postdoc_educacion_2020`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_postdoc_educacion_2020`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_postdoc_educacion_2020` AS SELECT 
 1 AS `email`,
 1 AS `doctorado_postulacion`,
 1 AS `nombre`,
 1 AS `apellidos`,
 1 AS `campo_investigacion`,
 1 AS `institucion`,
 1 AS `agno`,
 1 AS `informacion_adicional`,
 1 AS `descargar_archivo_motivacion`,
 1 AS `descargar_archivo_propuesta`,
 1 AS `descargar_archivo_cv`,
 1 AS `descargar_archivo_titulo`,
 1 AS `descargar_archivo_carta_recomendacion1`,
 1 AS `carta_recomendacion1_persona`,
 1 AS `carta_recomendacion1_email_persona`,
 1 AS `carta_recomendacion1_afiliacion_persona`,
 1 AS `descargar_archivo_carta_recomendacion2`,
 1 AS `carta_recomendacion2_persona`,
 1 AS `carta_recomendacion2_email_persona`,
 1 AS `carta_recomendacion2_afiliacion_persona`,
 1 AS `descargar_archivo_carta_recomendacion3`,
 1 AS `carta_recomendacion3_persona`,
 1 AS `carta_recomendacion3_email_persona`,
 1 AS `carta_recomendacion3_afiliacion_persona`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_postdoc_ensenanza_aprendizaje_2019`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_postdoc_ensenanza_aprendizaje_2019`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_postdoc_ensenanza_aprendizaje_2019` AS SELECT 
 1 AS `email`,
 1 AS `doctorado_postulacion`,
 1 AS `nombre`,
 1 AS `apellidos`,
 1 AS `campo_investigacion`,
 1 AS `institucion`,
 1 AS `agno`,
 1 AS `informacion_adicional`,
 1 AS `descargar_archivo_motivacion`,
 1 AS `descargar_archivo_propuesta`,
 1 AS `descargar_archivo_cv`,
 1 AS `descargar_archivo_titulo`,
 1 AS `descargar_archivo_carta_recomendacion1`,
 1 AS `carta_recomendacion1_persona`,
 1 AS `carta_recomendacion1_email_persona`,
 1 AS `carta_recomendacion1_afiliacion_persona`,
 1 AS `descargar_archivo_carta_recomendacion2`,
 1 AS `carta_recomendacion2_persona`,
 1 AS `carta_recomendacion2_email_persona`,
 1 AS `carta_recomendacion2_afiliacion_persona`,
 1 AS `descargar_archivo_carta_recomendacion3`,
 1 AS `carta_recomendacion3_persona`,
 1 AS `carta_recomendacion3_email_persona`,
 1 AS `carta_recomendacion3_afiliacion_persona`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_proy_ciae_extra`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_proy_ciae_extra`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_proy_ciae_extra` AS SELECT 
 1 AS `id_proyecto`,
 1 AS `activo`,
 1 AS `proyecto`,
 1 AS `proyecto_en`,
 1 AS `codigo`,
 1 AS `id_tipo`,
 1 AS `id_tipo_area_proyecto`,
 1 AS `agno_inicio`,
 1 AS `mes_inicio`,
 1 AS `url`,
 1 AS `antecedentes`,
 1 AS `objetivos`,
 1 AS `metodologia`,
 1 AS `periodo`,
 1 AS `financiamiento`,
 1 AS `productos`,
 1 AS `mandante`,
 1 AS `cooperacion_nacional`,
 1 AS `cooperacion_internacional`,
 1 AS `tipo_proyecto`,
 1 AS `tipo_area_proyecto`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_pub_ciae_extra`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_pub_ciae_extra`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_pub_ciae_extra` AS SELECT 
 1 AS `id_publicaciones`,
 1 AS `titulo`,
 1 AS `titulo_en`,
 1 AS `resumen`,
 1 AS `doi`,
 1 AS `isi`,
 1 AS `mes`,
 1 AS `mes_numero`,
 1 AS `agno`,
 1 AS `factor_Q`,
 1 AS `cooperacion_nacional`,
 1 AS `cooperacion_internacional`,
 1 AS `detalle_publicacion`,
 1 AS `link`,
 1 AS `numero_documento`,
 1 AS `tipo`,
 1 AS `area_es`,
 1 AS `visible`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_reporte_noticias`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_reporte_noticias`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_reporte_noticias` AS SELECT 
 1 AS `id_noticia`,
 1 AS `fecha`,
 1 AS `titulo`,
 1 AS `bajada`,
 1 AS `autor`,
 1 AS `tipo`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_tmp_reporte_noticias_prensa`;
/*!50001 DROP VIEW IF EXISTS `view_tmp_reporte_noticias_prensa`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_tmp_reporte_noticias_prensa` AS SELECT 
 1 AS `noticia`,
 1 AS `bajada`,
 1 AS `url externo`,
 1 AS `archivo`,
 1 AS `fecha`,
 1 AS `medio`,
 1 AS `tema`,
 1 AS `tipo medio`,
 1 AS `tipo cobertura`,
 1 AS `investigador`,
 1 AS `tipo aparicion`,
 1 AS `palabras clave`,
 1 AS `sitio`,
 1 AS `area`*/;
SET character_set_client = @saved_cs_client;

USE `ciaecl_ciae`;
/*!50001 DROP VIEW IF EXISTS `view_areas_proyecto`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_areas_proyecto` AS select `pr`.`id_proyecto` AS `id_proyecto`,`pa`.`id_area` AS `id_area`,`ar`.`area_es` AS `area_es`,`ar`.`area_en` AS `area_en` from ((((`site_proyectos_personas` `pe` join `site_proyectos` `pr`) join `site_personas` `ps`) join `site_personas_areas` `pa`) join `site_areas` `ar`) where ((`pe`.`id_proyecto` = `pr`.`id_proyecto`) and (`pr`.`activo` = 1) and (`pe`.`id_persona` = `ps`.`id_persona`) and (`pe`.`id_persona` = `pa`.`id_persona`) and (`pa`.`id_area` = `ar`.`id_area`)) group by `pr`.`id_proyecto`,`pa`.`id_area` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_auth_menu_access`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_auth_menu_access` AS select `a`.`id` AS `id`,`b`.`permiso` AS `permiso`,`a`.`opcion` AS `opcion`,`a`.`titulo_es` AS `titulo_es`,`a`.`tipo_menu` AS `tipo_menu`,`a`.`link` AS `link`,`a`.`tipo_archivo` AS `tipo_archivo`,`a`.`sitio` AS `sitio`,`a`.`archivo` AS `archivo`,`a`.`publicar` AS `publicar`,`a`.`menu_padre` AS `menu_padre` from (`auth_menu` `a` join `auth_menu_access` `b`) where (`a`.`id` = `b`.`id`) order by `a`.`id` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_auth_persona`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_auth_persona` AS select `p`.`username` AS `username`,`p`.`perms` AS `perms`,`p`.`permisos_extras` AS `permisos_extras`,`p`.`activo` AS `activo_usuario`,`pn`.`alias` AS `alias`,`pi`.`id_persona` AS `id_persona`,`pi`.`user_id` AS `user_id`,`pi`.`nombre` AS `nombre`,`pi`.`apellido_paterno` AS `apellido_paterno`,`pi`.`apellido_materno` AS `apellido_materno`,`pi`.`nombre_publicacion` AS `nombre_publicacion`,`pi`.`rut` AS `rut`,`pi`.`rut_dv` AS `rut_dv`,`pi`.`pasaporte` AS `pasaporte`,`pi`.`afiliacion` AS `afiliacion`,`pi`.`id_tipo_contrato` AS `id_tipo_contrato`,`pi`.`facultad_externa` AS `facultad_externa`,`pi`.`id_tipo_contrato_facultad` AS `id_tipo_contrato_facultad`,`pi`.`id_universidad` AS `id_universidad`,`pi`.`direccion` AS `direccion`,`pi`.`telefono_personal` AS `telefono_personal`,`pi`.`grado` AS `grado`,`pi`.`cargo_gestion` AS `cargo_gestion`,`pi`.`cargo` AS `cargo`,`pi`.`cargo_en` AS `cargo_en`,`pi`.`activo` AS `activo`,`pi`.`telefono` AS `telefono`,`pi`.`url` AS `url`,`pi`.`imagen` AS `imagen`,`pi`.`email` AS `email`,`pi`.`email_alternativo` AS `email_alternativo`,`pi`.`archivo_rut` AS `archivo_rut`,`pi`.`cv` AS `cv`,`pi`.`perfil` AS `perfil`,`pi`.`anexo` AS `anexo`,`pi`.`anexo_numero` AS `anexo_numero`,`pi`.`fecha` AS `fecha`,`pi`.`archivo_pasaporte` AS `archivo_pasaporte`,`pi`.`archivo_cv` AS `archivo_cv`,`pi`.`archivo_titulo` AS `archivo_titulo` from (((`auth_user_info` `i` join `auth_user_md5` `p`) join `auth_rol` `pn`) join `site_personas` `pi`) where ((`i`.`user_id` = `p`.`user_id`) and (`p`.`activo` = 1) and (`p`.`perms` = `pn`.`id_permiso`) and (`pi`.`user_id` = `p`.`user_id`) and (`pi`.`id_persona` = `i`.`id_persona`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_auth_site`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_auth_site` AS select `ms`.`user_id` AS `user_id`,`ui`.`nombre` AS `nombre`,`ui`.`apellido_paterno` AS `apellido_paterno`,`ui`.`username` AS `username`,`ui`.`alias` AS `permiso`,`ss`.`id_site` AS `id_site`,`ss`.`nombre_site` AS `nombre_site`,`ss`.`titulo_site` AS `titulo_site` from ((`auth_user_md5_site` `ms` join `view_auth_persona` `ui`) join `site_site` `ss`) where ((`ms`.`user_id` like `ui`.`user_id`) and (`ms`.`id_site` = `ss`.`id_site`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_bannner_site`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_bannner_site` AS select `a`.`id_banner` AS `id_banner`,`a`.`imagen` AS `imagen`,`a`.`titulo` AS `titulo`,`a`.`bajada` AS `bajada`,`a`.`orden` AS `orden`,`a`.`link` AS `link`,`a`.`activo` AS `activo`,`a`.`idioma` AS `idioma`,`a`.`tipo` AS `tipo`,`a`.`id_site` AS `id_site`,`a`.`fecha_caducidad` AS `fecha_caducidad`,`a`.`fecha_caducidad` AS `fecha_caducidad_html`,`s`.`nombre_site` AS `nombre_site`,`s`.`titulo_site` AS `titulo_site` from (`site_banner` `a` join `site_site` `s`) where (`a`.`id_site` = `s`.`id_site`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_boletin_especiales_site`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_boletin_especiales_site` AS select `a`.`id_boletin` AS `id_boletin`,`a`.`agno` AS `agno`,`a`.`mes` AS `mes`,`a`.`titulo` AS `titulo`,`a`.`id_noticia` AS `id_noticia`,`a`.`id_site` AS `id_site`,`b`.`nombre_site` AS `nombre_site`,`b`.`titulo_site` AS `titulo_site` from (`site_boletin_especiales` `a` join `site_site` `b`) where (`a`.`id_site` = `b`.`id_site`) order by `a`.`agno` desc,`a`.`mes` desc,`a`.`id_boletin` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_boletin_site`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_boletin_site` AS select `a`.`id_boletin` AS `id_boletin`,`a`.`agno` AS `agno`,`a`.`mes` AS `mes`,`a`.`archivo` AS `archivo`,`a`.`id_site` AS `id_site`,`b`.`nombre_site` AS `nombre_site`,`b`.`titulo_site` AS `titulo_site` from (`site_boletin` `a` join `site_site` `b`) where (`a`.`id_site` = `b`.`id_site`) order by `a`.`agno` desc,`a`.`mes` desc,`a`.`id_boletin` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_certificado_detalle_tipo`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_certificado_detalle_tipo` AS select `site_certificado_detalle`.`id_certificado` AS `id_certificado`,count(`site_certificado_detalle`.`id_certificado`) AS `total` from `site_certificado_detalle` group by `site_certificado_detalle`.`id_certificado` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_common_logs_download_fecha`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_common_logs_download_fecha` AS select `common_logs_download`.`id_visit` AS `id_visit`,`common_logs_download`.`sitio` AS `sitio`,date_format(from_unixtime(`common_logs_download`.`fecha`),_utf8'%d-%m-%Y %H:%i:%s') AS `fecha_html`,`common_logs_download`.`ip_address` AS `ip_address`,`common_logs_download`.`documento` AS `documento`,`common_logs_download`.`estado` AS `estado` from `common_logs_download` order by `common_logs_download`.`fecha` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_common_logs_download_fecha_error`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_common_logs_download_fecha_error` AS select `common_logs_download`.`id_visit` AS `id_visit`,`common_logs_download`.`sitio` AS `sitio`,date_format(from_unixtime(`common_logs_download`.`fecha`),_utf8'%d-%m-%Y %H:%i:%s') AS `fecha_html`,`common_logs_download`.`ip_address` AS `ip_address`,`common_logs_download`.`documento` AS `documento`,`common_logs_download`.`estado` AS `estado` from `common_logs_download` where (not((`common_logs_download`.`estado` like _latin1'OK'))) order by `common_logs_download`.`fecha` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_common_logs_download_resumen`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_common_logs_download_resumen` AS select count(0) AS `total`,`common_logs_download`.`documento` AS `documento` from `common_logs_download` where (`common_logs_download`.`estado` = _latin1'OK') group by `common_logs_download`.`documento` order by count(0) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_common_logs_fecha`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_common_logs_fecha` AS select `common_logs`.`time_log` AS `time_log`,`common_logs`.`ip` AS `ip`,`common_logs`.`ip_extra` AS `ip_extra`,`common_logs`.`sitio` AS `sitio`,`common_logs`.`username` AS `username`,`common_logs`.`action` AS `action`,`common_logs`.`msg` AS `msg`,`common_logs`.`post` AS `post`,from_unixtime(`common_logs`.`time_log`) AS `fecha` from `common_logs` order by `common_logs`.`time_log` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_common_logs_fecha_sin_visita`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_common_logs_fecha_sin_visita` AS select `common_logs`.`time_log` AS `time_log`,date_format(from_unixtime(`common_logs`.`time_log`),_utf8'%d-%m-%Y %H:%i:%s') AS `fecha_html`,`common_logs`.`ip` AS `ip`,`common_logs`.`sitio` AS `sitio`,`common_logs`.`username` AS `username`,`common_logs`.`action` AS `action`,`common_logs`.`msg` AS `msg`,`common_logs`.`post` AS `post`,`common_logs`.`ip_extra` AS `ip_extra` from `common_logs` where ((not((`common_logs`.`msg` like _utf8'%site_noticias_visita%'))) and (not((`common_logs`.`msg` like _utf8'%download.php%')))) order by `common_logs`.`time_log` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_common_logs_fecha_sin_visita_usuario`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_common_logs_fecha_sin_visita_usuario` AS select `view_common_logs_fecha`.`time_log` AS `time_log`,`view_common_logs_fecha`.`fecha` AS `fecha_html`,`view_common_logs_fecha`.`ip` AS `ip`,`view_common_logs_fecha`.`sitio` AS `sitio`,`view_common_logs_fecha`.`username` AS `username`,`view_common_logs_fecha`.`action` AS `action`,`view_common_logs_fecha`.`msg` AS `msg`,`view_common_logs_fecha`.`post` AS `post`,`view_common_logs_fecha`.`ip_extra` AS `ip_extra` from `view_common_logs_fecha` where (not((`view_common_logs_fecha`.`username` like _utf8'unknown'))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_common_logs_fecha_sin_visita_usuario_login`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_common_logs_fecha_sin_visita_usuario_login` AS select `view_common_logs_fecha`.`time_log` AS `time_log`,`view_common_logs_fecha`.`fecha` AS `fecha_html`,`view_common_logs_fecha`.`ip` AS `ip`,`view_common_logs_fecha`.`sitio` AS `sitio`,`view_common_logs_fecha`.`username` AS `username`,`view_common_logs_fecha`.`action` AS `action`,`view_common_logs_fecha`.`msg` AS `msg`,`view_common_logs_fecha`.`post` AS `post`,`view_common_logs_fecha`.`ip_extra` AS `ip_extra` from `view_common_logs_fecha` where ((not((`view_common_logs_fecha`.`username` like _utf8'unknown'))) and (`view_common_logs_fecha`.`action` like _utf8'LOGIN-SUCCESS')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_common_logs_ip`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_common_logs_ip` AS select `common_logs_ip_block`.`ip` AS `ip`,`common_logs_ip_block`.`bloqueado` AS `bloqueado`,`common_logs_ip_block`.`fecha` AS `fecha`,`common_logs_ip_block`.`sitio` AS `sitio`,`common_logs_ip_block`.`url` AS `url` from `common_logs_ip_block` where (`common_logs_ip_block`.`bloqueado` like _latin1'si') order by `common_logs_ip_block`.`fecha` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_common_logs_noticias_visitas`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_common_logs_noticias_visitas` AS select `a`.`id_noticia` AS `id_noticia`,count(`a`.`id_noticia`) AS `total_apariciones`,`a`.`tipo_visita` AS `tipo_visita` from (select `ciaecl_ciae`.`site_noticias_visita`.`id_noticia` AS `id_noticia`,`ciaecl_ciae`.`site_noticias_visita`.`tipo_visita` AS `tipo_visita_completo`,substr(`ciaecl_ciae`.`site_noticias_visita`.`tipo_visita`,1,5) AS `tipo_visita` from `ciaecl_ciae`.`site_noticias_visita` order by `ciaecl_ciae`.`site_noticias_visita`.`id_noticia` desc) `a` group by `a`.`id_noticia`,`a`.`tipo_visita` order by `a`.`id_noticia` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_common_logs_url_fecha`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_common_logs_url_fecha` AS select `common_logs_url`.`id_visit` AS `id_visit`,date_format(from_unixtime(`common_logs_url`.`fecha`),_utf8'%d-%m-%Y %H:%i:%s') AS `fecha_html`,`common_logs_url`.`ip_address` AS `ip_address`,`common_logs_url`.`username` AS `username`,`common_logs_url`.`url` AS `url`,`common_logs_url`.`uri` AS `uri`,`common_logs_url`.`browser` AS `browser` from `common_logs_url` order by `common_logs_url`.`fecha` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_common_logs_url_fecha_error`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_common_logs_url_fecha_error` AS select `view_common_logs_url_fecha`.`id_visit` AS `id_visit`,`view_common_logs_url_fecha`.`fecha_html` AS `fecha_html`,`view_common_logs_url_fecha`.`ip_address` AS `ip_address`,`view_common_logs_url_fecha`.`username` AS `username`,`view_common_logs_url_fecha`.`url` AS `url`,`view_common_logs_url_fecha`.`uri` AS `uri`,`view_common_logs_url_fecha`.`browser` AS `browser` from `view_common_logs_url_fecha` where ((`view_common_logs_url_fecha`.`uri` like _latin1'%select%') or (`view_common_logs_url_fecha`.`uri` like _latin1'%UNION%') or (`view_common_logs_url_fecha`.`uri` like _latin1'%insert%') or (`view_common_logs_url_fecha`.`browser` like _latin1'%sqlmap%')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_common_logs_url_fecha_usuario`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_common_logs_url_fecha_usuario` AS select `view_common_logs_url_fecha`.`id_visit` AS `id_visit`,`view_common_logs_url_fecha`.`fecha_html` AS `fecha_html`,`view_common_logs_url_fecha`.`ip_address` AS `ip_address`,`view_common_logs_url_fecha`.`username` AS `username`,`view_common_logs_url_fecha`.`url` AS `url`,`view_common_logs_url_fecha`.`uri` AS `uri`,`view_common_logs_url_fecha`.`browser` AS `browser` from `view_common_logs_url_fecha` where ((not((`view_common_logs_url_fecha`.`username` like _latin1'unknown'))) and (not((`view_common_logs_url_fecha`.`username` like _latin1'')))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_common_logs_visitas_uri`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_common_logs_visitas_uri` AS select `common_logs_url`.`url` AS `url`,`common_logs_url`.`uri` AS `uri`,count(0) AS `total` from `common_logs_url` group by `common_logs_url`.`uri` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_compras_adquisiciones`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_compras_adquisiciones` AS select `site_compras_adquisiciones_menores`.`id_compra` AS `id_compra`,`site_compras_adquisiciones_menores`.`concepto_tipo_gasto` AS `concepto_tipo_gasto`,`site_compras_adquisiciones_menores`.`cantidad` AS `cantidad`,`site_compras_adquisiciones_menores`.`valor` AS `valor`,`site_compras_adquisiciones_menores`.`deleted_at` AS `deleted_at`,`site_compras_adquisiciones_menores`.`created_at` AS `created_at`,`site_compras_adquisiciones_menores`.`updated_at` AS `updated_at` from `site_compras_adquisiciones_menores` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_email_webmaster_envio_orden`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_email_webmaster_envio_orden` AS select `site_email_webmaster_envio`.`fecha` AS `fecha`,`site_email_webmaster_envio`.`email` AS `email`,`site_email_webmaster_envio`.`orden` AS `orden`,`site_email_webmaster_envio`.`total` AS `total` from `site_email_webmaster_envio` order by `site_email_webmaster_envio`.`fecha` desc,`site_email_webmaster_envio`.`orden` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_email_webmaster_envio_total`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_email_webmaster_envio_total` AS select `site_email_webmaster_envio`.`fecha` AS `fecha`,dayname(`site_email_webmaster_envio`.`fecha`) AS `dia`,sum(`site_email_webmaster_envio`.`total`) AS `total` from `site_email_webmaster_envio` group by `site_email_webmaster_envio`.`fecha` order by `site_email_webmaster_envio`.`fecha` desc,`site_email_webmaster_envio`.`orden` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_gestion_centro_costo_responsable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_gestion_centro_costo_responsable` AS select `c`.`id_centro_costo` AS `id_centro_costo`,if((`c`.`codigo` <> _latin1''),`c`.`codigo`,_latin1'S/I') AS `codigo`,if((`c`.`proyecto` <> _latin1''),`c`.`proyecto`,_latin1'centro de costos por defecto (no modificar)') AS `centro_costo`,`c`.`cuenta_corriente` AS `cuenta_corriente`,`c`.`activo` AS `activo`,if((`c`.`activo` <> 1),_utf8'Inactivo',_utf8'Activo') AS `activo_html`,`p`.`username` AS `usuario`,`p`.`nombre` AS `nombre`,`p`.`apellido_paterno` AS `apellido_paterno`,`c`.`usuario_responsable` AS `usuario_responsable` from (`site_tipo_centro_costos` `c` join `view_auth_persona` `p`) where (`c`.`usuario_responsable` = `p`.`user_id`) order by `c`.`proyecto` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_gestion_destinos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_gestion_destinos` AS select distinct `site_gestion_solicitudes_viaticos`.`origen` AS `destino` from `site_gestion_solicitudes_viaticos` union select distinct `site_gestion_solicitudes_viaticos`.`destino` AS `destino` from `site_gestion_solicitudes_viaticos` order by `destino` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_gestion_honorarios_personas`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_gestion_honorarios_personas` AS select `p`.`id_honorario` AS `id_honorario`,`p`.`id_persona` AS `id_persona`,`p`.`numero_convenio` AS `numero_convenio`,`p`.`numero_decreto` AS `numero_decreto`,`p`.`numero_memo` AS `numero_memo`,`p`.`fecha_creacion` AS `fecha_creacion`,`p`.`fecha_termino` AS `fecha_termino`,`p`.`id_centro_costo` AS `id_centro_costo`,`p`.`centro_costo` AS `centro_costo`,`p`.`proyecto` AS `proyecto`,`p`.`id_investigador_responsable` AS `id_investigador_responsable`,`p`.`id_investigador_supervidor` AS `id_investigador_supervidor`,`p`.`monto_comprometido` AS `monto_comprometido`,`p`.`numero_cuotas` AS `numero_cuotas`,`p`.`fecha_desde` AS `fecha_desde`,`p`.`fecha_hasta` AS `fecha_hasta`,`p`.`fecha_convenio` AS `fecha_convenio`,`p`.`fecha_firma` AS `fecha_firma`,`p`.`fecha_compromiso` AS `fecha_compromiso`,`p`.`fecha_aprobacion` AS `fecha_aprobacion`,`p`.`id_tipo_estados_honorarios` AS `id_tipo_estados_honorarios`,`p`.`id_tipo_honorarios_calidad` AS `id_tipo_honorarios_calidad`,`p`.`horas_jornada` AS `horas_jornada`,`p`.`comentario_horas_jornada` AS `comentario_horas_jornada`,`p`.`labor` AS `labor`,`p`.`labor_resumida` AS `labor_resumida`,`p`.`proyecto_corto` AS `proyecto_corto`,`p`.`observacion` AS `observacion`,`p`.`envio_correo_general` AS `envio_correo_general`,format(`p`.`monto_comprometido`,0) AS `monto_comprometido_html`,concat(`b_resp`.`nombre`,_latin1' ',`b_resp`.`apellido_paterno`) AS `investigador_responsable`,concat(`b_super`.`nombre`,_latin1' ',`b_super`.`apellido_paterno`) AS `investigador_supervisor`,`b`.`user_id` AS `user_id`,`b`.`nombre` AS `nombre`,`b`.`apellido_paterno` AS `apellido_paterno`,`b`.`apellido_materno` AS `apellido_materno`,`b`.`nombre_publicacion` AS `nombre_publicacion`,`b`.`fecha_nacimiento` AS `fecha_nacimiento`,`b`.`fecha_nacimiento_html` AS `fecha_nacimiento_html`,`b`.`genero` AS `genero`,`b`.`rut` AS `rut`,`b`.`rut_html` AS `rut_html`,`b`.`rut_dv` AS `rut_dv`,`b`.`pasaporte` AS `pasaporte`,`b`.`afiliacion` AS `afiliacion`,`b`.`id_tipo_contrato` AS `id_tipo_contrato`,`b`.`tipo_contrato` AS `tipo_contrato`,`b`.`cumple_contrato` AS `cumple_contrato`,`b`.`facultad_externa` AS `facultad_externa`,`b`.`id_tipo_contrato_facultad` AS `id_tipo_contrato_facultad`,`b`.`id_universidad` AS `id_universidad`,`b`.`universidad` AS `universidad`,`b`.`direccion` AS `direccion`,`b`.`comuna_id` AS `comuna_id`,`b`.`comuna` AS `comuna`,`b`.`region` AS `region`,`b`.`pais_id` AS `pais_id`,`b`.`pais` AS `pais`,`b`.`telefono_personal` AS `telefono_personal`,`b`.`grado` AS `grado`,`b`.`grado_academico_honorarios` AS `grado_academico_honorarios`,`b`.`cargo_gestion` AS `cargo_gestion`,`b`.`cargo` AS `cargo`,`b`.`cargo_en` AS `cargo_en`,`b`.`activo` AS `activo`,`b`.`telefono` AS `telefono`,`b`.`url` AS `url`,`b`.`imagen` AS `imagen`,`b`.`email` AS `email`,`b`.`email_alternativo` AS `email_alternativo`,`b`.`archivo_rut` AS `archivo_rut`,`b`.`cv` AS `cv`,`b`.`perfil` AS `perfil`,`b`.`anexo` AS `anexo`,`b`.`anexo_numero` AS `anexo_numero`,`b`.`fecha_actualizacion` AS `fecha_actualizacion`,`b`.`archivo_pasaporte` AS `archivo_pasaporte`,`b`.`archivo_cv` AS `archivo_cv`,`b`.`archivo_titulo` AS `archivo_titulo`,`b`.`datos_honorarios_completo` AS `datos_honorarios_completo`,date_format(`p`.`fecha_creacion`,_utf8'%d-%m-%Y') AS `fecha_creacion_html`,date_format(`p`.`fecha_termino`,_utf8'%d-%m-%Y') AS `fecha_termino_html`,date_format(`p`.`fecha_desde`,_utf8'%d-%m-%Y') AS `fecha_desde_html`,date_format(`p`.`fecha_hasta`,_utf8'%d-%m-%Y') AS `fecha_hasta_html`,date_format(`p`.`fecha_convenio`,_utf8'%d-%m-%Y') AS `fecha_convenio_html`,date_format(`p`.`fecha_firma`,_utf8'%d-%m-%Y') AS `fecha_firma_html`,date_format(`p`.`fecha_compromiso`,_utf8'%d-%m-%Y') AS `fecha_compromiso_html`,date_format(`p`.`fecha_aprobacion`,_utf8'%d-%m-%Y') AS `fecha_aprobacion_html`,`c`.`codigo` AS `centro_costo_codigo`,`c`.`proyecto` AS `centro_costo_proyecto`,`e`.`tipo_honorarios_estados` AS `estado_convenio` from (((((`site_gestion_honorarios` `p` join `view_personas` `b`) join `view_personas` `b_resp`) join `view_personas` `b_super`) join `site_tipo_centro_costos` `c`) join `site_tipo_honorarios_estados` `e`) where ((`b`.`id_persona` = `p`.`id_persona`) and (`b_resp`.`id_persona` = `p`.`id_investigador_responsable`) and (`b_super`.`id_persona` = `p`.`id_investigador_supervidor`) and (`p`.`id_centro_costo` = `c`.`id_centro_costo`) and (`p`.`id_tipo_estados_honorarios` = `e`.`id_tipo_honorarios_estados`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_gestion_honorarios_personas_cuotas`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_gestion_honorarios_personas_cuotas` AS select `h`.`id_honorario` AS `id_honorario`,`h`.`id_persona` AS `id_persona`,`h`.`numero_convenio` AS `numero_convenio`,`h`.`numero_decreto` AS `numero_decreto`,`h`.`numero_memo` AS `numero_memo`,`h`.`fecha_creacion` AS `fecha_creacion`,`h`.`fecha_termino` AS `fecha_termino`,`h`.`id_centro_costo` AS `id_centro_costo`,`h`.`centro_costo` AS `centro_costo`,`h`.`proyecto` AS `proyecto`,`h`.`id_investigador_responsable` AS `id_investigador_responsable`,`h`.`id_investigador_supervidor` AS `id_investigador_supervidor`,`h`.`monto_comprometido` AS `monto_comprometido`,`h`.`numero_cuotas` AS `numero_cuotas`,`h`.`fecha_desde` AS `fecha_desde`,`h`.`fecha_hasta` AS `fecha_hasta`,`h`.`fecha_convenio` AS `fecha_convenio`,`h`.`fecha_firma` AS `fecha_firma`,`h`.`fecha_compromiso` AS `fecha_compromiso`,`h`.`fecha_aprobacion` AS `fecha_aprobacion`,`h`.`id_tipo_estados_honorarios` AS `id_tipo_estados_honorarios`,`h`.`id_tipo_honorarios_calidad` AS `id_tipo_honorarios_calidad`,`h`.`horas_jornada` AS `horas_jornada`,`h`.`comentario_horas_jornada` AS `comentario_horas_jornada`,`h`.`labor` AS `labor`,`h`.`labor_resumida` AS `labor_resumida`,`h`.`proyecto_corto` AS `proyecto_corto`,`h`.`observacion` AS `observacion`,`h`.`envio_correo_general` AS `envio_correo_general`,`h`.`monto_comprometido_html` AS `monto_comprometido_html`,`h`.`investigador_responsable` AS `investigador_responsable`,`h`.`investigador_supervisor` AS `investigador_supervisor`,`h`.`user_id` AS `user_id`,`h`.`nombre` AS `nombre`,`h`.`apellido_paterno` AS `apellido_paterno`,`h`.`apellido_materno` AS `apellido_materno`,`h`.`nombre_publicacion` AS `nombre_publicacion`,`h`.`fecha_nacimiento` AS `fecha_nacimiento`,`h`.`fecha_nacimiento_html` AS `fecha_nacimiento_html`,`h`.`genero` AS `genero`,`h`.`rut` AS `rut`,`h`.`rut_html` AS `rut_html`,`h`.`rut_dv` AS `rut_dv`,`h`.`pasaporte` AS `pasaporte`,`h`.`afiliacion` AS `afiliacion`,`h`.`id_tipo_contrato` AS `id_tipo_contrato`,`h`.`tipo_contrato` AS `tipo_contrato`,`h`.`cumple_contrato` AS `cumple_contrato`,`h`.`facultad_externa` AS `facultad_externa`,`h`.`id_tipo_contrato_facultad` AS `id_tipo_contrato_facultad`,`h`.`id_universidad` AS `id_universidad`,`h`.`universidad` AS `universidad`,`h`.`direccion` AS `direccion`,`h`.`comuna_id` AS `comuna_id`,`h`.`comuna` AS `comuna`,`h`.`region` AS `region`,`h`.`pais_id` AS `pais_id`,`h`.`pais` AS `pais`,`h`.`telefono_personal` AS `telefono_personal`,`h`.`grado` AS `grado`,`h`.`grado_academico_honorarios` AS `grado_academico_honorarios`,`h`.`cargo_gestion` AS `cargo_gestion`,`h`.`cargo` AS `cargo`,`h`.`cargo_en` AS `cargo_en`,`h`.`activo` AS `activo`,`h`.`telefono` AS `telefono`,`h`.`url` AS `url`,`h`.`imagen` AS `imagen`,`h`.`email` AS `email`,`h`.`email_alternativo` AS `email_alternativo`,`h`.`archivo_rut` AS `archivo_rut`,`h`.`cv` AS `cv`,`h`.`perfil` AS `perfil`,`h`.`anexo` AS `anexo`,`h`.`anexo_numero` AS `anexo_numero`,`h`.`fecha_actualizacion` AS `fecha_actualizacion`,`h`.`archivo_pasaporte` AS `archivo_pasaporte`,`h`.`archivo_cv` AS `archivo_cv`,`h`.`archivo_titulo` AS `archivo_titulo`,`h`.`datos_honorarios_completo` AS `datos_honorarios_completo`,`h`.`fecha_creacion_html` AS `fecha_creacion_html`,`h`.`fecha_termino_html` AS `fecha_termino_html`,`h`.`fecha_desde_html` AS `fecha_desde_html`,`h`.`fecha_hasta_html` AS `fecha_hasta_html`,`h`.`fecha_convenio_html` AS `fecha_convenio_html`,`h`.`fecha_firma_html` AS `fecha_firma_html`,`h`.`fecha_compromiso_html` AS `fecha_compromiso_html`,`h`.`fecha_aprobacion_html` AS `fecha_aprobacion_html`,`h`.`centro_costo_codigo` AS `centro_costo_codigo`,`h`.`centro_costo_proyecto` AS `centro_costo_proyecto`,`h`.`estado_convenio` AS `estado_convenio`,`c`.`numero_cuota` AS `numero_cuota`,`c`.`numero_agno` AS `numero_agno`,`c`.`numero_mes` AS `numero_mes`,`c`.`monto_cuota` AS `monto_cuota`,format(`c`.`monto_cuota`,0) AS `monto_cuota_html`,`c`.`estado` AS `estado`,`c`.`fecha_pago` AS `fecha_pago` from (`view_gestion_honorarios_personas` `h` join `site_gestion_honorarios_cuotas` `c`) where (`h`.`id_honorario` = `c`.`id_honorario`) order by `h`.`id_honorario` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_gestion_inventario_libros_libros`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_gestion_inventario_libros_libros` AS select `b`.`id_libro` AS `id_libro`,`b`.`id_uchile` AS `id_uchile`,`b`.`estado` AS `estado`,`b`.`numero_copias` AS `numero_copias`,`b`.`autores` AS `autores`,`b`.`titulo` AS `titulo`,`b`.`editorial` AS `editorial`,`b`.`fecha_ingreso_base` AS `fecha_ingreso_base`,date_format(`b`.`fecha_ingreso_base`,_utf8'%d-%m-%Y') AS `fecha_ingreso_base_html`,`b`.`agno_publicacion` AS `agno_publicacion`,`b`.`isbn` AS `isbn`,`b`.`doi` AS `doi`,`b`.`tipo_libro` AS `tipo_libro`,`b`.`proyecto` AS `proyecto`,`b`.`investigador_acargo` AS `investigador_acargo`,`b`.`palabra_clave` AS `palabra_clave`,`b`.`precio_unitario` AS `precio_unitario`,`b`.`precio_iva` AS `precio_iva`,`b`.`precio_total` AS `precio_total`,`b`.`proveedor` AS `proveedor`,`b`.`orden_compra` AS `orden_compra`,`b`.`factura` AS `factura`,`b`.`fecha_factura` AS `fecha_factura`,date_format(`b`.`fecha_factura`,_utf8'%d-%m-%Y') AS `fecha_factura_html`,`b`.`comentarios` AS `comentarios`,`b`.`fecha_actualizacion` AS `fecha_actualizacion`,date_format(`b`.`fecha_actualizacion`,_utf8'%d-%m-%Y') AS `fecha_actualizacion_html`,`c`.`id_centro_costo` AS `id_centro_costo`,`c`.`codigo` AS `centro_costo_codigo`,`c`.`centro_costo` AS `centro_costo`,`c`.`activo` AS `activo_centro_costo`,`c`.`activo_html` AS `activo_html_centro_costo`,`c`.`usuario` AS `usuario_centro_costo`,`c`.`nombre` AS `nombre_responsable_centro_costo`,`c`.`apellido_paterno` AS `apellido_paterno_responsable_centro_costo`,`c`.`usuario_responsable` AS `usuario_responsable_centro_costo` from (`site_gestion_inventario_libros_libros` `b` join `view_gestion_centro_costo_responsable` `c`) where (`b`.`centro_costo` = `c`.`id_centro_costo`) order by `b`.`titulo` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_gestion_inventario_libros_prestamos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_gestion_inventario_libros_prestamos` AS select distinct `view_gestion_inventario_libros_prestamos_detalle`.`id_prestamo` AS `id_prestamo`,`view_gestion_inventario_libros_prestamos_detalle`.`fecha_prestamo` AS `fecha_prestamo`,`view_gestion_inventario_libros_prestamos_detalle`.`fecha_prestamo_html` AS `fecha_prestamo_html`,`view_gestion_inventario_libros_prestamos_detalle`.`fecha_solicitud` AS `fecha_solicitud`,`view_gestion_inventario_libros_prestamos_detalle`.`fecha_solicitud_html` AS `fecha_solicitud_html`,`view_gestion_inventario_libros_prestamos_detalle`.`fecha_devolucion_estimada` AS `fecha_devolucion_estimada`,`view_gestion_inventario_libros_prestamos_detalle`.`fecha_devolucion_estimada_html` AS `fecha_devolucion_estimada_html`,`view_gestion_inventario_libros_prestamos_detalle`.`fecha_devolucion` AS `fecha_devolucion`,`view_gestion_inventario_libros_prestamos_detalle`.`fecha_devolucion_html` AS `fecha_devolucion_html`,`view_gestion_inventario_libros_prestamos_detalle`.`estado` AS `estado`,`view_gestion_inventario_libros_prestamos_detalle`.`id_usuario_solicitante` AS `id_usuario_solicitante`,`view_gestion_inventario_libros_prestamos_detalle`.`usuario_solicitante` AS `usuario_solicitante`,`view_gestion_inventario_libros_prestamos_detalle`.`id_usuario_gestiona` AS `id_usuario_gestiona`,`view_gestion_inventario_libros_prestamos_detalle`.`usuario_gestiona` AS `usuario_gestiona` from `view_gestion_inventario_libros_prestamos_detalle` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_gestion_inventario_libros_prestamos_detalle`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_gestion_inventario_libros_prestamos_detalle` AS select `a`.`id_prestamo` AS `id_prestamo`,`a`.`fecha_prestamo` AS `fecha_prestamo`,date_format(`a`.`fecha_prestamo`,_utf8'%d-%m-%Y') AS `fecha_prestamo_html`,`a`.`fecha_solicitud` AS `fecha_solicitud`,date_format(`a`.`fecha_solicitud`,_utf8'%d-%m-%Y') AS `fecha_solicitud_html`,`a`.`fecha_devolucion_estimada` AS `fecha_devolucion_estimada`,date_format(`a`.`fecha_devolucion_estimada`,_utf8'%d-%m-%Y') AS `fecha_devolucion_estimada_html`,`a`.`fecha_devolucion` AS `fecha_devolucion`,date_format(`a`.`fecha_devolucion`,_utf8'%d-%m-%Y') AS `fecha_devolucion_html`,`a`.`estado` AS `estado`,`a`.`id_usuario_solicitante` AS `id_usuario_solicitante`,concat(`pa`.`nombre`,_latin1' ',`pa`.`apellido_paterno`) AS `usuario_solicitante`,`a`.`id_usuario_gestiona` AS `id_usuario_gestiona`,concat(`pb`.`nombre`,_latin1' ',`pb`.`apellido_paterno`) AS `usuario_gestiona`,`a`.`archivo_prestamo_firmado` AS `archivo_prestamo_firmado`,`a`.`archivo_devolucion_firmado` AS `archivo_devolucion_firmado`,`a`.`comentario` AS `comentario`,`b`.`id_libro` AS `id_libro`,`ll`.`titulo` AS `titulo_libro`,`ll`.`autores` AS `autores_libro`,`ll`.`editorial` AS `editorial_libro`,`ll`.`agno_publicacion` AS `agno_publicacion_libro`,`ll`.`tipo_libro` AS `tipo_libro`,`b`.`fecha_devolucion_estimada` AS `fecha_devolucion_estimada_libro`,date_format(`b`.`fecha_devolucion_estimada`,_utf8'%d-%m-%Y') AS `fecha_devolucion_estimada_libro_html`,`b`.`fecha_devolucion` AS `fecha_devolucion_libro`,date_format(`b`.`fecha_devolucion`,_utf8'%d-%m-%Y') AS `fecha_devolucion_libro_html`,`b`.`estado` AS `estado_libro` from ((((`site_gestion_inventario_libros_prestamos` `a` join `site_gestion_inventario_libros_prestamos_detalle` `b`) join `site_personas` `pa`) join `site_personas` `pb`) join `view_gestion_inventario_libros_libros` `ll`) where ((`a`.`id_prestamo` = `b`.`id_prestamo`) and (`pa`.`id_persona` = `a`.`id_usuario_solicitante`) and (`pb`.`id_persona` = `a`.`id_usuario_gestiona`) and (`b`.`id_libro` = `ll`.`id_libro`)) order by `a`.`id_prestamo`,`b`.`id_libro` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_gestion_solicitudes_encargados`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_gestion_solicitudes_encargados` AS select distinct `a`.`id_tipo_estado` AS `id_tipo_estado`,`a`.`tipo_estado` AS `tipo_estado`,`a`.`funcionalidad` AS `funcionalidad`,`a`.`orden` AS `orden`,`a`.`id_usuario_responsable` AS `id_usuario_responsable`,`a`.`user_id_responsable` AS `user_id_responsable`,`a`.`estado_siguiente_aprobado` AS `estado_siguiente_aprobado`,`a`.`estado_siguiente_rechazado` AS `estado_siguiente_rechazado`,`b`.`email` AS `email` from (`site_tipo_solicitudes_estados` `a` join `view_personas_site` `b`) where ((`a`.`user_id_responsable` = `b`.`user_id`) and (not((`a`.`user_id_responsable` like _latin1'')))) order by `a`.`orden` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_gestion_solicitudes_estados`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_gestion_solicitudes_estados` AS select `s`.`id_solicitud` AS `id_solicitud`,`s`.`fecha_solicitud` AS `fecha_solicitud`,`s`.`id_persona_solicitante` AS `id_persona_solicitante`,`s`.`id_persona_beneficiario` AS `id_persona_beneficiario`,`s`.`observacion` AS `observacion`,`s`.`id_tipo_solicitudes` AS `id_tipo_solicitudes`,`s`.`id_solicitud_estado` AS `id_solicitud_estado`,`e`.`id_tipo_estado` AS `id_tipo_estado`,`e`.`tipo_estado` AS `tipo_estado`,`e`.`funcionalidad` AS `funcionalidad`,`e`.`orden` AS `orden`,`e`.`id_usuario_responsable` AS `id_usuario_responsable`,`e`.`user_id_responsable` AS `user_id_responsable`,concat(`a`.`nombre`,_latin1' ',`a`.`apellido_paterno`) AS `solicitantes`,concat(`p`.`nombre`,_latin1' ',`p`.`apellido_paterno`) AS `beneficiario` from (((`site_gestion_solicitudes` `s` join `site_tipo_solicitudes_estados` `e`) join `auth_user_info` `a`) join `site_personas` `p`) where ((`e`.`id_tipo_estado` = `s`.`id_solicitud_estado`) and (`a`.`user_id` = `s`.`id_persona_solicitante`) and (`s`.`id_persona_beneficiario` = `p`.`id_persona`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_gestion_solicitudes_estados_historial`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_gestion_solicitudes_estados_historial` AS select `s`.`id_solicitud` AS `id_solicitud`,`s`.`id_solicitud_estado` AS `id_solicitud_estado`,`s`.`fecha` AS `fecha`,`s`.`fecha_cierre` AS `fecha_cierre`,`s`.`user_id_responsable` AS `user_id_responsable`,`s`.`comentarios` AS `comentarios`,`e`.`id_tipo_estado` AS `id_tipo_estado`,`e`.`tipo_estado` AS `tipo_estado`,`e`.`funcionalidad` AS `funcionalidad`,`e`.`orden` AS `orden`,`e`.`id_usuario_responsable` AS `id_usuario_responsable`,`t`.`tipo_solicitud` AS `tipo_solicitud`,`gs`.`fecha_solicitud` AS `fecha_solicitud`,`gs`.`id_persona_solicitante` AS `id_persona_solicitante`,`gs`.`id_persona_beneficiario` AS `id_persona_beneficiario`,`gs`.`id_tipo_solicitudes` AS `id_tipo_solicitudes` from (((`site_gestion_solicitudes` `gs` join `site_gestion_solicitudes_estados` `s`) join `site_tipo_solicitudes_estados` `e`) join `site_tipo_solicitudes_gestion` `t`) where ((`gs`.`id_solicitud` = `s`.`id_solicitud`) and (`e`.`id_tipo_estado` = `s`.`id_solicitud_estado`) and (`gs`.`id_tipo_solicitudes` = `t`.`id_tipo_solicitud`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_inscripcion_total`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_inscripcion_total` AS select count(`site_inscripcion`.`tipo_inscripcion`) AS `total`,`site_inscripcion`.`tipo_inscripcion` AS `tipo_inscripcion` from `site_inscripcion` where ((not((`site_inscripcion`.`email` like _latin1'psepulve@gmail.com'))) and (not((`site_inscripcion`.`email` like _latin1'pampli@gmail.com'))) and (not((`site_inscripcion`.`email` like _latin1'psepulveda@ciae.uchile.cl')))) group by `site_inscripcion`.`tipo_inscripcion` order by `site_inscripcion`.`tipo_inscripcion` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_inscripciones_diplomado_lenguaje_2022`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_inscripciones_diplomado_lenguaje_2022` AS select `site_inscripcion`.`email` AS `email`,`site_inscripcion`.`tipo_inscripcion` AS `tipo_inscripcion`,`site_inscripcion`.`fecha_actualizacion` AS `fecha_actualizacion`,`site_inscripcion`.`nombre` AS `nombre`,`site_inscripcion`.`apellidos` AS `apellidos`,`site_inscripcion`.`edad` AS `edad`,`site_inscripcion`.`institucion` AS `institucion`,`site_inscripcion`.`cargo` AS `cargo`,`site_inscripcion`.`actividad` AS `actividad`,`site_inscripcion`.`telefono_movil` AS `telefono_movil`,`site_inscripcion`.`ciudad` AS `ciudad`,`site_inscripcion`.`profesion` AS `profesion`,`site_inscripcion`.`comentario` AS `comentario`,concat(_latin1'<a href=\'http://www.ciae.uchile.cl/download.php?file=postulacion/',`site_inscripcion`.`archivo_extra1`,_latin1'\'>Ver archivo</a>') AS `descargar_archivo_extra1`,concat(_latin1'<a href=\'http://www.ciae.uchile.cl/download.php?file=postulacion/',`site_inscripcion`.`archivo_extra2`,_latin1'\'>Ver archivo</a>') AS `descargar_archivo_extra2` from `site_inscripcion` where (`site_inscripcion`.`tipo_inscripcion` like '2022_diplomado_lenguaje') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_inscripciones_diplomado_mejoramiento_2022`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_inscripciones_diplomado_mejoramiento_2022` AS select `site_inscripcion`.`email` AS `email`,`site_inscripcion`.`tipo_inscripcion` AS `tipo_inscripcion`,`site_inscripcion`.`fecha_actualizacion` AS `fecha_actualizacion`,`site_inscripcion`.`nombre` AS `nombre`,`site_inscripcion`.`apellidos` AS `apellidos`,`site_inscripcion`.`edad` AS `edad`,`site_inscripcion`.`institucion` AS `institucion`,`site_inscripcion`.`cargo` AS `cargo`,`site_inscripcion`.`actividad` AS `actividad`,`site_inscripcion`.`telefono_movil` AS `telefono_movil`,`site_inscripcion`.`ciudad` AS `ciudad`,`site_inscripcion`.`profesion` AS `profesion`,`site_inscripcion`.`comentario` AS `comentario`,concat(_latin1'<a href=\'http://www.ciae.uchile.cl/download.php?file=postulacion/',`site_inscripcion`.`archivo_extra1`,_latin1'\'>Ver archivo</a>') AS `descargar_archivo_extra1`,concat(_latin1'<a href=\'http://www.ciae.uchile.cl/download.php?file=postulacion/',`site_inscripcion`.`archivo_extra2`,_latin1'\'>Ver archivo</a>') AS `descargar_archivo_extra2` from `site_inscripcion` where (`site_inscripcion`.`tipo_inscripcion` like '2022_diplomado_mejoramiento') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_noticias_prensa_site`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_noticias_prensa_site` AS select `np`.`id_prensa` AS `id_prensa`,`np`.`titulo` AS `titulo`,`np`.`bajada` AS `bajada`,`np`.`url` AS `url`,`np`.`pdf` AS `pdf`,`np`.`fecha` AS `fecha`,`np`.`medio` AS `medio`,`np`.`tema` AS `tema`,`np`.`tipo_medio` AS `tipo_medio`,`np`.`tipo_cobertura` AS `tipo_cobertura`,`np`.`investigador` AS `investigador`,`np`.`tipo_aparicion` AS `tipo_aparicion`,`np`.`palabras_clave` AS `palabras_clave`,`np`.`palabras_clave` AS `palabra_clave`,`s`.`id_site` AS `id_site`,`s`.`nombre_site` AS `nombre_site`,`s`.`titulo_site` AS `titulo_site`,`np`.`id_area` AS `id_area`,if((`ar`.`id_area` = _utf8'6'),_latin1'S/I',`ar`.`area_es`) AS `area` from (((`site_noticias_prensa` `np` join `site_noticias_prensa_site` `ns` on((`np`.`id_prensa` = `ns`.`id_prensa`))) join `site_site` `s` on((`ns`.`id_site` = `s`.`id_site`))) join `site_areas` `ar` on((`np`.`id_area` = `ar`.`id_area`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_noticias_site`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_noticias_site` AS select `n`.`id_noticia` AS `id_noticia`,`n`.`fecha` AS `fecha`,`n`.`titulo` AS `titulo`,`n`.`bajada` AS `bajada`,`n`.`noticia` AS `noticia`,`n`.`autor` AS `autor`,`n`.`imagen` AS `imagen`,`n`.`imagen_bajada` AS `imagen_bajada`,`n`.`imagen2` AS `imagen2`,`n`.`imagen2_bajada` AS `imagen2_bajada`,`n`.`imagen3` AS `imagen3`,`n`.`imagen3_bajada` AS `imagen3_bajada`,`n`.`tipo` AS `tipo`,`n`.`trabajo` AS `trabajo`,`n`.`investigaciones_ie` AS `investigaciones_ie`,`n`.`cursos_ie` AS `cursos_ie`,`n`.`tipo_curso` AS `tipo_curso`,`n`.`noticia_tipo` AS `noticia_tipo`,`n`.`idioma` AS `idioma`,`ns`.`activo` AS `activo`,`ns`.`destacado` AS `destacado`,`ns`.`destacado_forzado` AS `destacado_forzado`,`n`.`tiene_galeria` AS `tiene_galeria`,`n`.`palabra_clave` AS `palabra_clave`,`n`.`palabra_clave` AS `palabras_clave`,`n`.`time_ingreso` AS `time_ingreso`,`n`.`fecha_evento` AS `fecha_evento`,`n`.`lugar_evento` AS `lugar_evento`,`n`.`lugar_curso` AS `lugar_curso`,`n`.`calendario_curso` AS `calendario_curso`,`n`.`plan_estudio` AS `plan_estudio`,`n`.`requisitos` AS `requisitos`,`n`.`perfil_egreso` AS `perfil_egreso`,`n`.`costo_evento` AS `costo_evento`,`n`.`modalidad_evento` AS `modalidad_evento`,`n`.`dirigido` AS `dirigido`,`n`.`certificado_evento` AS `certificado_evento`,`n`.`traduccion_evento` AS `traduccion_evento`,`n`.`contacto_evento` AS `contacto_evento`,`n`.`web_externo_evento` AS `web_externo_evento`,`n`.`inscripcion_evento` AS `inscripcion_evento`,`n`.`organizadores_evento` AS `organizadores_evento`,`n`.`usuario` AS `usuario`,`s`.`id_site` AS `id_site`,`s`.`nombre_site` AS `nombre_site`,`s`.`url_site` AS `url_site` from ((`site_noticias` `n` join `site_noticias_site` `ns` on((`n`.`id_noticia` = `ns`.`id_noticia`))) join `site_site` `s` on((`ns`.`id_site` = `s`.`id_site`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_personas`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_personas` AS select `p`.`id_persona` AS `id_persona`,`p`.`user_id` AS `user_id`,`p`.`nombre` AS `nombre`,`p`.`apellido_paterno` AS `apellido_paterno`,`p`.`apellido_materno` AS `apellido_materno`,`p`.`nombre_publicacion` AS `nombre_publicacion`,`p`.`fecha_nacimiento` AS `fecha_nacimiento`,date_format(`p`.`fecha_nacimiento`,_utf8'%d-%m-%Y') AS `fecha_nacimiento_html`,`p`.`genero` AS `genero`,`p`.`rut` AS `rut`,format(`p`.`rut`,0) AS `rut_html`,`p`.`rut_dv` AS `rut_dv`,`p`.`pasaporte` AS `pasaporte`,`p`.`afiliacion` AS `afiliacion`,`p`.`id_tipo_contrato` AS `id_tipo_contrato`,`tc`.`tipo_contrato` AS `tipo_contrato`,`tc`.`cumple_contrato` AS `cumple_contrato`,`p`.`facultad_externa` AS `facultad_externa`,`p`.`id_tipo_contrato_facultad` AS `id_tipo_contrato_facultad`,`p`.`id_universidad` AS `id_universidad`,`u`.`universidad` AS `universidad`,`p`.`direccion` AS `direccion`,`p`.`comuna_id` AS `comuna_id`,`rc`.`comuna` AS `comuna`,`rc`.`region` AS `region`,`p`.`pais_id` AS `pais_id`,`pa`.`pais` AS `pais`,`p`.`telefono_personal` AS `telefono_personal`,`p`.`grado` AS `grado`,`p`.`grado_academico_honorarios` AS `grado_academico_honorarios`,`p`.`cargo_gestion` AS `cargo_gestion`,`p`.`cargo` AS `cargo`,`p`.`cargo_en` AS `cargo_en`,`p`.`activo` AS `activo`,`p`.`telefono` AS `telefono`,`p`.`url` AS `url`,`p`.`imagen` AS `imagen`,`p`.`email` AS `email`,`p`.`email_alternativo` AS `email_alternativo`,`p`.`archivo_rut` AS `archivo_rut`,`p`.`cv` AS `cv`,`p`.`perfil` AS `perfil`,`p`.`anexo` AS `anexo`,`p`.`anexo_numero` AS `anexo_numero`,`p`.`fecha` AS `fecha_actualizacion`,`p`.`archivo_pasaporte` AS `archivo_pasaporte`,`p`.`archivo_cv` AS `archivo_cv`,`p`.`archivo_titulo` AS `archivo_titulo`,`p`.`datos_honorarios_completo` AS `datos_honorarios_completo` from ((((`site_personas` `p` join `site_tipo_contrato` `tc`) join `site_universidad` `u`) join `view_regiones_comunas` `rc`) join `common_paises` `pa`) where ((`tc`.`id_tipo_contrato` = `p`.`id_tipo_contrato`) and (`p`.`id_universidad` = `u`.`id_universidad`) and (`p`.`comuna_id` = `rc`.`comuna_id`) and (`pa`.`pais_id` = `p`.`pais_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_personas_areas`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_personas_areas` AS select `p`.`id_persona` AS `id_persona`,`p`.`user_id` AS `user_id`,`p`.`nombre` AS `nombre`,`p`.`apellido_paterno` AS `apellido_paterno`,`p`.`apellido_materno` AS `apellido_materno`,`p`.`nombre_publicacion` AS `nombre_publicacion`,`p`.`afiliacion` AS `afiliacion`,`p`.`id_universidad` AS `id_universidad`,`p`.`grado` AS `grado`,`p`.`cargo` AS `cargo`,`p`.`cargo_en` AS `cargo_en`,`p`.`telefono` AS `telefono`,`p`.`url` AS `url`,`p`.`imagen` AS `imagen`,`p`.`email` AS `email`,`p`.`cv` AS `cv_archivo`,`p`.`cv` AS `cv`,`p`.`perfil` AS `perfil`,`t`.`id_area` AS `id_area`,`t`.`area` AS `area`,`t`.`area_clave` AS `area_clave` from (`site_personas` `p` left join `view_personas_areas_simple` `t` on((`p`.`id_persona` = `t`.`id_persona`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_personas_areas_simple`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_personas_areas_simple` AS select `p`.`id_persona` AS `id_persona`,`a`.`id_area` AS `id_area`,`a`.`area_es` AS `area`,`a`.`clave` AS `area_clave` from (`site_areas` `a` join `site_personas_areas` `p`) where (`p`.`id_area` = `a`.`id_area`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_personas_noticias`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_personas_noticias` AS (select `ps`.`id_noticia` AS `id_noticia`,`p`.`id_persona` AS `id_persona`,`ps`.`id_tipo` AS `id_tipo_persona`,`ts`.`tipo` AS `tipo_persona`,`p`.`user_id` AS `user_id`,`p`.`nombre` AS `nombre`,`p`.`apellido_paterno` AS `apellido_paterno`,`p`.`apellido_materno` AS `apellido_materno`,`p`.`nombre_publicacion` AS `nombre_publicacion`,`p`.`rut` AS `rut`,`p`.`rut_dv` AS `rut_dv`,`p`.`pasaporte` AS `pasaporte`,`p`.`afiliacion` AS `afiliacion`,`p`.`id_tipo_contrato` AS `id_tipo_contrato`,`p`.`facultad_externa` AS `facultad_externa`,`p`.`id_tipo_contrato_facultad` AS `id_tipo_contrato_facultad`,`p`.`id_universidad` AS `id_universidad`,`p`.`direccion` AS `direccion`,`p`.`telefono_personal` AS `telefono_personal`,`p`.`grado` AS `grado`,`p`.`cargo_gestion` AS `cargo_gestion`,`p`.`cargo` AS `cargo`,`p`.`cargo_en` AS `cargo_en`,`p`.`activo` AS `activo`,`p`.`telefono` AS `telefono`,`p`.`url` AS `url`,`p`.`imagen` AS `imagen`,`p`.`email` AS `email`,`p`.`archivo_rut` AS `archivo_rut`,`p`.`cv` AS `cv`,`p`.`perfil` AS `perfil`,`p`.`anexo` AS `anexo`,`p`.`anexo_numero` AS `anexo_numero`,`p`.`fecha` AS `fecha`,`p`.`archivo_pasaporte` AS `archivo_pasaporte`,`p`.`archivo_cv` AS `archivo_cv`,`p`.`archivo_titulo` AS `archivo_titulo`,`ps`.`orden` AS `orden` from ((`site_personas` `p` join `site_noticias_persona` `ps` on((`p`.`id_persona` = `ps`.`id_persona`))) join `site_tipo_personas` `ts` on((`ps`.`id_tipo` = `ts`.`id_tipo`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_personas_site`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_personas_site` AS (select distinct `p`.`id_persona` AS `id_persona`,`p`.`user_id` AS `user_id`,`p`.`nombre` AS `nombre`,`p`.`apellido_paterno` AS `apellido_paterno`,`p`.`apellido_materno` AS `apellido_materno`,`p`.`nombre_publicacion` AS `nombre_publicacion`,`p`.`rut` AS `rut`,`p`.`rut_dv` AS `rut_dv`,`p`.`pasaporte` AS `pasaporte`,`p`.`afiliacion` AS `afiliacion`,`p`.`id_tipo_contrato` AS `id_tipo_contrato`,`p`.`facultad_externa` AS `facultad_externa`,`p`.`id_tipo_contrato_facultad` AS `id_tipo_contrato_facultad`,`p`.`id_universidad` AS `id_universidad`,`p`.`direccion` AS `direccion`,`p`.`telefono_personal` AS `telefono_personal`,`p`.`grado` AS `grado`,`p`.`cargo_gestion` AS `cargo_gestion`,`p`.`cargo` AS `cargo`,`p`.`cargo_en` AS `cargo_en`,`p`.`activo` AS `activo`,`p`.`telefono` AS `telefono`,`p`.`url` AS `url`,`p`.`imagen` AS `imagen`,`p`.`email` AS `email`,`p`.`archivo_rut` AS `archivo_rut`,`p`.`cv` AS `cv`,`p`.`perfil` AS `perfil`,`p`.`anexo` AS `anexo`,`p`.`anexo_numero` AS `anexo_numero`,`p`.`fecha` AS `fecha`,`p`.`archivo_pasaporte` AS `archivo_pasaporte`,`p`.`archivo_cv` AS `archivo_cv`,`p`.`archivo_titulo` AS `archivo_titulo`,`s`.`id_site` AS `id_site`,`s`.`nombre_site` AS `nombre_site`,`ps`.`cargo` AS `cargo_site`,`ps`.`orden` AS `orden_site` from ((`site_personas` `p` join `site_personas_site` `ps` on((`p`.`id_persona` = `ps`.`id_persona`))) join `site_site` `s` on((`ps`.`id_site` = `s`.`id_site`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_personas_site_tipo`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_personas_site_tipo` AS select `t`.`id_persona` AS `id_persona`,`t`.`user_id` AS `user_id`,`t`.`nombre` AS `nombre`,`t`.`apellido_paterno` AS `apellido_paterno`,`t`.`apellido_materno` AS `apellido_materno`,`t`.`nombre_publicacion` AS `nombre_publicacion`,`t`.`afiliacion` AS `afiliacion`,`t`.`id_universidad` AS `id_universidad`,`t`.`grado` AS `grado`,`t`.`cargo` AS `cargo`,`t`.`cargo_en` AS `cargo_en`,`t`.`telefono` AS `telefono`,`t`.`url` AS `url`,`t`.`imagen` AS `imagen`,`t`.`email` AS `email`,`t`.`cv_archivo` AS `cv_archivo`,`t`.`cv` AS `cv`,`t`.`perfil` AS `perfil`,`t`.`id_tipo` AS `id_tipo`,`t`.`tipo` AS `tipo`,`t`.`id_site` AS `id_site`,`s`.`nombre_site` AS `nombre_site`,`s`.`cargo_site` AS `cargo_site`,`s`.`orden_site` AS `orden_site`,`s`.`anexo` AS `anexo`,`s`.`anexo_numero` AS `anexo_numero`,`s`.`activo` AS `activo` from (`view_personas_tipo` `t` join `view_personas_site` `s`) where ((`t`.`id_persona` = `s`.`id_persona`) and (`t`.`id_site` = `s`.`id_site`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_personas_tipo`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_personas_tipo` AS select `p`.`id_persona` AS `id_persona`,`p`.`user_id` AS `user_id`,`p`.`nombre` AS `nombre`,`p`.`apellido_paterno` AS `apellido_paterno`,`p`.`apellido_materno` AS `apellido_materno`,`p`.`nombre_publicacion` AS `nombre_publicacion`,`p`.`afiliacion` AS `afiliacion`,`p`.`id_universidad` AS `id_universidad`,`p`.`grado` AS `grado`,`p`.`cargo` AS `cargo`,`p`.`cargo_en` AS `cargo_en`,`p`.`telefono` AS `telefono`,`p`.`url` AS `url`,`p`.`imagen` AS `imagen`,`p`.`email` AS `email`,`p`.`cv` AS `cv_archivo`,`p`.`cv` AS `cv`,`p`.`perfil` AS `perfil`,`t`.`id_tipo` AS `id_tipo`,`tp`.`tipo` AS `tipo`,`t`.`id_site` AS `id_site` from ((`site_personas` `p` join `site_personas_tipo` `t`) join `site_tipo_personas` `tp`) where ((`p`.`id_persona` = `t`.`id_persona`) and (`t`.`id_tipo` = `tp`.`id_tipo`)) order by `tp`.`id_tipo`,`p`.`apellido_paterno` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_postulaciones`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_postulaciones` AS select `site_postulaciones`.`email` AS `email`,`site_postulaciones`.`postulacion` AS `doctorado_postulacion`,`site_postulaciones`.`nombre` AS `nombre`,`site_postulaciones`.`apellidos` AS `apellidos`,`site_postulaciones`.`campo_investigacion` AS `campo_investigacion`,`site_postulaciones`.`institucion` AS `institucion`,`site_postulaciones`.`agno` AS `agno`,`site_postulaciones`.`informacion_adicional` AS `informacion_adicional`,concat(_latin1'<a href=\'http://www.ciae.uchile.cl/download.php?file=postulacion/',`site_postulaciones`.`archivo_motivacion`,_latin1'\'>Ver archivo</a>') AS `descargar_archivo_motivacion`,concat(_latin1'<a href=\'http://www.ciae.uchile.cl/download.php?file=postulacion/',`site_postulaciones`.`archivo_propuesta`,_latin1'\'>Ver archivo</a>') AS `descargar_archivo_propuesta`,concat(_latin1'<a href=\'http://www.ciae.uchile.cl/download.php?file=postulacion/',`site_postulaciones`.`archivo_cv`,_latin1'\'>Ver archivo</a>') AS `descargar_archivo_cv`,concat(_latin1'<a href=\'http://www.ciae.uchile.cl/download.php?file=postulacion/',`site_postulaciones`.`archivo_titulo`,_latin1'\'>Ver archvo</a>') AS `descargar_archivo_titulo`,concat(_latin1'<a href=\'http://www.ciae.uchile.cl/download.php?file=postulacion/',`site_postulaciones`.`carta1_archivo`,_latin1'\'>Ver archivo</a>') AS `descargar_archivo_carta_recomendacion1`,`site_postulaciones`.`carta1_nombre` AS `carta_recomendacion1_persona`,`site_postulaciones`.`carta1_email` AS `carta_recomendacion1_email_persona`,`site_postulaciones`.`carta1_descripcion` AS `carta_recomendacion1_afiliacion_persona`,concat(_latin1'<a href=\'http://www.ciae.uchile.cl/download.php?file=postulacion/',`site_postulaciones`.`carta2_archivo`,_latin1'\'>Ver archivo</a>') AS `descargar_archivo_carta_recomendacion2`,`site_postulaciones`.`carta2_nombre` AS `carta_recomendacion2_persona`,`site_postulaciones`.`carta2_email` AS `carta_recomendacion2_email_persona`,`site_postulaciones`.`carta2_descripcion` AS `carta_recomendacion2_afiliacion_persona`,concat(_latin1'<a href=\'http://www.ciae.uchile.cl/download.php?file=postulacion/',`site_postulaciones`.`carta3_archivo`,_latin1'\'>Ver archivo</a>') AS `descargar_archivo_carta_recomendacion3`,`site_postulaciones`.`carta3_nombre` AS `carta_recomendacion3_persona`,`site_postulaciones`.`carta3_email` AS `carta_recomendacion3_email_persona`,`site_postulaciones`.`carta3_descripcion` AS `carta_recomendacion3_afiliacion_persona` from `site_postulaciones` where (not((`site_postulaciones`.`email` like _latin1'psepulveda@ciae.uchile.cl'))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_profesores_academicos_noticias`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_profesores_academicos_noticias` AS (select `ps`.`id_noticia` AS `id_noticia`,`p`.`id_persona` AS `id_persona`,`p`.`user_id` AS `user_id`,`p`.`nombre` AS `nombrePA`,`p`.`apellido_paterno` AS `apellido_paternoPA`,`p`.`apellido_materno` AS `apellido_maternoPA`,`p`.`nombre_publicacion` AS `nombre_publicacionPA`,`p`.`rut` AS `rutPA`,`p`.`rut_dv` AS `rut_dvPA`,`p`.`pasaporte` AS `pasaportePA`,`p`.`afiliacion` AS `afiliacionPA`,`p`.`id_tipo_contrato` AS `id_tipo_contratoPA`,`p`.`facultad_externa` AS `facultad_externaPA`,`p`.`id_tipo_contrato_facultad` AS `id_tipo_contrato_facultadPA`,`p`.`id_universidad` AS `id_universidad`,`p`.`direccion` AS `direccionPA`,`p`.`telefono_personal` AS `telefono_personalPA`,`p`.`grado` AS `gradoPA`,`p`.`cargo_gestion` AS `cargo_gestionPA`,`p`.`cargo` AS `cargoPA`,`p`.`cargo_en` AS `cargo_enPA`,`p`.`activo` AS `activoPA`,`p`.`telefono` AS `telefonoPA`,`p`.`url` AS `urlPA`,`p`.`imagen` AS `imagenPA`,`p`.`email` AS `emailPA`,`p`.`archivo_rut` AS `archivo_rutPA`,`p`.`cv` AS `cv`,`p`.`perfil` AS `perfilPA`,`p`.`anexo` AS `anexoP`,`p`.`anexo_numero` AS `anexo_numeroPA`,`p`.`fecha` AS `fechaPA`,`p`.`archivo_pasaporte` AS `archivo_pasaportePA`,`p`.`archivo_cv` AS `archivo_cvPA`,`p`.`archivo_titulo` AS `archivo_tituloPA`,`ps`.`orden` AS `orden`,group_concat(`sa`.`area_es` separator ',') AS `area_aca` from (((`site_personas` `p` join `site_noticias_profesores_academicos` `ps` on((`p`.`id_persona` = `ps`.`id_persona`))) join `site_personas_areas` `spa` on((`p`.`id_persona` = `spa`.`id_persona`))) join `site_areas` `sa` on((`spa`.`id_area` = `sa`.`id_area`))) group by `p`.`id_persona`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_profesores_comite_noticias`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_profesores_comite_noticias` AS (select `ps`.`id_noticia` AS `id_noticia`,`p`.`id_persona` AS `id_persona`,`p`.`user_id` AS `user_id`,`p`.`nombre` AS `nombre`,`p`.`apellido_paterno` AS `apellido_paterno`,`p`.`apellido_materno` AS `apellido_materno`,`p`.`nombre_publicacion` AS `nombre_publicacion`,`p`.`rut` AS `rut`,`p`.`rut_dv` AS `rut_dv`,`p`.`pasaporte` AS `pasaporte`,`p`.`afiliacion` AS `afiliacion`,`p`.`id_tipo_contrato` AS `id_tipo_contrato`,`p`.`facultad_externa` AS `facultad_externa`,`p`.`id_tipo_contrato_facultad` AS `id_tipo_contrato_facultad`,`p`.`id_universidad` AS `id_universidad`,`p`.`direccion` AS `direccion`,`p`.`telefono_personal` AS `telefono_personal`,`p`.`grado` AS `grado`,`p`.`cargo_gestion` AS `cargo_gestion`,`p`.`cargo` AS `cargo`,`p`.`cargo_en` AS `cargo_en`,`p`.`activo` AS `activo`,`p`.`telefono` AS `telefono`,`p`.`url` AS `url`,`p`.`imagen` AS `imagen`,`p`.`email` AS `email`,`p`.`archivo_rut` AS `archivo_rut`,`p`.`cv` AS `cv`,`p`.`perfil` AS `perfil`,`p`.`anexo` AS `anexo`,`p`.`anexo_numero` AS `anexo_numero`,`p`.`fecha` AS `fecha`,`p`.`archivo_pasaporte` AS `archivo_pasaporte`,`p`.`archivo_cv` AS `archivo_cv`,`p`.`archivo_titulo` AS `archivo_titulo`,`ps`.`orden` AS `orden`,group_concat(`sa`.`area_es` separator ', ') AS `area_es`,`ps`.`tipo` AS `tipo` from (((`site_personas` `p` join `site_noticias_profesores_comite` `ps` on((`p`.`id_persona` = `ps`.`id_persona`))) join `site_personas_areas` `spa` on((`p`.`id_persona` = `spa`.`id_persona`))) join `site_areas` `sa` on((`spa`.`id_area` = `sa`.`id_area`))) group by `p`.`id_persona`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_profesores_comite_site`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_profesores_comite_site` AS (select distinct `p`.`id_persona` AS `id_persona`,`p`.`user_id` AS `user_id`,`p`.`nombre` AS `nombre`,`p`.`apellido_paterno` AS `apellido_paterno`,`p`.`apellido_materno` AS `apellido_materno`,`p`.`nombre_publicacion` AS `nombre_publicacion`,`p`.`rut` AS `rut`,`p`.`rut_dv` AS `rut_dv`,`p`.`pasaporte` AS `pasaporte`,`p`.`afiliacion` AS `afiliacion`,`p`.`id_tipo_contrato` AS `id_tipo_contrato`,`p`.`facultad_externa` AS `facultad_externa`,`p`.`id_tipo_contrato_facultad` AS `id_tipo_contrato_facultad`,`p`.`id_universidad` AS `id_universidad`,`p`.`direccion` AS `direccion`,`p`.`telefono_personal` AS `telefono_personal`,`p`.`grado` AS `grado`,`p`.`cargo_gestion` AS `cargo_gestion`,`p`.`cargo` AS `cargo`,`p`.`cargo_en` AS `cargo_en`,`p`.`activo` AS `activo`,`p`.`telefono` AS `telefono`,`p`.`url` AS `url`,`p`.`imagen` AS `imagen`,`p`.`email` AS `email`,`p`.`archivo_rut` AS `archivo_rut`,`p`.`cv` AS `cv`,`p`.`perfil` AS `perfil`,`p`.`anexo` AS `anexo`,`p`.`anexo_numero` AS `anexo_numero`,`p`.`fecha` AS `fecha`,`p`.`archivo_pasaporte` AS `archivo_pasaporte`,`p`.`archivo_cv` AS `archivo_cv`,`p`.`archivo_titulo` AS `archivo_titulo`,`s`.`id_site` AS `id_site`,`s`.`nombre_site` AS `nombre_site`,`ps`.`cargo` AS `cargo_site`,`ps`.`orden` AS `orden_site` from ((`site_personas` `p` join `site_personas_site` `ps` on((`p`.`id_persona` = `ps`.`id_persona`))) join `site_site` `s` on((`ps`.`id_site` = `s`.`id_site`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_profesores_noticias`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_profesores_noticias` AS (select `ps`.`id_noticia` AS `id_noticia`,`p`.`id_persona` AS `id_persona`,`p`.`user_id` AS `user_id`,`p`.`nombre` AS `nombreP`,`p`.`apellido_paterno` AS `apellido_paternoP`,`p`.`apellido_materno` AS `apellido_maternoP`,`p`.`nombre_publicacion` AS `nombre_publicacionP`,`p`.`rut` AS `rutP`,`p`.`rut_dv` AS `rut_dvP`,`p`.`pasaporte` AS `pasaporteP`,`p`.`afiliacion` AS `afiliacionP`,`p`.`id_tipo_contrato` AS `id_tipo_contratoP`,`p`.`facultad_externa` AS `facultad_externaP`,`p`.`id_tipo_contrato_facultad` AS `id_tipo_contrato_facultadP`,`p`.`id_universidad` AS `id_universidad`,`p`.`direccion` AS `direccionP`,`p`.`telefono_personal` AS `telefono_personalP`,`p`.`grado` AS `gradoP`,`p`.`cargo_gestion` AS `cargo_gestionP`,`p`.`cargo` AS `cargoP`,`p`.`cargo_en` AS `cargo_enP`,`p`.`activo` AS `activoP`,`p`.`telefono` AS `telefonoP`,`p`.`url` AS `urlP`,`p`.`imagen` AS `imagenP`,`p`.`email` AS `emailP`,`p`.`archivo_rut` AS `archivo_rutP`,`p`.`cv` AS `cv`,`p`.`perfil` AS `perfilP`,`p`.`anexo` AS `anexoP`,`p`.`anexo_numero` AS `anexo_numeroP`,`p`.`fecha` AS `fechaP`,`p`.`archivo_pasaporte` AS `archivo_pasaporteP`,`p`.`archivo_cv` AS `archivo_cvP`,`p`.`archivo_titulo` AS `archivo_tituloP`,`ps`.`orden` AS `orden`,group_concat(`sa`.`area_es` separator ',') AS `area_pro` from (((`site_personas` `p` join `site_noticias_profesores` `ps` on((`p`.`id_persona` = `ps`.`id_persona`))) join `site_personas_areas` `spa` on((`p`.`id_persona` = `spa`.`id_persona`))) join `site_areas` `sa` on((`spa`.`id_area` = `sa`.`id_area`))) group by `p`.`id_persona`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_profesores_visitantes_noticias`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_profesores_visitantes_noticias` AS (select `ps`.`id_noticia` AS `id_noticia`,`p`.`id_persona` AS `id_persona`,`p`.`user_id` AS `user_id`,`p`.`nombre` AS `nombrePV`,`p`.`apellido_paterno` AS `apellido_paternoPV`,`p`.`apellido_materno` AS `apellido_maternoPV`,`p`.`nombre_publicacion` AS `nombre_publicacionPV`,`p`.`rut` AS `rutPV`,`p`.`rut_dv` AS `rut_dvPV`,`p`.`pasaporte` AS `pasaportePV`,`p`.`afiliacion` AS `afiliacionPV`,`p`.`id_tipo_contrato` AS `id_tipo_contratoPV`,`p`.`facultad_externa` AS `facultad_externaPV`,`p`.`id_tipo_contrato_facultad` AS `id_tipo_contrato_facultadPV`,`p`.`id_universidad` AS `id_universidad`,`p`.`direccion` AS `direccionPV`,`p`.`telefono_personal` AS `telefono_personalPV`,`p`.`grado` AS `gradoPV`,`p`.`cargo_gestion` AS `cargo_gestionPV`,`p`.`cargo` AS `cargoPV`,`p`.`cargo_en` AS `cargo_enPV`,`p`.`activo` AS `activoPV`,`p`.`telefono` AS `telefonoPV`,`p`.`url` AS `urlPV`,`p`.`imagen` AS `imagenPV`,`p`.`email` AS `emailPV`,`p`.`archivo_rut` AS `archivo_rutPV`,`p`.`cv` AS `cv`,`p`.`perfil` AS `perfilPV`,`p`.`anexo` AS `anexoP`,`p`.`anexo_numero` AS `anexo_numeroPV`,`p`.`fecha` AS `fechaPV`,`p`.`archivo_pasaporte` AS `archivo_pasaportePV`,`p`.`archivo_cv` AS `archivo_cvPV`,`p`.`archivo_titulo` AS `archivo_tituloPV`,`ps`.`orden` AS `orden` from (`site_personas` `p` join `site_noticias_profesores_visitantes` `ps` on((`p`.`id_persona` = `ps`.`id_persona`)))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_proyecto_detalle`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_proyecto_detalle` AS select `a`.`id_proyecto` AS `id_proyecto`,`a`.`activo` AS `activo`,`a`.`proyecto` AS `proyecto`,`a`.`proyecto_en` AS `proyecto_en`,`a`.`codigo` AS `codigo`,`a`.`id_tipo` AS `id_tipo`,`a`.`id_tipo_area_proyecto` AS `id_tipo_area_proyecto`,`a`.`agno_inicio` AS `agno_inicio`,`b`.`mes_inicio` AS `mes_inicio`,`a`.`url` AS `url`,`a`.`antecedentes` AS `antecedentes`,`a`.`objetivos` AS `objetivos`,`a`.`metodologia` AS `metodologia`,`a`.`periodo` AS `periodo`,`a`.`financiamiento` AS `financiamiento`,`a`.`productos` AS `productos`,`a`.`mandante` AS `mandante`,`a`.`cooperacion_nacional` AS `cooperacion_nacional`,`a`.`cooperacion_internacional` AS `cooperacion_internacional`,`a`.`tipo_proyecto` AS `tipo_proyecto`,`b`.`tipo_area_proyecto` AS `tipo_area_proyecto` from (`view_proyecto_tipo` `a` join `view_proyecto_tipo_area` `b`) where (`a`.`id_proyecto` = `b`.`id_proyecto`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_proyecto_tipo`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_proyecto_tipo` AS select `a`.`id_proyecto` AS `id_proyecto`,`a`.`activo` AS `activo`,`a`.`proyecto` AS `proyecto`,`a`.`proyecto_en` AS `proyecto_en`,`a`.`codigo` AS `codigo`,`a`.`id_tipo` AS `id_tipo`,`a`.`id_tipo_area_proyecto` AS `id_tipo_area_proyecto`,`a`.`agno_inicio` AS `agno_inicio`,`a`.`url` AS `url`,`a`.`antecedentes` AS `antecedentes`,`a`.`objetivos` AS `objetivos`,`a`.`metodologia` AS `metodologia`,`a`.`periodo` AS `periodo`,`a`.`financiamiento` AS `financiamiento`,`a`.`productos` AS `productos`,`a`.`mandante` AS `mandante`,`a`.`cooperacion_nacional` AS `cooperacion_nacional`,`a`.`cooperacion_internacional` AS `cooperacion_internacional`,`b`.`tipo` AS `tipo_proyecto` from (`site_proyectos` `a` left join `site_tipo_proyectos` `b` on((`a`.`id_tipo` = `b`.`id_tipo`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_proyecto_tipo_area`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_proyecto_tipo_area` AS select `a`.`id_proyecto` AS `id_proyecto`,`a`.`activo` AS `activo`,`a`.`proyecto` AS `proyecto`,`a`.`proyecto_en` AS `proyecto_en`,`a`.`codigo` AS `codigo`,`a`.`id_tipo` AS `id_tipo`,`a`.`id_tipo_area_proyecto` AS `id_tipo_area_proyecto`,`a`.`agno_inicio` AS `agno_inicio`,`a`.`mes_inicio` AS `mes_inicio`,`a`.`url` AS `url`,`a`.`antecedentes` AS `antecedentes`,`a`.`objetivos` AS `objetivos`,`a`.`metodologia` AS `metodologia`,`a`.`periodo` AS `periodo`,`a`.`financiamiento` AS `financiamiento`,`a`.`productos` AS `productos`,`a`.`mandante` AS `mandante`,`a`.`cooperacion_nacional` AS `cooperacion_nacional`,`a`.`cooperacion_internacional` AS `cooperacion_internacional`,`b`.`tipo` AS `tipo_area_proyecto` from (`site_proyectos` `a` left join `site_tipo_proyectos_area` `b` on((`a`.`id_tipo_area_proyecto` = `b`.`id_tipo`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_proyectos_personas`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_proyectos_personas` AS select `pe`.`id_proyecto` AS `id_proyecto`,`pr`.`proyecto` AS `proyecto`,`pe`.`id_persona` AS `id_persona`,`ps`.`nombre` AS `nombre`,`ps`.`apellido_paterno` AS `apellido_paterno`,`ps`.`apellido_materno` AS `apellido_materno`,`pe`.`cargo` AS `cargo`,`pe`.`orden` AS `orden`,`pe`.`nombre_extra` AS `nombre_extra` from ((`site_proyectos_personas` `pe` join `site_proyectos` `pr`) join `site_personas` `ps`) where ((`pe`.`id_proyecto` = `pr`.`id_proyecto`) and (`pr`.`activo` = 1) and (`pe`.`id_persona` = `ps`.`id_persona`)) order by `pe`.`id_proyecto`,`pe`.`orden` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_proyectos_site`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_proyectos_site` AS select `p`.`id_proyecto` AS `id_proyecto`,`p`.`activo` AS `activo`,`p`.`proyecto` AS `proyecto`,`p`.`proyecto_en` AS `proyecto_en`,`p`.`codigo` AS `codigo`,`p`.`imagen` AS `imagen`,`p`.`id_tipo` AS `id_tipo`,`p`.`id_tipo_area_proyecto` AS `id_tipo_area_proyecto`,`p`.`agno_inicio` AS `agno_inicio`,`p`.`mes_inicio` AS `mes_inicio`,`p`.`agno_termino` AS `agno_termino`,`p`.`url` AS `url`,`p`.`antecedentes` AS `antecedentes`,`p`.`objetivos` AS `objetivos`,`p`.`metodologia` AS `metodologia`,`p`.`periodo` AS `periodo`,`p`.`financiamiento` AS `financiamiento`,`p`.`productos` AS `productos`,`p`.`palabras_clave` AS `palabras_clave`,`p`.`mandante` AS `mandante`,`p`.`cooperacion_nacional` AS `cooperacion_nacional`,`p`.`cooperacion_internacional` AS `cooperacion_internacional`,`p`.`seleccionado_area` AS `seleccionado_area`,`s`.`id_site` AS `id_site`,`s`.`nombre_site` AS `nombre_site`,`sp`.`vigente` AS `vigente` from ((`site_proyectos` `p` join `site_proyectos_site` `sp` on((`p`.`id_proyecto` = `sp`.`id_proyecto`))) join `site_site` `s` on((`sp`.`id_site` = `s`.`id_site`))) group by `sp`.`id_proyecto`,`sp`.`id_site` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_publicacion_persona`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_publicacion_persona` AS select `a`.`id_publicaciones` AS `id_publicaciones`,`a`.`id_persona` AS `id_persona`,`a`.`persona_nombre` AS `persona_nombre`,`a`.`orden` AS `orden`,`b`.`nombre` AS `nombre`,`b`.`apellido_paterno` AS `apellido_paterno`,`b`.`apellido_materno` AS `apellido_materno`,`b`.`nombre_publicacion` AS `nombre_publicacion` from (`site_publicaciones_persona` `a` join `site_personas` `b` on((`a`.`id_persona` = `b`.`id_persona`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_publicaciones_area`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_publicaciones_area` AS select `a`.`id_publicaciones` AS `id_publicaciones`,`a`.`fecha` AS `fecha`,`a`.`titulo` AS `titulo`,`a`.`resumen` AS `resumen`,`a`.`titulo_en` AS `titulo_en`,`a`.`doi` AS `doi`,`a`.`isi` AS `isi`,`a`.`mes` AS `mes`,`a`.`mes_numero` AS `mes_numero`,`a`.`agno` AS `agno`,`a`.`texto` AS `texto`,`a`.`documento` AS `documento`,`a`.`link` AS `link`,`a`.`numero` AS `numero`,`a`.`id_tipo` AS `id_tipo`,`a`.`id_area` AS `id_area`,`a`.`activo` AS `activo`,`a`.`destacado` AS `destacado`,`a`.`ver_detalle` AS `ver_detalle`,`b`.`area_es` AS `area`,`b`.`area_en` AS `area_en` from (`site_publicaciones` `a` left join `site_areas` `b` on((`a`.`id_area` = `b`.`id_area`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_publicaciones_detalle`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_publicaciones_detalle` AS select `a`.`id_publicaciones` AS `id_publicaciones`,date_format(from_unixtime(`a`.`fecha`),_utf8'%d-%m-%Y %H:%i:%s') AS `fecha`,`a`.`titulo` AS `titulo`,`a`.`resumen` AS `resumen`,`a`.`titulo_en` AS `titulo_en`,`a`.`doi` AS `doi`,`a`.`isi` AS `isi`,`a`.`mes` AS `mes`,`a`.`mes_numero` AS `mes_numero`,`a`.`agno` AS `agno`,`a`.`texto` AS `texto`,`a`.`documento` AS `documento`,`a`.`link` AS `link`,`a`.`numero` AS `numero`,`a`.`id_tipo` AS `id_tipo`,`a`.`id_area` AS `id_area`,`a`.`activo` AS `activo`,`a`.`destacado` AS `destacado`,`a`.`ver_detalle` AS `ver_detalle`,`a`.`tipo_publicacion` AS `tipo_publicacion`,`b`.`area` AS `area` from (`view_publicaciones_tipo` `a` join `view_publicaciones_area` `b`) where (`a`.`id_publicaciones` = `b`.`id_publicaciones`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_publicaciones_persona`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_publicaciones_persona` AS select `site_publicaciones_persona`.`id_publicaciones` AS `id_publicaciones`,`site_publicaciones_persona`.`id_persona` AS `id_persona`,`site_publicaciones_persona`.`persona_nombre` AS `persona_nombre`,`site_publicaciones_persona`.`orden` AS `orden` from `site_publicaciones_persona` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_publicaciones_site`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_publicaciones_site` AS select `p`.`id_publicaciones` AS `id_publicaciones`,`p`.`fecha` AS `fecha`,`p`.`titulo` AS `titulo`,`p`.`resumen` AS `resumen`,`p`.`titulo_en` AS `titulo_en`,`p`.`doi` AS `doi`,`p`.`isi` AS `isi`,`p`.`mes` AS `mes`,`p`.`mes_numero` AS `mes_numero`,`p`.`agno` AS `agno`,`p`.`factor_Q` AS `factor_Q`,`p`.`cooperacion_internacional` AS `cooperacion_internacional`,`p`.`cooperacion_nacional` AS `cooperacion_nacional`,`p`.`texto` AS `texto`,`p`.`documento` AS `documento`,`p`.`documento_publico` AS `documento_publico`,`p`.`link` AS `link`,`p`.`numero` AS `numero`,`p`.`id_tipo` AS `id_tipo`,`p`.`id_area` AS `id_area`,`p`.`activo` AS `activo`,`p`.`destacado` AS `destacado`,`p`.`ver_detalle` AS `ver_detalle`,`p`.`seleccionado` AS `seleccionado`,`p`.`palabras_clave` AS `palabras_clave`,`p`.`bib_palabra_clave` AS `bib_palabra_clave`,`p`.`bib_ubicacion` AS `bib_ubicacion`,`p`.`bib_ciudad` AS `bib_ciudad`,`p`.`bib_pais` AS `bib_pais`,`p`.`bib_edicion` AS `bib_edicion`,`p`.`bib_editor` AS `bib_editor`,`p`.`bib_editorial` AS `bib_editorial`,`p`.`bib_institucion` AS `bib_institucion`,`p`.`bib_revista` AS `bib_revista`,`p`.`bib_libro` AS `bib_libro`,`p`.`bib_capitulo` AS `bib_capitulo`,`p`.`bib_numero` AS `bib_numero`,`p`.`bib_paginas` AS `bib_paginas`,`p`.`bib_series` AS `bib_series`,`p`.`bib_volume` AS `bib_volume`,`p`.`bib_escuela` AS `bib_escuela`,`p`.`bib_tipo_estudio` AS `bib_tipo_estudio`,`p`.`bib_respaldo_tipo_ingreso` AS `bib_respaldo_tipo_ingreso`,`p`.`bib_respaldo_comentario` AS `bib_respaldo_comentario`,`p`.`bib_respaldo_autor` AS `bib_respaldo_autor`,`p`.`bib_respaldo_archivo` AS `bib_respaldo_archivo`,`s`.`id_site` AS `id_site`,`s`.`nombre_site` AS `nombre_site`,`s`.`titulo_site` AS `titulo_site`,`s`.`url_site` AS `url_site` from ((`site_publicaciones` `p` join `site_publicaciones_site` `ps`) join `site_site` `s`) where ((`p`.`id_publicaciones` = `ps`.`id_publicaciones`) and (`ps`.`id_site` = `s`.`id_site`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_publicaciones_tipo`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_publicaciones_tipo` AS select `a`.`id_publicaciones` AS `id_publicaciones`,`a`.`fecha` AS `fecha`,`a`.`titulo` AS `titulo`,`a`.`resumen` AS `resumen`,`a`.`titulo_en` AS `titulo_en`,`a`.`doi` AS `doi`,`a`.`isi` AS `isi`,`a`.`mes` AS `mes`,`a`.`mes_numero` AS `mes_numero`,`a`.`agno` AS `agno`,`a`.`texto` AS `texto`,`a`.`documento` AS `documento`,`a`.`link` AS `link`,`a`.`numero` AS `numero`,`a`.`id_tipo` AS `id_tipo`,`a`.`id_area` AS `id_area`,`a`.`activo` AS `activo`,`a`.`destacado` AS `destacado`,`a`.`ver_detalle` AS `ver_detalle`,`b`.`tipo` AS `tipo_publicacion` from (`site_publicaciones` `a` left join `site_tipo_publicaciones` `b` on((`a`.`id_tipo` = `b`.`id_tipo`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_recursos_site`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_recursos_site` AS select `rec`.`id_recurso` AS `id_recurso`,`rec`.`fecha` AS `fecha`,`rec`.`titulo` AS `titulo`,`rec`.`bajada` AS `bajada`,`rec`.`descripcion` AS `descripcion`,`rec`.`autor` AS `autor`,`rec`.`editorial` AS `editorial`,`rec`.`paginas` AS `paginas`,`rec`.`isbn` AS `isbn`,`rec`.`extra` AS `extra`,`rec`.`imagen` AS `imagen`,`rs`.`id_tipo` AS `id_tipo`,`tr`.`tipo` AS `tipo`,`tr`.`orden` AS `tipo_orden`,`rec`.`agno` AS `agno`,`rec`.`archivo` AS `archivo`,`rec`.`video` AS `video`,`rec`.`video_lista` AS `video_lista`,`rec`.`libro_digital` AS `libro_digital`,`rec`.`iframe` AS `iframe`,`rec`.`link_externo` AS `link_externo`,`rec`.`link_externo_texto` AS `link_externo_texto`,`rec`.`idioma` AS `idioma`,`rs`.`activo` AS `activo`,`rs`.`destacado` AS `destacado`,`rs`.`id_tipo_estructura` AS `id_tipo_estructura`,`re`.`tipo_estructura` AS `tipo_estructura`,`re`.`orden` AS `tipo_estructura_orden`,`re`.`opcion_site` AS `tipo_estructura_opcion_site`,`re`.`opcion_site` AS `opcion_site`,`rec`.`palabras_clave` AS `palabras_clave`,`rec`.`time_ingreso` AS `time_ingreso`,`rec`.`usuario` AS `usuario`,`s`.`id_site` AS `id_site`,`s`.`nombre_site` AS `nombre_site`,`s`.`titulo_site` AS `titulo_site`,`s`.`url_site` AS `url_site`,concat(`tr`.`tipo`,'@',`re`.`tipo_estructura`) AS `tipo_estructura_combinada` from ((((`site_recursos` `rec` join `site_recursos_site` `rs`) join `site_site` `s`) join `site_tipo_recursos` `tr`) join `site_tipo_recursos_estructura` `re`) where ((`rs`.`id_site` = `s`.`id_site`) and (`rec`.`id_recurso` = `rs`.`id_recurso`) and (`tr`.`id_tipo` = `rs`.`id_tipo`) and (`rs`.`id_tipo_estructura` = `re`.`id_tipo_estructura`)) order by `rec`.`id_recurso` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_regiones_comunas`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_regiones_comunas` AS select `c`.`comuna_id` AS `comuna_id`,`c`.`comuna` AS `comuna`,`c`.`orden` AS `orden_comuna`,`r`.`region_id` AS `region_id`,`r`.`region` AS `region`,`r`.`orden` AS `orden_region` from (`common_region` `r` join `common_comuna` `c`) where (`c`.`region_id` = `r`.`region_id`) order by `r`.`orden`,`c`.`orden` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_site_eventos_informe`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_site_eventos_informe` AS select `site_eventos_informe`.`id_evento` AS `id_evento`,`site_eventos_informe`.`id_noticia` AS `id_noticia`,concat(`site_eventos_informe`.`id_inscripcion`,'_presencial') AS `id_inscripcion`,`site_eventos_informe`.`fecha_inicio` AS `fecha_inicio`,`site_eventos_informe`.`fecha_termino` AS `fecha_termino`,`site_eventos_informe`.`info_completa` AS `info_completa`,`site_eventos_informe`.`nombre` AS `nombre`,`site_eventos_informe`.`tipo_evento` AS `tipo_evento`,`site_eventos_informe`.`total_inscritos_presencial` AS `total_inscritos_presencial`,`site_eventos_informe`.`total_inscritos_online` AS `total_inscritos_online`,`site_eventos_informe`.`total_asistencia` AS `total_asistencia`,`site_eventos_informe`.`institucion_co_organizadora` AS `institucion_co_organizadora`,`site_eventos_informe`.`link_inscripcion` AS `link_inscripcion`,`site_eventos_informe`.`inscripcion_opcion_menu` AS `inscripcion_opcion_menu`,`site_eventos_informe`.`inscripcion_fecha_cierre` AS `inscripcion_fecha_cierre`,`site_eventos_informe`.`inscripcion_cupos_maximo` AS `inscripcion_cupos_maximo`,`site_eventos_informe`.`email` AS `email`,`site_eventos_informe`.`ubicacion` AS `ubicacion`,`site_eventos_informe`.`ubicacion_email` AS `ubicacion_email`,`site_eventos_informe`.`ubicacion_email_online` AS `ubicacion_email_online`,`site_eventos_informe`.`date_texto` AS `date_texto`,`site_eventos_informe`.`date_texto_email` AS `date_texto_email`,`site_eventos_informe`.`programa` AS `programa`,`site_eventos_informe`.`costo_texto_extras` AS `costo_texto_extras`,`site_eventos_informe`.`listas` AS `listas`,`site_eventos_informe`.`logos` AS `logos`,`site_eventos_informe`.`tipo_formulario_confirmacion` AS `tipo_formulario_confirmacion`,`site_eventos_informe`.`mensaje_extra_notificacion` AS `mensaje_extra_notificacion`,`site_eventos_informe`.`link_online` AS `link_online`,`site_eventos_informe`.`certificado_encabezado_fech` AS `certificado_encabezado_fech`,`site_eventos_informe`.`certificado_fec` AS `certificado_fec`,`site_eventos_informe`.`certificado_horas` AS `certificado_horas`,`site_eventos_informe`.`certificado_ubicacion` AS `certificado_ubicacion`,`site_eventos_informe`.`certificado_organizadores` AS `certificado_organizadores` from `site_eventos_informe` where (not((`site_eventos_informe`.`id_inscripcion` like ''))) union select `site_eventos_informe`.`id_evento` AS `id_evento`,`site_eventos_informe`.`id_noticia` AS `id_noticia`,concat(`site_eventos_informe`.`id_inscripcion`,'_online') AS `id_inscripcion`,`site_eventos_informe`.`fecha_inicio` AS `fecha_inicio`,`site_eventos_informe`.`fecha_termino` AS `fecha_termino`,`site_eventos_informe`.`info_completa` AS `info_completa`,`site_eventos_informe`.`nombre` AS `nombre`,`site_eventos_informe`.`tipo_evento` AS `tipo_evento`,`site_eventos_informe`.`total_inscritos_presencial` AS `total_inscritos_presencial`,`site_eventos_informe`.`total_inscritos_online` AS `total_inscritos_online`,`site_eventos_informe`.`total_asistencia` AS `total_asistencia`,`site_eventos_informe`.`institucion_co_organizadora` AS `institucion_co_organizadora`,`site_eventos_informe`.`link_inscripcion` AS `link_inscripcion`,`site_eventos_informe`.`inscripcion_opcion_menu` AS `inscripcion_opcion_menu`,`site_eventos_informe`.`inscripcion_fecha_cierre` AS `inscripcion_fecha_cierre`,`site_eventos_informe`.`inscripcion_cupos_maximo` AS `inscripcion_cupos_maximo`,`site_eventos_informe`.`email` AS `email`,`site_eventos_informe`.`ubicacion` AS `ubicacion`,`site_eventos_informe`.`ubicacion_email` AS `ubicacion_email`,`site_eventos_informe`.`ubicacion_email_online` AS `ubicacion_email_online`,`site_eventos_informe`.`date_texto` AS `date_texto`,`site_eventos_informe`.`date_texto_email` AS `date_texto_email`,`site_eventos_informe`.`programa` AS `programa`,`site_eventos_informe`.`costo_texto_extras` AS `costo_texto_extras`,`site_eventos_informe`.`listas` AS `listas`,`site_eventos_informe`.`logos` AS `logos`,`site_eventos_informe`.`tipo_formulario_confirmacion` AS `tipo_formulario_confirmacion`,`site_eventos_informe`.`mensaje_extra_notificacion` AS `mensaje_extra_notificacion`,`site_eventos_informe`.`link_online` AS `link_online`,`site_eventos_informe`.`certificado_encabezado_fech` AS `certificado_encabezado_fech`,`site_eventos_informe`.`certificado_fec` AS `certificado_fec`,`site_eventos_informe`.`certificado_horas` AS `certificado_horas`,`site_eventos_informe`.`certificado_ubicacion` AS `certificado_ubicacion`,`site_eventos_informe`.`certificado_organizadores` AS `certificado_organizadores` from `site_eventos_informe` where (not((`site_eventos_informe`.`id_inscripcion` like ''))) union select `site_eventos_informe`.`id_evento` AS `id_evento`,`site_eventos_informe`.`id_noticia` AS `id_noticia`,`site_eventos_informe`.`id_inscripcion` AS `id_inscripcion`,`site_eventos_informe`.`fecha_inicio` AS `fecha_inicio`,`site_eventos_informe`.`fecha_termino` AS `fecha_termino`,`site_eventos_informe`.`info_completa` AS `info_completa`,`site_eventos_informe`.`nombre` AS `nombre`,`site_eventos_informe`.`tipo_evento` AS `tipo_evento`,`site_eventos_informe`.`total_inscritos_presencial` AS `total_inscritos_presencial`,`site_eventos_informe`.`total_inscritos_online` AS `total_inscritos_online`,`site_eventos_informe`.`total_asistencia` AS `total_asistencia`,`site_eventos_informe`.`institucion_co_organizadora` AS `institucion_co_organizadora`,`site_eventos_informe`.`link_inscripcion` AS `link_inscripcion`,`site_eventos_informe`.`inscripcion_opcion_menu` AS `inscripcion_opcion_menu`,`site_eventos_informe`.`inscripcion_fecha_cierre` AS `inscripcion_fecha_cierre`,`site_eventos_informe`.`inscripcion_cupos_maximo` AS `inscripcion_cupos_maximo`,`site_eventos_informe`.`email` AS `email`,`site_eventos_informe`.`ubicacion` AS `ubicacion`,`site_eventos_informe`.`ubicacion_email` AS `ubicacion_email`,`site_eventos_informe`.`ubicacion_email_online` AS `ubicacion_email_online`,`site_eventos_informe`.`date_texto` AS `date_texto`,`site_eventos_informe`.`date_texto_email` AS `date_texto_email`,`site_eventos_informe`.`programa` AS `programa`,`site_eventos_informe`.`costo_texto_extras` AS `costo_texto_extras`,`site_eventos_informe`.`listas` AS `listas`,`site_eventos_informe`.`logos` AS `logos`,`site_eventos_informe`.`tipo_formulario_confirmacion` AS `tipo_formulario_confirmacion`,`site_eventos_informe`.`mensaje_extra_notificacion` AS `mensaje_extra_notificacion`,`site_eventos_informe`.`link_online` AS `link_online`,`site_eventos_informe`.`certificado_encabezado_fech` AS `certificado_encabezado_fech`,`site_eventos_informe`.`certificado_fec` AS `certificado_fec`,`site_eventos_informe`.`certificado_horas` AS `certificado_horas`,`site_eventos_informe`.`certificado_ubicacion` AS `certificado_ubicacion`,`site_eventos_informe`.`certificado_organizadores` AS `certificado_organizadores` from `site_eventos_informe` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_201804_argumentacion_oral_escrita`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_201804_argumentacion_oral_escrita` AS select date_format(`i`.`fecha_actualizacion`,_utf8'%Y-%m-%d %H:%i:%s') AS `fecha postulación`,`i`.`nombre` AS `nombre`,`i`.`apellidos` AS `apellidos`,`i`.`genero` AS `genero`,`i`.`email` AS `correo electrónico`,`c`.`comuna` AS `comuna residencia`,`i`.`ciudad` AS `ciudad residencia`,`c`.`region` AS `region residencia`,`i`.`telefono_movil` AS `telefono contacto`,`i`.`actividad` AS `actividad`,`i`.`profesion` AS `profesion`,`i`.`institucion` AS `institución donde trabaja` from (`site_inscripcion` `i` join `view_regiones_comunas` `c`) where ((`i`.`tipo_inscripcion` like _latin1'201804_argumentacion_oral_escrita') and (`i`.`comuna` = `c`.`comuna_id`) and (`i`.`email` <> _latin1'psepulveda@ciae.uchile.cl') and (`i`.`email` <> _latin1'joseluisrs@hotmail.com')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_201804_seminario_juego_infancia_priv`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_201804_seminario_juego_infancia_priv` AS select date_format(`i`.`fecha_actualizacion`,_utf8'%Y-%m-%d %H:%i:%s') AS `fecha postulación`,`i`.`nombre` AS `nombre`,`i`.`apellidos` AS `apellidos`,`i`.`genero` AS `genero`,`i`.`email` AS `correo electrónico`,`c`.`comuna` AS `comuna residencia`,`i`.`ciudad` AS `ciudad residencia`,`c`.`region` AS `region residencia`,`i`.`telefono_movil` AS `telefono contacto`,`i`.`actividad` AS `actividad`,`i`.`profesion` AS `profesion`,`i`.`institucion` AS `institución donde trabaja` from (`site_inscripcion` `i` join `view_regiones_comunas` `c`) where ((`i`.`tipo_inscripcion` like _latin1'201804_seminario_juego_infancia_priv') and (`i`.`comuna` = `c`.`comuna_id`) and (`i`.`email` <> _latin1'psepulveda@ciae.uchile.cl') and (`i`.`email` <> _latin1'joseluisrs@hotmail.com')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_202204_concurso_postdoc`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_202204_concurso_postdoc` AS select date_format(`i`.`fecha_actualizacion`,_utf8'%Y-%m-%d %H:%i:%s') AS `fecha postulación`,`i`.`email` AS `correo electrónico`,`i`.`nombre` AS `nombre`,`i`.`apellidos` AS `apellido_paterno`,`i`.`campo_extra6` AS `apellido_materno`,format(`i`.`rut`,0) AS `rut-pasaporte`,date_format(`i`.`fecha_nacimiento`,_utf8'%d-%m-%Y') AS `fecha nacimiento`,`i`.`genero` AS `genero`,`i`.`campo_extra5` AS `correo electrónico alternativo`,`i`.`telefono_movil` AS `telefono contacto`,`i`.`direccion` AS `direccion`,`p`.`pais` AS `pais`,`i`.`profesion` AS `profesion`,`i`.`institucion` AS `institución donde trabaja`,`i`.`campo_extra4` AS `area postulacion`,if((`i`.`archivo_extra1` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra1`,_latin1'>descargar archivo</a>'),'') AS `archivo_cv`,if((`i`.`archivo_extra2` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra2`,_latin1'>descargar archivo</a>'),'') AS `archivo titulos y grados (1)`,if((`i`.`archivo_extra3` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra3`,_latin1'>descargar archivo</a>'),'') AS `carta recomendacion (1)`,if((`i`.`archivo_extra4` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra4`,_latin1'>descargar archivo</a>'),'') AS `carta recomendacion (2)`,if((`i`.`archivo_extra5` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra5`,_latin1'>descargar archivo</a>'),'') AS `proyecto`,if((`i`.`archivo_extra6` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra6`,_latin1'>descargar archivo</a>'),'') AS `carta de intención` from ((`site_inscripcion` `i` join `view_regiones_comunas` `c`) join `common_paises` `p`) where ((`i`.`tipo_inscripcion` like _latin1'202204_concurso_postdoc') and (`i`.`comuna` = `c`.`comuna_id`) and (`p`.`pais_id` = `i`.`pais`) and (`i`.`email` <> _latin1'psepulveda@ciae.uchile.cl') and (`i`.`email` <> _latin1'psepulve@gmail.com')) order by `i`.`fecha_actualizacion` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_202206_concurso_academicos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_202206_concurso_academicos` AS select date_format(`i`.`fecha_actualizacion`,_utf8'%Y-%m-%d %H:%i:%s') AS `fecha postulación`,`i`.`nombre` AS `nombre`,`i`.`apellidos` AS `apellido_paterno`,`i`.`campo_extra6` AS `apellido_materno`,format(`i`.`rut`,0) AS `rut`,`i`.`rut_dv` AS `rut_digito`,date_format(`i`.`fecha_nacimiento`,_utf8'%d-%m-%Y') AS `fecha nacimiento`,`i`.`genero` AS `genero`,`i`.`email` AS `correo electrónico`,`i`.`campo_extra5` AS `correo electrónico alternativo`,`i`.`campo_extra1` AS `dirección residencia`,`i`.`ciudad` AS `ciudad residencia`,`i`.`telefono_movil` AS `telefono contacto`,`i`.`profesion` AS `profesion`,if((`i`.`archivo_extra1` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra1`,_latin1'>descargar archivo</a>'),'') AS `archivo_cv`,if((`i`.`archivo_extra2` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra2`,_latin1'>descargar archivo</a>'),'') AS `archivo titulos y grados (1)`,if((`i`.`archivo_extra3` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra3`,_latin1'>descargar archivo</a>'),'') AS `archivo declaración inhabilidades`,if((`i`.`archivo_extra4` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra4`,_latin1'>descargar archivo</a>'),'') AS `archivo declaracion cumplimiento b) y c)`,if((`i`.`archivo_extra5` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra5`,_latin1'>descargar archivo</a>'),'') AS `archivo declaracion salud`,if((`i`.`archivo_extra6` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra6`,_latin1'>descargar archivo</a>'),'') AS `carta motivacion` from (`site_inscripcion` `i` join `view_regiones_comunas` `c`) where ((`i`.`tipo_inscripcion` like _latin1'202206_concurso_academicos') and (`i`.`comuna` = `c`.`comuna_id`) and (`i`.`email` <> _latin1'psepulveda@ciae.uchile.cl')) order by `i`.`fecha_actualizacion` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_202208_taller_constitucion`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_202208_taller_constitucion` AS select date_format(`i`.`fecha_actualizacion`,_utf8'%Y-%m-%d %H:%i:%s') AS `fecha inscripcion`,`i`.`email` AS `email`,`i`.`nombre` AS `nombre`,`i`.`apellidos` AS `apellido_paterno`,`i`.`actividad` AS `actividad`,`i`.`profesion` AS `profesion`,`i`.`institucion` AS `institución`,`i`.`campo_extra1` AS `Nivel que enseña`,`i`.`campo_extra2` AS `Intereses` from `site_inscripcion` `i` where ((`i`.`tipo_inscripcion` like _latin1'202208_taller_constitucion') and (`i`.`email` <> _latin1'psepulveda@ciae.uchile.cl') and (`i`.`email` <> 'psepulve@gmail.com')) order by `i`.`fecha_actualizacion` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_202209_concurso_postdoc`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_202209_concurso_postdoc` AS select date_format(`i`.`fecha_actualizacion`,_utf8'%Y-%m-%d %H:%i:%s') AS `fecha postulación`,`i`.`email` AS `correo electrónico`,`i`.`nombre` AS `nombre`,`i`.`apellidos` AS `apellido_paterno`,`i`.`rut` AS `rut-pasaporte`,date_format(`i`.`fecha_nacimiento`,_utf8'%d-%m-%Y') AS `fecha nacimiento`,`i`.`genero` AS `genero`,`i`.`campo_extra5` AS `correo electrónico alternativo`,`i`.`telefono_movil` AS `telefono contacto`,`i`.`direccion` AS `direccion`,`p`.`pais` AS `pais`,`i`.`profesion` AS `profesion`,`i`.`institucion` AS `institución donde trabaja`,`i`.`campo_extra4` AS `area postulacion`,if((`i`.`archivo_extra1` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra1`,_latin1'>descargar archivo</a>'),'') AS `archivo_cv`,if((`i`.`archivo_extra2` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra2`,_latin1'>descargar archivo</a>'),'') AS `archivo titulos y grados (1)`,if((`i`.`archivo_extra3` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra3`,_latin1'>descargar archivo</a>'),'') AS `carta recomendacion (1)`,if((`i`.`archivo_extra4` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra4`,_latin1'>descargar archivo</a>'),'') AS `carta recomendacion (2)`,if((`i`.`archivo_extra5` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra5`,_latin1'>descargar archivo</a>'),'') AS `proyecto`,if((`i`.`archivo_extra6` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra6`,_latin1'>descargar archivo</a>'),'') AS `carta de intención` from ((`site_inscripcion` `i` join `view_regiones_comunas` `c`) join `common_paises` `p`) where ((`i`.`tipo_inscripcion` like _latin1'202209_concurso_postdoc') and (`i`.`comuna` = `c`.`comuna_id`) and (`p`.`pais_id` = `i`.`pais`) and (`i`.`email` <> _latin1'psepulveda@ciae.uchile.cl') and (`i`.`email` <> _latin1'psepulve@gmail.com')) order by `i`.`fecha_actualizacion` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_2022_concurso_academicos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_2022_concurso_academicos` AS select date_format(`i`.`fecha_actualizacion`,_utf8'%Y-%m-%d %H:%i:%s') AS `fecha postulación`,`i`.`nombre` AS `nombre`,`i`.`apellidos` AS `apellido_paterno`,`i`.`campo_extra6` AS `apellido_materno`,format(`i`.`rut`,0) AS `rut`,`i`.`rut_dv` AS `rut_digito`,date_format(`i`.`fecha_nacimiento`,_utf8'%d-%m-%Y') AS `fecha nacimiento`,`i`.`genero` AS `genero`,`i`.`email` AS `correo electrónico`,`i`.`campo_extra5` AS `correo electrónico alternativo`,`i`.`campo_extra1` AS `dirección residencia`,`i`.`ciudad` AS `ciudad residencia`,`i`.`telefono_movil` AS `telefono contacto`,`i`.`profesion` AS `profesion`,if((`i`.`archivo_extra1` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra1`,_latin1'>descargar archivo</a>'),'') AS `archivo_cv`,if((`i`.`archivo_extra2` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra2`,_latin1'>descargar archivo</a>'),'') AS `archivo titulos y grados (1)`,if((`i`.`archivo_extra3` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra3`,_latin1'>descargar archivo</a>'),'') AS `archivo declaración inhabilidades`,if((`i`.`archivo_extra4` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra4`,_latin1'>descargar archivo</a>'),'') AS `archivo declaracion cumplimiento b) y c)`,if((`i`.`archivo_extra5` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra5`,_latin1'>descargar archivo</a>'),'') AS `archivo declaracion salud`,if((`i`.`archivo_extra6` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra6`,_latin1'>descargar archivo</a>'),'') AS `carta motivacion` from (`site_inscripcion` `i` join `view_regiones_comunas` `c`) where ((`i`.`tipo_inscripcion` like _latin1'2022_concurso_academicos') and (`i`.`comuna` = `c`.`comuna_id`) and (`i`.`email` <> _latin1'psepulveda@ciae.uchile.cl')) order by `i`.`fecha_actualizacion` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_20231130_postdoctorado`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_20231130_postdoctorado` AS select date_format(`i`.`fecha_actualizacion`,_utf8'%Y-%m-%d %H:%i:%s') AS `fecha postulación`,`i`.`email` AS `correo electrónico`,`i`.`nombre` AS `nombre`,`i`.`apellidos` AS `apellido_paterno`,`i`.`rut` AS `rut-pasaporte`,date_format(`i`.`fecha_nacimiento`,_utf8'%d-%m-%Y') AS `fecha nacimiento`,`i`.`genero` AS `genero`,`i`.`campo_extra5` AS `correo electrónico alternativo`,`i`.`telefono_movil` AS `telefono contacto`,`i`.`direccion` AS `direccion`,`p`.`pais` AS `pais`,`i`.`profesion` AS `profesion`,`i`.`institucion` AS `institución donde trabaja`,`i`.`campo_extra4` AS `area postulacion`,if((`i`.`archivo_extra1` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra1`,_latin1'>descargar archivo</a>'),'') AS `archivo_cv`,if((`i`.`archivo_extra2` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra2`,_latin1'>descargar archivo</a>'),'') AS `archivo titulos y grados (1)`,if((`i`.`archivo_extra3` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra3`,_latin1'>descargar archivo</a>'),'') AS `proyecto`,if((`i`.`archivo_extra4` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra4`,_latin1'>descargar archivo</a>'),'') AS `carta recomendacion (1)`,if((`i`.`archivo_extra5` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra5`,_latin1'>descargar archivo</a>'),'') AS `carta recomendacion (2)`,if((`i`.`archivo_extra6` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra6`,_latin1'>descargar archivo</a>'),'') AS `carta de intención` from ((`site_inscripcion` `i` join `view_regiones_comunas` `c`) join `common_paises` `p`) where ((`i`.`tipo_inscripcion` like _latin1'20231115_postdoctorado') and (`i`.`comuna` = `c`.`comuna_id`) and (`p`.`pais_id` = `i`.`pais`) and (`i`.`email` <> _latin1'psepulveda@ciae.uchile.cl') and (`i`.`email` <> _latin1'psepulve@gmail.com')) order by `i`.`fecha_actualizacion` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_202311_taller_arpa_ensenanza_matematica`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_202311_taller_arpa_ensenanza_matematica` AS select `site_inscripcion`.`email` AS `email`,`site_inscripcion`.`fecha_actualizacion` AS `fecha_actualizacion`,`site_inscripcion`.`nombre` AS `nombre`,`site_inscripcion`.`apellidos` AS `apellidos`,`site_inscripcion`.`institucion` AS `institucion`,`site_inscripcion`.`actividad` AS `actividad`,`site_inscripcion`.`profesion` AS `profesion`,`site_inscripcion`.`campo_extra1` AS `donde_enseña` from `site_inscripcion` where ((`site_inscripcion`.`tipo_inscripcion` like '202311_taller_arpa_ensenanza_matematica%') and (`site_inscripcion`.`email` <> 'psepulve@gmail.com')) order by `site_inscripcion`.`apellidos` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_ciae_anexos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_ciae_anexos` AS select `site_personas`.`apellido_paterno` AS `Apellidos`,`site_personas`.`nombre` AS `Nombre`,`site_personas`.`email` AS `Email`,`site_personas`.`anexo_numero` AS `Anexo` from `site_personas` where (`site_personas`.`anexo` like _latin1'Si') order by `site_personas`.`apellido_paterno` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_diplomado_investigacion_2022`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_diplomado_investigacion_2022` AS select date_format(`i`.`fecha_actualizacion`,_utf8'%Y-%m-%d %H:%i:%s') AS `fecha postulación`,`i`.`nombre` AS `nombre`,`i`.`apellidos` AS `apellido_paterno`,`i`.`campo_extra6` AS `apellido_materno`,format(`i`.`rut`,0) AS `rut`,`i`.`rut_dv` AS `rut_digito`,date_format(`i`.`fecha_nacimiento`,_utf8'%d-%m-%Y') AS `fecha nacimiento`,`i`.`genero` AS `genero`,`i`.`email` AS `correo electrónico`,`i`.`campo_extra5` AS `correo electrónico alternativo`,`i`.`campo_extra1` AS `dirección residencia`,`c`.`comuna` AS `comuna residencia`,`i`.`ciudad` AS `ciudad residencia`,`i`.`telefono_movil` AS `telefono contacto`,`i`.`actividad` AS `actividad`,`i`.`profesion` AS `profesion`,`i`.`institucion` AS `institución donde trabaja`,`i`.`campo_extra2` AS `telefono institución`,`i`.`campo_extra3` AS `sitio web institución`,`i`.`campo_extra4` AS `años de servicio`,`i`.`campo_extra7` AS `dependencia`,if((`i`.`archivo_extra1` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra1`,_latin1'>descargar archivo</a>'),'') AS `archivo_cv`,if((`i`.`archivo_extra2` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra2`,_latin1'>descargar archivo</a>'),'') AS `archivo titulos y grados (1)`,`i`.`comentario` AS `carta de intención` from (`site_inscripcion` `i` join `view_regiones_comunas` `c`) where ((`i`.`tipo_inscripcion` like _latin1'2022_diploma_investigacon_educacion') and (`i`.`comuna` = `c`.`comuna_id`) and (`i`.`email` <> _latin1'psepulveda@ciae.uchile.cl')) order by `i`.`fecha_actualizacion` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_diplomado_lenguaje_2019`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_diplomado_lenguaje_2019` AS select date_format(`i`.`fecha_actualizacion`,_utf8'%Y-%m-%d %H:%i:%s') AS `fecha postulación`,`i`.`nombre` AS `nombre`,`i`.`apellidos` AS `apellidos`,format(`i`.`rut`,0) AS `rut`,`i`.`rut_dv` AS `rut_digito`,date_format(`i`.`fecha_nacimiento`,_utf8'%d-%m-%Y') AS `fecha nacimiento`,`i`.`genero` AS `genero`,`i`.`email` AS `correo electrónico`,`i`.`campo_extra5` AS `correo electrónico alternativo`,`c`.`comuna` AS `comuna residencia`,`i`.`ciudad` AS `ciudad residencia`,`c`.`region` AS `region residencia`,`i`.`telefono_movil` AS `telefono contacto`,`i`.`actividad` AS `actividad`,`i`.`profesion` AS `profesion`,`i`.`institucion` AS `institución donde trabaja`,`i`.`campo_extra1` AS `dirección institución`,`i`.`campo_extra2` AS `telefono institución`,`i`.`campo_extra3` AS `sitio web institución`,`i`.`campo_extra4` AS `años de servicio`,concat(_latin1'<a href=http://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra1`,_latin1'>descargar archivo</a>') AS `archivo cv`,concat(_latin1'<a href=http://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra2`,_latin1'>descargar archivo</a>') AS `archivo titulos y grados`,concat(_latin1'<a href=http://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra4`,_latin1'>descargar archivo</a>') AS `archivo liquidaciones`,concat(_latin1'<a\r\nhref=http://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra6`,_latin1'>descargar archivo</a>') AS `cert_participa_curso`,`i`.`comentario` AS `carta de intención` from (`site_inscripcion` `i` join `view_regiones_comunas` `c`) where ((`i`.`tipo_inscripcion` like _latin1'2019_diplomado_lenguaje') and (`i`.`comuna` = `c`.`comuna_id`) and (`i`.`email` <> _latin1'psepulveda@ciae.uchile.cl')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_diplomado_lenguaje_2020`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_diplomado_lenguaje_2020` AS select date_format(`i`.`fecha_actualizacion`,_utf8'%Y-%m-%d %H:%i:%s') AS `fecha postulación`,`i`.`nombre` AS `nombre`,`i`.`apellidos` AS `apellidos`,format(`i`.`rut`,0) AS `rut`,`i`.`rut_dv` AS `rut_digito`,date_format(`i`.`fecha_nacimiento`,_utf8'%d-%m-%Y') AS `fecha nacimiento`,`i`.`genero` AS `genero`,`i`.`email` AS `correo electrónico`,`i`.`campo_extra5` AS `correo electrónico alternativo`,`i`.`campo_extra1` AS `domicilio`,`i`.`ciudad` AS `ciudad residencia`,`c`.`region` AS `region residencia`,`i`.`telefono_movil` AS `telefono contacto`,`i`.`actividad` AS `actividad`,`i`.`profesion` AS `profesion`,`i`.`institucion` AS `institución donde trabaja`,`i`.`campo_extra2` AS `telefono institución`,`i`.`campo_extra3` AS `sitio web institución`,`i`.`campo_extra4` AS `años de servicio`,concat(_latin1'<a href=http://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra1`,_latin1'>descargar archivo</a>') AS `archivo cv`,concat(_latin1'<a href=http://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra2`,_latin1'>descargar archivo</a>') AS `archivo titulos y grados`,concat(_latin1'<a href=http://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra4`,_latin1'>descargar archivo</a>') AS `archivo liquidaciones`,concat(_latin1'<a\r\nhref=http://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra6`,_latin1'>descargar archivo</a>') AS `cert_participa_curso`,`i`.`comentario` AS `carta de intención` from (`site_inscripcion` `i` join `view_regiones_comunas` `c`) where ((`i`.`tipo_inscripcion` like _latin1'2020_diplomado_lenguaje') and (`i`.`comuna` = `c`.`comuna_id`) and (`i`.`email` <> _latin1'joseluis.ramos@ciae.uchile.cl')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_diplomado_lenguaje_2021`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_diplomado_lenguaje_2021` AS select date_format(`i`.`fecha_actualizacion`,_utf8'%Y-%m-%d %H:%i:%s') AS `fecha postulación`,`i`.`nombre` AS `nombre`,`i`.`apellidos` AS `apellidos`,format(`i`.`rut`,0) AS `rut`,`i`.`rut_dv` AS `rut_digito`,date_format(`i`.`fecha_nacimiento`,_utf8'%d-%m-%Y') AS `fecha nacimiento`,`i`.`genero` AS `genero`,`i`.`email` AS `correo electrónico`,`i`.`campo_extra5` AS `correo electrónico alternativo`,`c`.`comuna` AS `comuna residencia`,`i`.`ciudad` AS `ciudad residencia`,`c`.`region` AS `region residencia`,`i`.`telefono_movil` AS `telefono contacto`,`i`.`actividad` AS `actividad`,`i`.`profesion` AS `profesion`,`i`.`institucion` AS `institución donde trabaja`,`i`.`campo_extra1` AS `dirección institución`,`i`.`campo_extra2` AS `telefono institución`,`i`.`campo_extra3` AS `sitio web institución`,`i`.`campo_extra4` AS `años de servicio`,concat(_latin1'<a href=http://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra1`,_latin1'>descargar archivo</a>') AS `archivo_cv`,concat(_latin1'<a href=http://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra2`,_latin1'>descargar archivo</a>') AS `archivo titulos y grados (1)` from (`site_inscripcion` `i` join `view_regiones_comunas` `c`) where ((`i`.`tipo_inscripcion` like _latin1'2021_diplomado_lenguaje') and (`i`.`comuna` = `c`.`comuna_id`) and (`i`.`email` <> _latin1'psepulveda@ciae.uchile.cl')) order by `i`.`fecha_actualizacion` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_diplomado_lenguaje_2022`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_diplomado_lenguaje_2022` AS select date_format(`i`.`fecha_actualizacion`,_utf8'%Y-%m-%d %H:%i:%s') AS `fecha postulación`,`i`.`nombre` AS `nombre`,`i`.`apellidos` AS `apellido_paterno`,`i`.`campo_extra6` AS `apellido_materno`,format(`i`.`rut`,0) AS `rut`,`i`.`rut_dv` AS `rut_digito`,date_format(`i`.`fecha_nacimiento`,_utf8'%d-%m-%Y') AS `fecha nacimiento`,`i`.`genero` AS `genero`,`i`.`email` AS `correo electrónico`,`i`.`campo_extra5` AS `correo electrónico alternativo`,`i`.`campo_extra1` AS `dirección residencia`,`c`.`comuna` AS `comuna residencia`,`i`.`ciudad` AS `ciudad residencia`,`i`.`telefono_movil` AS `telefono contacto`,`i`.`actividad` AS `actividad`,`i`.`profesion` AS `profesion`,`i`.`institucion` AS `institución donde trabaja`,`i`.`campo_extra2` AS `telefono institución`,`i`.`campo_extra3` AS `sitio web institución`,`i`.`campo_extra4` AS `años de servicio`,`i`.`campo_extra7` AS `dependencia`,if((`i`.`archivo_extra1` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra1`,_latin1'>descargar archivo</a>'),'') AS `archivo_cv`,if((`i`.`archivo_extra2` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra2`,_latin1'>descargar archivo</a>'),'') AS `archivo titulos y grados (1)`,`i`.`comentario` AS `carta de intención` from (`site_inscripcion` `i` join `view_regiones_comunas` `c`) where ((`i`.`tipo_inscripcion` like _latin1'2022_diplomado_lenguaje') and (`i`.`comuna` = `c`.`comuna_id`) and (`i`.`email` <> _latin1'psepulveda@ciae.uchile.cl')) order by `i`.`fecha_actualizacion` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_diplomado_me_2018`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_diplomado_me_2018` AS select date_format(`i`.`fecha_actualizacion`,_utf8'%Y-%m-%d %H:%i:%s') AS `fecha postulación`,`i`.`nombre` AS `nombre`,`i`.`apellidos` AS `apellidos`,format(`i`.`rut`,0) AS `rut`,`i`.`rut_dv` AS `rut_digito`,date_format(`i`.`fecha_nacimiento`,_utf8'%d-%m-%Y') AS `fecha nacimiento`,`i`.`genero` AS `genero`,`i`.`email` AS `correo electrónico`,`i`.`campo_extra5` AS `correo electrónico alternativo`,`c`.`comuna` AS `comuna residencia`,`i`.`ciudad` AS `ciudad residencia`,`c`.`region` AS `region residencia`,`i`.`telefono_movil` AS `telefono contacto`,`i`.`actividad` AS `actividad`,`i`.`profesion` AS `profesion`,`i`.`institucion` AS `institución donde trabaja`,`i`.`campo_extra1` AS `dirección institución`,`i`.`campo_extra2` AS `telefono institución`,`i`.`campo_extra3` AS `sitio web institución`,`i`.`campo_extra4` AS `años de servicio`,concat(_latin1'<a href=http://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra1`,_latin1'>descargar archivo</a>') AS `archivo_cv`,concat(_latin1'<a href=http://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra2`,_latin1'>descargar archivo</a>') AS `archivo titulos y grados (1)`,concat(_latin1'<a href=http://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra3`,_latin1'>descargar archivo</a>') AS `archivo titulos y grados (2)`,`i`.`comentario` AS `carta de intención` from (`site_inscripcion` `i` join `view_regiones_comunas` `c`) where ((`i`.`tipo_inscripcion` like _latin1'2018_diplomado_mejoramiento') and (`i`.`comuna` = `c`.`comuna_id`) and (`i`.`email` <> _latin1'psepulveda@ciae.uchile.cl')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_diplomado_me_2019`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_diplomado_me_2019` AS select date_format(`i`.`fecha_actualizacion`,_utf8'%Y-%m-%d %H:%i:%s') AS `fecha postulación`,`i`.`nombre` AS `nombre`,`i`.`apellidos` AS `apellidos`,format(`i`.`rut`,0) AS `rut`,`i`.`rut_dv` AS `rut_digito`,date_format(`i`.`fecha_nacimiento`,_utf8'%d-%m-%Y') AS `fecha nacimiento`,`i`.`genero` AS `genero`,`i`.`email` AS `correo electrónico`,`i`.`campo_extra5` AS `correo electrónico alternativo`,`c`.`comuna` AS `comuna residencia`,`i`.`ciudad` AS `ciudad residencia`,`c`.`region` AS `region residencia`,`i`.`telefono_movil` AS `telefono contacto`,`i`.`actividad` AS `actividad`,`i`.`profesion` AS `profesion`,`i`.`institucion` AS `institución donde trabaja`,`i`.`campo_extra1` AS `dirección institución`,`i`.`campo_extra2` AS `telefono institución`,`i`.`campo_extra3` AS `sitio web institución`,`i`.`campo_extra4` AS `años de servicio`,concat(_latin1'<a href=http://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra1`,_latin1'>descargar archivo</a>') AS `archivo_cv`,concat(_latin1'<a href=http://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra2`,_latin1'>descargar archivo</a>') AS `archivo titulos y grados (1)`,concat(_latin1'<a href=http://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra3`,_latin1'>descargar archivo</a>') AS `archivo titulos y grados (2)`,`i`.`comentario` AS `carta de intención` from (`site_inscripcion` `i` join `view_regiones_comunas` `c`) where ((`i`.`tipo_inscripcion` like _latin1'2019_diplomado_mejoramiento') and (`i`.`comuna` = `c`.`comuna_id`) and (`i`.`email` <> _latin1'psepulveda@ciae.uchile.cl')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_diplomado_me_2020`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_diplomado_me_2020` AS select date_format(`i`.`fecha_actualizacion`,_utf8'%Y-%m-%d %H:%i:%s') AS `fecha postulación`,`i`.`nombre` AS `nombre`,`i`.`apellidos` AS `apellidos`,format(`i`.`rut`,0) AS `rut`,`i`.`rut_dv` AS `rut_digito`,date_format(`i`.`fecha_nacimiento`,_utf8'%d-%m-%Y') AS `fecha nacimiento`,`i`.`genero` AS `genero`,`i`.`email` AS `correo electrónico`,`i`.`campo_extra5` AS `correo electrónico alternativo`,`c`.`comuna` AS `comuna residencia`,`i`.`ciudad` AS `ciudad residencia`,`c`.`region` AS `region residencia`,`i`.`telefono_movil` AS `telefono contacto`,`i`.`actividad` AS `actividad`,`i`.`profesion` AS `profesion`,`i`.`institucion` AS `institución donde trabaja`,`i`.`campo_extra1` AS `dirección institución`,`i`.`campo_extra2` AS `telefono institución`,`i`.`campo_extra3` AS `sitio web institución`,`i`.`campo_extra4` AS `años de servicio`,concat(_latin1'<a href=http://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra1`,_latin1'>descargar archivo</a>') AS `archivo_cv`,concat(_latin1'<a href=http://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra2`,_latin1'>descargar archivo</a>') AS `archivo titulos y grados (1)`,concat(_latin1'<a href=http://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra3`,_latin1'>descargar archivo</a>') AS `archivo titulos y grados (2)`,`i`.`comentario` AS `carta de intención` from (`site_inscripcion` `i` join `view_regiones_comunas` `c`) where ((`i`.`tipo_inscripcion` like _latin1'2020_diplomado_mejoramiento') and (`i`.`comuna` = `c`.`comuna_id`) and (`i`.`email` <> _latin1'psepulveda@ciae.uchile.cl')) order by `i`.`fecha_actualizacion` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_diplomado_me_2021`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_diplomado_me_2021` AS select date_format(`i`.`fecha_actualizacion`,_utf8'%Y-%m-%d %H:%i:%s') AS `fecha postulación`,`i`.`nombre` AS `nombre`,`i`.`apellidos` AS `apellidos`,format(`i`.`rut`,0) AS `rut`,`i`.`rut_dv` AS `rut_digito`,date_format(`i`.`fecha_nacimiento`,_utf8'%d-%m-%Y') AS `fecha nacimiento`,`i`.`genero` AS `genero`,`i`.`email` AS `correo electrónico`,`i`.`campo_extra5` AS `correo electrónico alternativo`,`c`.`comuna` AS `comuna residencia`,`i`.`ciudad` AS `ciudad residencia`,`c`.`region` AS `region residencia`,`i`.`telefono_movil` AS `telefono contacto`,`i`.`actividad` AS `actividad`,`i`.`profesion` AS `profesion`,`i`.`institucion` AS `institución donde trabaja`,`i`.`campo_extra1` AS `dirección institución`,`i`.`campo_extra2` AS `telefono institución`,`i`.`campo_extra3` AS `sitio web institución`,`i`.`campo_extra4` AS `años de servicio`,concat(_latin1'<a href=http://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra1`,_latin1'>descargar archivo</a>') AS `archivo_cv`,concat(_latin1'<a href=http://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra2`,_latin1'>descargar archivo</a>') AS `archivo titulos y grados (1)`,`i`.`comentario` AS `carta de intención` from (`site_inscripcion` `i` join `view_regiones_comunas` `c`) where ((`i`.`tipo_inscripcion` like _latin1'2021_diplomado_mejoramiento') and (`i`.`comuna` = `c`.`comuna_id`) and (`i`.`email` <> _latin1'psepulveda@ciae.uchile.cl')) order by `i`.`fecha_actualizacion` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_diplomado_me_2022`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_diplomado_me_2022` AS select date_format(`i`.`fecha_actualizacion`,_utf8'%Y-%m-%d %H:%i:%s') AS `fecha postulación`,`i`.`nombre` AS `nombre`,`i`.`apellidos` AS `apellido_paterno`,`i`.`campo_extra6` AS `apellido_materno`,format(`i`.`rut`,0) AS `rut`,`i`.`rut_dv` AS `rut_digito`,date_format(`i`.`fecha_nacimiento`,_utf8'%d-%m-%Y') AS `fecha nacimiento`,`i`.`genero` AS `genero`,`i`.`email` AS `correo electrónico`,`i`.`campo_extra5` AS `correo electrónico alternativo`,`i`.`campo_extra1` AS `dirección residencia`,`c`.`comuna` AS `comuna residencia`,`i`.`ciudad` AS `ciudad residencia`,`i`.`telefono_movil` AS `telefono contacto`,`i`.`actividad` AS `actividad`,`i`.`profesion` AS `profesion`,`i`.`institucion` AS `institución donde trabaja`,`i`.`campo_extra2` AS `telefono institución`,`i`.`campo_extra3` AS `sitio web institución`,`i`.`campo_extra4` AS `años de servicio`,`i`.`campo_extra7` AS `dependencia`,if((`i`.`archivo_extra1` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra1`,_latin1'>descargar archivo</a>'),'') AS `archivo_cv`,if((`i`.`archivo_extra2` <> ''),concat(_latin1'<a href=https://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra2`,_latin1'>descargar archivo</a>'),'') AS `archivo titulos y grados (1)`,`i`.`comentario` AS `carta de intención` from (`site_inscripcion` `i` join `view_regiones_comunas` `c`) where ((`i`.`tipo_inscripcion` like _latin1'2022_diplomado_mejoramiento') and (`i`.`comuna` = `c`.`comuna_id`) and (`i`.`email` <> _latin1'psepulveda@ciae.uchile.cl')) order by `i`.`fecha_actualizacion` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_diplomado_me_concep_2018`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_diplomado_me_concep_2018` AS select date_format(`i`.`fecha_actualizacion`,_utf8'%Y-%m-%d %H:%i:%s') AS `fecha postulación`,`i`.`nombre` AS `nombre`,`i`.`apellidos` AS `apellidos`,format(`i`.`rut`,0) AS `rut`,`i`.`rut_dv` AS `rut_digito`,date_format(`i`.`fecha_nacimiento`,_utf8'%d-%m-%Y') AS `fecha nacimiento`,`i`.`genero` AS `genero`,`i`.`email` AS `correo electrónico`,`i`.`campo_extra5` AS `correo electrónico alternativo`,`c`.`comuna` AS `comuna residencia`,`i`.`ciudad` AS `ciudad residencia`,`c`.`region` AS `region residencia`,`i`.`telefono_movil` AS `telefono contacto`,`i`.`actividad` AS `actividad`,`i`.`profesion` AS `profesion`,`i`.`institucion` AS `institución donde trabaja`,`i`.`campo_extra1` AS `dirección institución`,`i`.`campo_extra2` AS `telefono institución`,`i`.`campo_extra3` AS `sitio web institución`,`i`.`campo_extra4` AS `años de servicio`,concat(_latin1'<a href=http://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra1`,_latin1'>descargar archivo</a>') AS `archivo_cv`,concat(_latin1'<a href=http://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra2`,_latin1'>descargar archivo</a>') AS `archivo titulos y grados (1)`,concat(_latin1'<a href=http://www.ciae.uchile.cl/download.php?file=inscripciones/',`i`.`archivo_extra3`,_latin1'>descargar archivo</a>') AS `archivo titulos y grados (2)`,`i`.`comentario` AS `carta de intención` from (`site_inscripcion` `i` join `view_regiones_comunas` `c`) where ((`i`.`tipo_inscripcion` like _latin1'2018_concep_diplomado_mejoramiento') and (`i`.`comuna` = `c`.`comuna_id`) and (`i`.`email` <> _latin1'psepulveda@ciae.uchile.cl')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_graduacion_me_2018`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_graduacion_me_2018` AS select date_format(`i`.`fecha_actualizacion`,_utf8'%Y-%m-%d %H:%i:%s') AS `fecha postulación`,`i`.`nombre` AS `nombre`,`i`.`apellidos` AS `apellidos`,`i`.`email` AS `correo electrónico`,`c`.`comuna` AS `comuna residencia`,`c`.`region` AS `region residencia`,`i`.`telefono` AS `telefono contacto`,`i`.`campo_extra1` AS `acompañante 1`,`i`.`campo_extra2` AS `acompañante 2` from (`site_inscripcion` `i` join `view_regiones_comunas` `c`) where ((`i`.`tipo_inscripcion` like _latin1'2018_graduacion_ME') and (`i`.`comuna` = `c`.`comuna_id`) and (`i`.`email` <> _latin1'psepulveda@ciae.uchile.cl')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_graduacion_me_2019`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_graduacion_me_2019` AS select date_format(`i`.`fecha_actualizacion`,_utf8'%Y-%m-%d %H:%i:%s') AS `fecha postulación`,`i`.`nombre` AS `nombre`,`i`.`apellidos` AS `apellidos`,`i`.`email` AS `correo electrónico`,`c`.`comuna` AS `comuna residencia`,`c`.`region` AS `region residencia`,`i`.`telefono` AS `telefono contacto`,`i`.`campo_extra1` AS `acompañante 1`,`i`.`campo_extra2` AS `acompañante 2` from (`site_inscripcion` `i` join `view_regiones_comunas` `c`) where ((`i`.`tipo_inscripcion` like _latin1'2019_graduacion_ME') and (`i`.`comuna` = `c`.`comuna_id`) and (`i`.`email` <> _latin1'psepulveda@ciae.uchile.cl')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_honorarios`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_honorarios` AS select `h`.`rut` AS `rut`,`h`.`email` AS `email`,`h`.`nombre` AS `nombre`,`h`.`apellidos` AS `apellidos`,`h`.`telefono` AS `telefono`,`h`.`telefono_movil` AS `telefono_movil`,`h`.`direccion` AS `direccion`,`c`.`comuna` AS `comuna`,`h`.`fecha_nacimiento` AS `fecha_nacimiento`,`h`.`genero` AS `genero`,`h`.`archivo_cv` AS `archivo_cv`,`h`.`archivo_ci` AS `archivo_ci`,`h`.`area` AS `area`,`h`.`fecha_actualizacion` AS `fecha_actualizacion` from (`site_honorario_personas` `h` join `common_comuna` `c`) where (`c`.`comuna_id` = `h`.`comuna`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_honorarios_labores`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_honorarios_labores` AS select `site_honorario_personas_labores`.`rut` AS `rut`,`site_honorario_personas_labores`.`orden` AS `orden`,`site_honorario_personas_labores`.`cargo` AS `cargo`,`site_honorario_personas_labores`.`institucion` AS `institucion`,`site_honorario_personas_labores`.`monto` AS `monto`,`site_honorario_personas_labores`.`periodo_inicio_mes` AS `periodo_inicio_mes`,`site_honorario_personas_labores`.`periodo_inicio_agno` AS `periodo_inicio_agno`,`site_honorario_personas_labores`.`periodo_termino_mes` AS `periodo_termino_mes`,`site_honorario_personas_labores`.`periodo_termino_agno` AS `periodo_termino_agno`,`site_honorario_personas_labores`.`tipo_contrato` AS `tipo_contrato` from `site_honorario_personas_labores` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_honorarios_titulos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_honorarios_titulos` AS select `site_honorario_personas_titulo`.`rut` AS `rut`,`site_honorario_personas_titulo`.`tipo` AS `tipo`,`site_honorario_personas_titulo`.`orden` AS `orden`,`site_honorario_personas_titulo`.`titulo` AS `titulo`,`site_honorario_personas_titulo`.`institucion` AS `institucion`,`site_honorario_personas_titulo`.`archivo` AS `archivo`,`site_honorario_personas_titulo`.`ciudad` AS `ciudad`,`site_honorario_personas_titulo`.`pais` AS `pais`,`site_honorario_personas_titulo`.`fecha` AS `fecha` from `site_honorario_personas_titulo` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_igeos_inventario`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_igeos_inventario` AS select `view_salida_igeos_inventario`.`fecha` AS `fecha`,`view_salida_igeos_inventario`.`Número de inventario` AS `Número de inventario`,`view_salida_igeos_inventario`.`Nombre del bien` AS `Nombre del bien`,`view_salida_igeos_inventario`.`Modelo` AS `Modelo`,`view_salida_igeos_inventario`.`marca` AS `marca`,`view_salida_igeos_inventario`.`N Serie` AS `N Serie`,`view_salida_igeos_inventario`.`numero_interno_ciae` AS `numero_interno_ciae`,`view_salida_igeos_inventario`.`orden_compra` AS `orden_compra`,`view_salida_igeos_inventario`.`Proveedor` AS `Proveedor`,`view_salida_igeos_inventario`.`Rut Proveedor` AS `Rut Proveedor`,`view_salida_igeos_inventario`.`N Factura` AS `N Factura`,`view_salida_igeos_inventario`.`Organismo` AS `Organismo`,`view_salida_igeos_inventario`.`Unidad` AS `Unidad`,`view_salida_igeos_inventario`.`recinto` AS `recinto` from `ciaecl_inventario`.`view_salida_igeos_inventario` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_indagacion_en_aulas_2019`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_indagacion_en_aulas_2019` AS select date_format(`i`.`fecha_actualizacion`,_utf8'%Y-%m-%d %H:%i:%s') AS `fecha postulación`,`i`.`email` AS `email institución`,`i`.`institucion` AS `institución/establecimiento`,`i`.`rbd` AS `RBD`,`c`.`comuna` AS `comuna residencia`,`i`.`ciudad` AS `ciudad residencia`,`c`.`region` AS `region residencia`,`i`.`telefono` AS `telefono institución`,`i`.`campo_extra1` AS `participante 1 Nombre`,`i`.`campo_extra2` AS `participante 1 Cargo`,`i`.`campo_extra3` AS `participante 1 Email`,`i`.`campo_extra4` AS `participante 1 teléfono`,`i`.`campo_extra5` AS `participante 2 Nombre`,`i`.`campo_extra6` AS `participante 2 Cargo`,`i`.`campo_extra7` AS `participante 2 Email`,`i`.`campo_extra8` AS `participante 2 teléfono`,`i`.`campo_extra9` AS `participante 3 Nombre`,`i`.`campo_extra10` AS `participante 3 Cargo`,`i`.`campo_extra11` AS `participante 3 Email`,`i`.`campo_extra12` AS `participante 3 teléfono`,`i`.`campo_extra13` AS `participante 4 Nombre`,`i`.`campo_extra14` AS `participante 4 Cargo`,`i`.`campo_extra15` AS `participante 4 Email`,`i`.`campo_extra16` AS `participante 4 teléfono`,`i`.`campo_extra17` AS `participante 5 Nombre`,`i`.`campo_extra18` AS `participante 5 Cargo`,`i`.`campo_extra19` AS `participante 5 Email`,`i`.`campo_extra20` AS `participante 5 teléfono` from (`site_inscripcion` `i` join `view_regiones_comunas` `c`) where ((`i`.`tipo_inscripcion` like _latin1'2019_indagacion_en_aulas') and (`i`.`comuna` = `c`.`comuna_id`) and (`i`.`email` <> _latin1'psepulveda@ciae.uchile.cl')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_inventario_biblioteca`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_inventario_biblioteca` AS select `b`.`id_libro` AS `ID_CIAE`,`b`.`id_uchile` AS `ID_UChile`,`b`.`titulo` AS `titulo`,`b`.`autores` AS `autor`,`b`.`editorial` AS `editorial`,`b`.`agno_publicacion` AS `año`,`b`.`numero_copias` AS `n_copias`,if((`b`.`isbn` <> _latin1''),concat(`b`.`isbn`,_latin1'&nbsp;'),_latin1'') AS `isbn`,`b`.`doi` AS `doi`,`b`.`tipo_libro` AS `tipo_libro`,`b`.`precio_unitario` AS `precio_unitario_sin_iva`,round(`b`.`precio_iva`,0) AS `iva`,round(`b`.`precio_total`,0) AS `total_con_iva`,`b`.`proveedor` AS `proveedor`,`b`.`orden_compra` AS `n_orden_de_compra`,`b`.`factura` AS `n_factura`,date_format(`b`.`fecha_factura`,_utf8'%d-%m-%Y') AS `fecha_de_factura`,if((`c`.`codigo` <> _latin1''),concat(`c`.`codigo`,_latin1'&nbsp;'),_latin1'') AS `centro_costo`,`b`.`proyecto` AS `proyecto`,`b`.`investigador_acargo` AS `director_proyecto`,date_format(`b`.`fecha_ingreso_base`,_utf8'%d-%m-%Y') AS `fecha_ingreso_base`,`b`.`estado` AS `estado`,`b`.`comentarios` AS `comentarios_interno` from (`site_gestion_inventario_libros_libros` `b` join `site_tipo_centro_costos` `c`) where (`b`.`centro_costo` = `c`.`id_centro_costo`) order by `b`.`titulo` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_inventario_biblioteca_formulario`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_inventario_biblioteca_formulario` AS select `site_gestion_inventario_libros_libros`.`titulo` AS `titulo_del_libro`,`site_gestion_inventario_libros_libros`.`autores` AS `autor`,`site_gestion_inventario_libros_libros`.`editorial` AS `editorial`,`site_gestion_inventario_libros_libros`.`agno_publicacion` AS `agno`,`site_gestion_inventario_libros_libros`.`numero_copias` AS `n_copias`,if((`site_gestion_inventario_libros_libros`.`isbn` <> _latin1''),concat(`site_gestion_inventario_libros_libros`.`isbn`,_latin1'&nbsp;'),_latin1'') AS `isbn`,`site_gestion_inventario_libros_libros`.`precio_unitario` AS `precio_unitario_sin_iva`,round(`site_gestion_inventario_libros_libros`.`precio_iva`,0) AS `iva`,round(`site_gestion_inventario_libros_libros`.`precio_total`,0) AS `total_con_iva`,`site_gestion_inventario_libros_libros`.`proveedor` AS `proveedor`,`site_gestion_inventario_libros_libros`.`orden_compra` AS `n_orden_de_compra`,`site_gestion_inventario_libros_libros`.`factura` AS `n_factura`,date_format(`site_gestion_inventario_libros_libros`.`fecha_factura`,_utf8'%d-%m-%Y') AS `fecha_de_factura`,if((`site_gestion_inventario_libros_libros`.`id_uchile` <> _latin1''),concat(`site_gestion_inventario_libros_libros`.`id_uchile`,_latin1' -<BR>',`site_gestion_inventario_libros_libros`.`id_libro`),`site_gestion_inventario_libros_libros`.`id_libro`) AS `n_correlativo_interno`,`site_gestion_inventario_libros_libros`.`proyecto` AS `proyecto`,`site_gestion_inventario_libros_libros`.`investigador_acargo` AS `director_proyecto`,date_format(`site_gestion_inventario_libros_libros`.`fecha_factura`,_utf8'%Y') AS `agno_compra` from `site_gestion_inventario_libros_libros` order by `site_gestion_inventario_libros_libros`.`fecha_factura` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_inventario_biblioteca_prestamos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_inventario_biblioteca_prestamos` AS select if((`a`.`id_uchile` <> _latin1''),concat(`a`.`id_uchile`,_latin1' -<BR>',`a`.`id_libro`),`a`.`id_libro`) AS `n_correlativo_interno`,`a`.`titulo` AS `titulo_del_libro`,`a`.`autores` AS `autor`,date_format(`b`.`fecha_prestamo`,_utf8'%d-%m-%Y') AS `fecha_prestamo`,date_format(`b`.`fecha_devolucion_estimada`,_utf8'%d-%m-%Y') AS `fecha_devolucion_estimada`,date_format(`b`.`fecha_devolucion`,_utf8'%d-%m-%Y') AS `fecha_devolucion`,`b`.`usuario_solicitante` AS `persona_prestamo`,`a`.`investigador_acargo` AS `director_proyecto_responsable_estimada` from (`view_gestion_inventario_libros_libros` `a` join `view_gestion_inventario_libros_prestamos_detalle` `b`) where (`a`.`id_libro` = `b`.`id_libro`) order by `b`.`fecha_devolucion`,`b`.`fecha_prestamo` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_inventario_biblioteca_simple`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_inventario_biblioteca_simple` AS select `site_gestion_inventario_libros_libros`.`id_libro` AS `ID_CIAE`,`site_gestion_inventario_libros_libros`.`titulo` AS `titulo`,`site_gestion_inventario_libros_libros`.`autores` AS `autor`,`site_gestion_inventario_libros_libros`.`editorial` AS `editorial`,`site_gestion_inventario_libros_libros`.`agno_publicacion` AS `año`,`site_gestion_inventario_libros_libros`.`numero_copias` AS `n_copias`,if((`site_gestion_inventario_libros_libros`.`isbn` <> _latin1''),concat(`site_gestion_inventario_libros_libros`.`isbn`,_latin1'&nbsp;'),_latin1'') AS `isbn`,`site_gestion_inventario_libros_libros`.`doi` AS `doi`,`site_gestion_inventario_libros_libros`.`tipo_libro` AS `tipo_libro`,`site_gestion_inventario_libros_libros`.`proyecto` AS `proyecto`,`site_gestion_inventario_libros_libros`.`investigador_acargo` AS `director_proyecto`,`site_gestion_inventario_libros_libros`.`estado` AS `estado`,date_format(`site_gestion_inventario_libros_libros`.`fecha_ingreso_base`,_utf8'%d-%m-%Y') AS `fecha_ingreso_base` from `site_gestion_inventario_libros_libros` order by `site_gestion_inventario_libros_libros`.`titulo` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_pedidos_tadi`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_pedidos_tadi` AS select `site_tadi_pedido`.`id_pedido` AS `id_pedido`,`site_tadi_pedido`.`estado` AS `estado`,`site_tadi_pedido`.`fecha` AS `fecha`,`site_tadi_pedido`.`nombre` AS `nombre`,`site_tadi_pedido`.`rut` AS `rut`,`site_tadi_pedido`.`cantidad` AS `cantidad`,`site_tadi_pedido`.`email` AS `email`,`site_tadi_pedido`.`institucion` AS `institucion`,`site_tadi_pedido`.`direccion` AS `direccion`,`site_tadi_pedido`.`ciudad` AS `ciudad`,`site_tadi_pedido`.`region` AS `region`,`site_tadi_pedido`.`pais` AS `pais`,`site_tadi_pedido`.`telefono_fijo` AS `telefono_fijo`,`site_tadi_pedido`.`telefono_celular` AS `telefono_celular`,`site_tadi_pedido`.`tipo_envio` AS `tipo_envio` from `site_tadi_pedido` where (`site_tadi_pedido`.`estado` = _latin1'activo') order by `site_tadi_pedido`.`fecha`,`site_tadi_pedido`.`id_pedido` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_postdoc_educacion_2020`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_postdoc_educacion_2020` AS select `view_postulaciones`.`email` AS `email`,`view_postulaciones`.`doctorado_postulacion` AS `doctorado_postulacion`,`view_postulaciones`.`nombre` AS `nombre`,`view_postulaciones`.`apellidos` AS `apellidos`,`view_postulaciones`.`campo_investigacion` AS `campo_investigacion`,`view_postulaciones`.`institucion` AS `institucion`,`view_postulaciones`.`agno` AS `agno`,`view_postulaciones`.`informacion_adicional` AS `informacion_adicional`,`view_postulaciones`.`descargar_archivo_motivacion` AS `descargar_archivo_motivacion`,`view_postulaciones`.`descargar_archivo_propuesta` AS `descargar_archivo_propuesta`,`view_postulaciones`.`descargar_archivo_cv` AS `descargar_archivo_cv`,`view_postulaciones`.`descargar_archivo_titulo` AS `descargar_archivo_titulo`,`view_postulaciones`.`descargar_archivo_carta_recomendacion1` AS `descargar_archivo_carta_recomendacion1`,`view_postulaciones`.`carta_recomendacion1_persona` AS `carta_recomendacion1_persona`,`view_postulaciones`.`carta_recomendacion1_email_persona` AS `carta_recomendacion1_email_persona`,`view_postulaciones`.`carta_recomendacion1_afiliacion_persona` AS `carta_recomendacion1_afiliacion_persona`,`view_postulaciones`.`descargar_archivo_carta_recomendacion2` AS `descargar_archivo_carta_recomendacion2`,`view_postulaciones`.`carta_recomendacion2_persona` AS `carta_recomendacion2_persona`,`view_postulaciones`.`carta_recomendacion2_email_persona` AS `carta_recomendacion2_email_persona`,`view_postulaciones`.`carta_recomendacion2_afiliacion_persona` AS `carta_recomendacion2_afiliacion_persona`,`view_postulaciones`.`descargar_archivo_carta_recomendacion3` AS `descargar_archivo_carta_recomendacion3`,`view_postulaciones`.`carta_recomendacion3_persona` AS `carta_recomendacion3_persona`,`view_postulaciones`.`carta_recomendacion3_email_persona` AS `carta_recomendacion3_email_persona`,`view_postulaciones`.`carta_recomendacion3_afiliacion_persona` AS `carta_recomendacion3_afiliacion_persona` from `view_postulaciones` where (`view_postulaciones`.`doctorado_postulacion` = _latin1'202004_postdoc_educacion') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_postdoc_ensenanza_aprendizaje_2019`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_postdoc_ensenanza_aprendizaje_2019` AS select `view_postulaciones`.`email` AS `email`,`view_postulaciones`.`doctorado_postulacion` AS `doctorado_postulacion`,`view_postulaciones`.`nombre` AS `nombre`,`view_postulaciones`.`apellidos` AS `apellidos`,`view_postulaciones`.`campo_investigacion` AS `campo_investigacion`,`view_postulaciones`.`institucion` AS `institucion`,`view_postulaciones`.`agno` AS `agno`,`view_postulaciones`.`informacion_adicional` AS `informacion_adicional`,`view_postulaciones`.`descargar_archivo_motivacion` AS `descargar_archivo_motivacion`,`view_postulaciones`.`descargar_archivo_propuesta` AS `descargar_archivo_propuesta`,`view_postulaciones`.`descargar_archivo_cv` AS `descargar_archivo_cv`,`view_postulaciones`.`descargar_archivo_titulo` AS `descargar_archivo_titulo`,`view_postulaciones`.`descargar_archivo_carta_recomendacion1` AS `descargar_archivo_carta_recomendacion1`,`view_postulaciones`.`carta_recomendacion1_persona` AS `carta_recomendacion1_persona`,`view_postulaciones`.`carta_recomendacion1_email_persona` AS `carta_recomendacion1_email_persona`,`view_postulaciones`.`carta_recomendacion1_afiliacion_persona` AS `carta_recomendacion1_afiliacion_persona`,`view_postulaciones`.`descargar_archivo_carta_recomendacion2` AS `descargar_archivo_carta_recomendacion2`,`view_postulaciones`.`carta_recomendacion2_persona` AS `carta_recomendacion2_persona`,`view_postulaciones`.`carta_recomendacion2_email_persona` AS `carta_recomendacion2_email_persona`,`view_postulaciones`.`carta_recomendacion2_afiliacion_persona` AS `carta_recomendacion2_afiliacion_persona`,`view_postulaciones`.`descargar_archivo_carta_recomendacion3` AS `descargar_archivo_carta_recomendacion3`,`view_postulaciones`.`carta_recomendacion3_persona` AS `carta_recomendacion3_persona`,`view_postulaciones`.`carta_recomendacion3_email_persona` AS `carta_recomendacion3_email_persona`,`view_postulaciones`.`carta_recomendacion3_afiliacion_persona` AS `carta_recomendacion3_afiliacion_persona` from `view_postulaciones` where (`view_postulaciones`.`doctorado_postulacion` = _latin1'201910_postdoc_ensenanza_aprendizaje') */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_proy_ciae_extra`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_proy_ciae_extra` AS select `view_proyecto_detalle`.`id_proyecto` AS `id_proyecto`,`view_proyecto_detalle`.`activo` AS `activo`,`view_proyecto_detalle`.`proyecto` AS `proyecto`,`view_proyecto_detalle`.`proyecto_en` AS `proyecto_en`,`view_proyecto_detalle`.`codigo` AS `codigo`,`view_proyecto_detalle`.`id_tipo` AS `id_tipo`,`view_proyecto_detalle`.`id_tipo_area_proyecto` AS `id_tipo_area_proyecto`,`view_proyecto_detalle`.`agno_inicio` AS `agno_inicio`,`view_proyecto_detalle`.`mes_inicio` AS `mes_inicio`,`view_proyecto_detalle`.`url` AS `url`,`view_proyecto_detalle`.`antecedentes` AS `antecedentes`,`view_proyecto_detalle`.`objetivos` AS `objetivos`,`view_proyecto_detalle`.`metodologia` AS `metodologia`,`view_proyecto_detalle`.`periodo` AS `periodo`,`view_proyecto_detalle`.`financiamiento` AS `financiamiento`,`view_proyecto_detalle`.`productos` AS `productos`,`view_proyecto_detalle`.`mandante` AS `mandante`,`view_proyecto_detalle`.`cooperacion_nacional` AS `cooperacion_nacional`,`view_proyecto_detalle`.`cooperacion_internacional` AS `cooperacion_internacional`,`view_proyecto_detalle`.`tipo_proyecto` AS `tipo_proyecto`,`view_proyecto_detalle`.`tipo_area_proyecto` AS `tipo_area_proyecto` from `view_proyecto_detalle` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_pub_ciae_extra`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_pub_ciae_extra` AS select `p`.`id_publicaciones` AS `id_publicaciones`,`p`.`titulo` AS `titulo`,`p`.`titulo_en` AS `titulo_en`,`p`.`resumen` AS `resumen`,`p`.`doi` AS `doi`,`p`.`isi` AS `isi`,`p`.`mes` AS `mes`,`p`.`mes_numero` AS `mes_numero`,`p`.`agno` AS `agno`,`p`.`factor_Q` AS `factor_Q`,`p`.`cooperacion_nacional` AS `cooperacion_nacional`,`p`.`cooperacion_internacional` AS `cooperacion_internacional`,`p`.`texto` AS `detalle_publicacion`,`p`.`link` AS `link`,`p`.`numero` AS `numero_documento`,`tp`.`tipo` AS `tipo`,`ap`.`area_es` AS `area_es`,`p`.`activo` AS `visible` from ((`site_publicaciones` `p` join `site_tipo_publicaciones` `tp`) join `site_areas` `ap`) where ((`p`.`id_tipo` = `tp`.`id_tipo`) and (`ap`.`id_area` = `p`.`id_area`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_reporte_noticias`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_reporte_noticias` AS select distinct `view_noticias_site`.`id_noticia` AS `id_noticia`,`view_noticias_site`.`fecha` AS `fecha`,`view_noticias_site`.`titulo` AS `titulo`,`view_noticias_site`.`bajada` AS `bajada`,`view_noticias_site`.`autor` AS `autor`,`view_noticias_site`.`tipo` AS `tipo` from `view_noticias_site` order by `view_noticias_site`.`id_noticia` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_tmp_reporte_noticias_prensa`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_tmp_reporte_noticias_prensa` AS select `view_noticias_prensa_site`.`titulo` AS `noticia`,`view_noticias_prensa_site`.`bajada` AS `bajada`,`view_noticias_prensa_site`.`url` AS `url externo`,if((`view_noticias_prensa_site`.`pdf` <> _latin1''),concat(_latin1'http://www.ciae.uchile.cl/download.php?file=en_la_prensa/',`view_noticias_prensa_site`.`pdf`),_latin1'') AS `archivo`,`view_noticias_prensa_site`.`fecha` AS `fecha`,`view_noticias_prensa_site`.`medio` AS `medio`,`view_noticias_prensa_site`.`tema` AS `tema`,`view_noticias_prensa_site`.`tipo_medio` AS `tipo medio`,`view_noticias_prensa_site`.`tipo_cobertura` AS `tipo cobertura`,`view_noticias_prensa_site`.`investigador` AS `investigador`,`view_noticias_prensa_site`.`tipo_aparicion` AS `tipo aparicion`,`view_noticias_prensa_site`.`palabras_clave` AS `palabras clave`,`view_noticias_prensa_site`.`titulo_site` AS `sitio`,`view_noticias_prensa_site`.`area` AS `area` from `view_noticias_prensa_site` order by `view_noticias_prensa_site`.`fecha` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

