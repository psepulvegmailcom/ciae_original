/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

/*!40000 DROP DATABASE IF EXISTS `ciaecl_correoweb`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `ciaecl_correoweb` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `ciaecl_correoweb`;
DROP TABLE IF EXISTS `base_datos_email`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `base_datos_email` (
  `email` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `estado` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT 'activo',
  `fecha_actualizacion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `creacion_fecha` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `creacion_lista` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `tratamiento` varchar(15) COLLATE latin1_general_ci DEFAULT NULL,
  `genero` varchar(2) COLLATE latin1_general_ci DEFAULT NULL,
  `nombre` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `apellidos` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `rut` varchar(12) COLLATE latin1_general_ci DEFAULT NULL,
  `rut_dv` varchar(1) COLLATE latin1_general_ci DEFAULT NULL,
  `rbd` varchar(11) COLLATE latin1_general_ci DEFAULT NULL,
  `rbd_dv` varchar(1) COLLATE latin1_general_ci DEFAULT NULL,
  `cargo_posicion` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `actividad` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `profesion` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `institucion` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `direccion` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `comuna` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `region` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `ciudad` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `pais` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `pais_id` int(11) DEFAULT NULL,
  `telefono` varchar(150) COLLATE latin1_general_ci DEFAULT NULL,
  `telefono2` varchar(150) COLLATE latin1_general_ci DEFAULT NULL,
  `comentario` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `grupo_masivo` varchar(150) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`email`),
  KEY `fecha_actualizacion` (`fecha_actualizacion`),
  KEY `creacion_fecha` (`creacion_fecha`),
  KEY `email` (`email`,`estado`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `base_datos_email_tipo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `base_datos_email_tipo` (
  `email` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `tipo_base` varchar(255) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`email`,`tipo_base`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `common_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `common_logs` (
  `time_log` int(11) NOT NULL,
  `ip` varchar(100) NOT NULL,
  `ip_extra` varchar(100) NOT NULL,
  `sitio` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `action` varchar(255) NOT NULL,
  `msg` text NOT NULL,
  `post` text NOT NULL,
  PRIMARY KEY (`time_log`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `common_logs_url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `common_logs_url` (
  `id_visit` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `uri` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `browser` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `fecha` int(11) NOT NULL,
  `username` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `ip_address` varchar(50) COLLATE latin1_general_ci NOT NULL,
  `ip_address_extra` varchar(100) COLLATE latin1_general_ci NOT NULL,
  PRIMARY KEY (`id_visit`)
) ENGINE=MyISAM AUTO_INCREMENT=54278 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `envio_email_destino`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `envio_email_destino` (
  `caso_envio` varchar(100) COLLATE latin1_general_ci NOT NULL,
  `fecha_estado` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `estado` varchar(50) COLLATE latin1_general_ci NOT NULL DEFAULT 'no_enviado',
  `email` varchar(255) COLLATE latin1_general_ci NOT NULL,
  `email_md5` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `vistas` int(11) DEFAULT NULL,
  `nombre` varchar(255) COLLATE latin1_general_ci DEFAULT ' ',
  `apellidos` varchar(255) COLLATE latin1_general_ci DEFAULT ' ',
  `tratamiento` varchar(7) COLLATE latin1_general_ci DEFAULT 'o/a',
  `email_secundario` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `cargo` varchar(255) COLLATE latin1_general_ci DEFAULT ' ',
  `mensaje` text COLLATE latin1_general_ci,
  `remitente` varchar(150) COLLATE latin1_general_ci DEFAULT NULL,
  PRIMARY KEY (`caso_envio`,`email`),
  KEY `estado` (`estado`,`email`),
  KEY `caso_envio` (`caso_envio`,`fecha_estado`,`estado`,`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `envio_email_destino_inscripciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `envio_email_destino_inscripciones` (
  `caso_envio` varchar(150) NOT NULL,
  `tipo_inscripcion` varchar(150) NOT NULL,
  PRIMARY KEY (`caso_envio`,`tipo_inscripcion`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `envio_email_detalle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `envio_email_detalle` (
  `caso_envio` varchar(255) NOT NULL,
  `caso_envio_md5` varchar(255) DEFAULT NULL,
  `vistas` int(11) DEFAULT NULL,
  `fecha_creacion` datetime DEFAULT CURRENT_TIMESTAMP,
  `fecha_actualizacion` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `tipo` varchar(30) NOT NULL DEFAULT 'manual',
  `estado` varchar(10) NOT NULL DEFAULT 'inactivo',
  `fecha_activar` date DEFAULT NULL,
  `fecha_desactivar` date DEFAULT NULL,
  `orden_envio` int(11) NOT NULL DEFAULT '10',
  `asunto` varchar(255) DEFAULT NULL,
  `tipo_remitente` varchar(10) NOT NULL DEFAULT 'CIAE-IE',
  `reply` varchar(255) NOT NULL DEFAULT 'contacto@ciae.uchile.cl',
  `cc_1` varchar(255) DEFAULT NULL,
  `cc_2` varchar(255) DEFAULT NULL,
  `bcc_1` varchar(255) DEFAULT NULL,
  `bcc_2` varchar(255) DEFAULT NULL,
  `contenido` text,
  `adjunto` text,
  PRIMARY KEY (`caso_envio`),
  UNIQUE KEY `caso_envio_md5` (`caso_envio_md5`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `envio_email_remitentes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `envio_email_remitentes` (
  `remitente` varchar(150) NOT NULL,
  `estado` varchar(15) NOT NULL DEFAULT 'activo',
  `total` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`remitente`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `envio_local_casos_envios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `envio_local_casos_envios` (
  `caso_envio` varchar(150) COLLATE latin1_general_ci NOT NULL,
  `estado` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `orden` int(11) NOT NULL DEFAULT '3',
  `fecha_actualizacion` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`caso_envio`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `envio_local_destinos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `envio_local_destinos` (
  `destinatario` varchar(100) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `estado` varchar(10) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `envio` varchar(250) CHARACTER SET latin1 COLLATE latin1_general_ci NOT NULL,
  `fecha_actualizacion` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`destinatario`,`envio`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `extra_ultima_vista`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `extra_ultima_vista` (
  `ultima_fecha` datetime NOT NULL,
  `fecha_grupos_masivos` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `indice_todos` int(11) NOT NULL,
  `indice_nuevos` int(11) NOT NULL,
  PRIMARY KEY (`ultima_fecha`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;
DROP TABLE IF EXISTS `view_bases_activos`;
/*!50001 DROP VIEW IF EXISTS `view_bases_activos`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_bases_activos` AS SELECT 
 1 AS `email`,
 1 AS `nombre`,
 1 AS `apellidos`,
 1 AS `estado`,
 1 AS `fecha_actualizacion`,
 1 AS `creacion_fecha`,
 1 AS `creacion_lista`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_bases_creacion`;
/*!50001 DROP VIEW IF EXISTS `view_bases_creacion`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_bases_creacion` AS SELECT 
 1 AS `email`,
 1 AS `estado`,
 1 AS `fecha_actualizacion`,
 1 AS `creacion_fecha`,
 1 AS `creacion_lista`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_bases_creacion_total`;
/*!50001 DROP VIEW IF EXISTS `view_bases_creacion_total`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_bases_creacion_total` AS SELECT 
 1 AS `total`,
 1 AS `creacion_lista`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_bases_datos_email`;
/*!50001 DROP VIEW IF EXISTS `view_bases_datos_email`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_bases_datos_email` AS SELECT 
 1 AS `email`,
 1 AS `nombre`,
 1 AS `apellidos`,
 1 AS `tipo_base`,
 1 AS `creacion_fecha`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_bases_datos_inscripciones`;
/*!50001 DROP VIEW IF EXISTS `view_bases_datos_inscripciones`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_bases_datos_inscripciones` AS SELECT 
 1 AS `email`,
 1 AS `tipo_inscripcion`,
 1 AS `fecha_actualizacion`,
 1 AS `tratamiento`,
 1 AS `nombre`,
 1 AS `apellidos`,
 1 AS `edad`,
 1 AS `institucion`,
 1 AS `cargo`,
 1 AS `cargo_otro`,
 1 AS `actividad`,
 1 AS `telefono`,
 1 AS `telefono_movil`,
 1 AS `direccion`,
 1 AS `comuna`,
 1 AS `ciudad`,
 1 AS `region`,
 1 AS `pais`,
 1 AS `rut`,
 1 AS `rut_dv`,
 1 AS `rbd`,
 1 AS `rbd_dv`,
 1 AS `fecha_nacimiento`,
 1 AS `nacionalidad`,
 1 AS `genero`,
 1 AS `profesion`,
 1 AS `comentario`,
 1 AS `comentario_interno`,
 1 AS `campo_extra1`,
 1 AS `campo_extra2`,
 1 AS `campo_extra3`,
 1 AS `campo_extra4`,
 1 AS `campo_extra5`,
 1 AS `campo_extra6`,
 1 AS `archivo_extra1`,
 1 AS `archivo_extra2`,
 1 AS `archivo_extra3`,
 1 AS `archivo_extra4`,
 1 AS `archivo_extra5`,
 1 AS `archivo_extra6`,
 1 AS `campo_extra7`,
 1 AS `campo_extra8`,
 1 AS `campo_extra9`,
 1 AS `campo_extra10`,
 1 AS `campo_extra11`,
 1 AS `campo_extra12`,
 1 AS `campo_extra13`,
 1 AS `campo_extra14`,
 1 AS `campo_extra15`,
 1 AS `campo_extra16`,
 1 AS `campo_extra17`,
 1 AS `campo_extra18`,
 1 AS `campo_extra19`,
 1 AS `campo_extra20`,
 1 AS `inicia_situacion_academica`,
 1 AS `inicia_situacion_academica_carrera`,
 1 AS `inicia_situacion_academica_agno_egreso`,
 1 AS `inicia_situacion_academica_agno_ingreso`,
 1 AS `inicia_situacion_academica_agno_titulo`,
 1 AS `inicia_situacion_academica_institucion`,
 1 AS `inicia_situacion_laboral`,
 1 AS `inicia_situacion_laboral_colegio`,
 1 AS `inicia_situacion_laboral_colegio_telefono`,
 1 AS `inicia_situacion_laboral_colegio_tipo`,
 1 AS `inicia_transferencia_titular`,
 1 AS `inicia_transferencia_banco`,
 1 AS `inicia_transferencia_tipo`,
 1 AS `inicia_transferencia_rut`,
 1 AS `inicia_transferencia_cuenta`,
 1 AS `inicia_rendicion_sede`,
 1 AS `inicia_rendicion_fecha`,
 1 AS `inicia_rendicion_fecha_extra`,
 1 AS `inicia_rendicion_forma_1`,
 1 AS `inicia_rendicion_folio_1`,
 1 AS `inicia_rendicion_forma_2`,
 1 AS `inicia_rendicion_folio_2`,
 1 AS `inicia_rendicion_forma_3`,
 1 AS `inicia_rendicion_folio_3`,
 1 AS `inicia_rendicion_forma_4`,
 1 AS `inicia_rendicion_folio_4`,
 1 AS `inicia_rendicion_folio_pendiente_1`,
 1 AS `inicia_rendicion_folio_pendiente_2`,
 1 AS `inicia_rendicion_estado_asistencia`,
 1 AS `inicia_rendicion_pago_version`,
 1 AS `inicia_rendicion_pago_monto`,
 1 AS `inicia_honorario_calidad`,
 1 AS `inicia_honorario_agno`,
 1 AS `inicia_honorario_dia`,
 1 AS `inicia_honorario_mes`,
 1 AS `inicia_honorario_grado_academico`,
 1 AS `inicia_honorario_grado_academico_institucion`,
 1 AS `inicia_honorario_grado_academico_agno`,
 1 AS `inicia_honorario_grado_academico_mes`,
 1 AS `inicia_honorario_grado_academico_dia`,
 1 AS `inicia_honorario_institucion_publica`,
 1 AS `inicia_honorario_inst_publica_cargo`,
 1 AS `inicia_honorario_tipo_contrato`,
 1 AS `inicia_honorario_renta`,
 1 AS `inicia_honorario_honorario`,
 1 AS `inicia_honorario_honorario_cargo`,
 1 AS `inicia_honorario_honorario_periodo`,
 1 AS `inicia_honorario_honorario_monto`,
 1 AS `inicia_honorario_nacionalidad`,
 1 AS `fecha`,
 1 AS `preinscripcion`,
 1 AS `asistencia`,
 1 AS `activo`,
 1 AS `confirmacion`,
 1 AS `egresado_diplomado`,
 1 AS `egresado_curso`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_bases_datos_tipo`;
/*!50001 DROP VIEW IF EXISTS `view_bases_datos_tipo`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_bases_datos_tipo` AS SELECT 
 1 AS `tipo_base`,
 1 AS `total`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_bases_inactivos`;
/*!50001 DROP VIEW IF EXISTS `view_bases_inactivos`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_bases_inactivos` AS SELECT 
 1 AS `email`,
 1 AS `estado`,
 1 AS `fecha_actualizacion`,
 1 AS `creacion_fecha`,
 1 AS `comentario`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_bases_inactivos_nuevos`;
/*!50001 DROP VIEW IF EXISTS `view_bases_inactivos_nuevos`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_bases_inactivos_nuevos` AS SELECT 
 1 AS `email`,
 1 AS `fecha_actualizacion`,
 1 AS `creacion_fecha`,
 1 AS `comentario`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_bases_inactivos_suscripcion`;
/*!50001 DROP VIEW IF EXISTS `view_bases_inactivos_suscripcion`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_bases_inactivos_suscripcion` AS SELECT 
 1 AS `email`,
 1 AS `estado`,
 1 AS `fecha_actualizacion`,
 1 AS `creacion_fecha`,
 1 AS `comentario`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_bases_masivos`;
/*!50001 DROP VIEW IF EXISTS `view_bases_masivos`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_bases_masivos` AS SELECT 
 1 AS `total`,
 1 AS `estado`,
 1 AS `grupo_masivo`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_common_correos_enviados_con_rebote`;
/*!50001 DROP VIEW IF EXISTS `view_common_correos_enviados_con_rebote`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_common_correos_enviados_con_rebote` AS SELECT 
 1 AS `total_enviados`,
 1 AS `caso_envio`,
 1 AS `asunto`,
 1 AS `tipo_remitente`,
 1 AS `reply`,
 1 AS `contenido`,
 1 AS `fecha_actualizacion`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_common_correos_enviados_no_rebote`;
/*!50001 DROP VIEW IF EXISTS `view_common_correos_enviados_no_rebote`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_common_correos_enviados_no_rebote` AS SELECT 
 1 AS `total_enviados`,
 1 AS `caso_envio`,
 1 AS `asunto`,
 1 AS `tipo_remitente`,
 1 AS `reply`,
 1 AS `contenido`,
 1 AS `fecha_actualizacion`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_common_logs_imagen`;
/*!50001 DROP VIEW IF EXISTS `view_common_logs_imagen`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_common_logs_imagen` AS SELECT 
 1 AS `id_visita`,
 1 AS `sitio`,
 1 AS `fecha`,
 1 AS `tipo_visita`,
 1 AS `email`,
 1 AS `caso_envio`,
 1 AS `ip_address`,
 1 AS `url`,
 1 AS `fecha_completa`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_envio_caso_email`;
/*!50001 DROP VIEW IF EXISTS `view_envio_caso_email`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_envio_caso_email` AS SELECT 
 1 AS `caso_envio`,
 1 AS `caso_envio_md5`,
 1 AS `fecha_actualizacion`,
 1 AS `tipo`,
 1 AS `estado`,
 1 AS `orden_envio`,
 1 AS `asunto`,
 1 AS `tipo_remitente`,
 1 AS `reply`,
 1 AS `cc_1`,
 1 AS `cc_2`,
 1 AS `bcc_1`,
 1 AS `bcc_2`,
 1 AS `contenido`,
 1 AS `fecha_envio`,
 1 AS `email`,
 1 AS `email_md5`,
 1 AS `estado_email`,
 1 AS `nombre`,
 1 AS `apellidos`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_envio_caso_email_vista`;
/*!50001 DROP VIEW IF EXISTS `view_envio_caso_email_vista`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_envio_caso_email_vista` AS SELECT 
 1 AS `asunto`,
 1 AS `fecha_vista`,
 1 AS `fecha_envio`,
 1 AS `email`,
 1 AS `email_md5`,
 1 AS `estado_email`,
 1 AS `nombre`,
 1 AS `apellidos`,
 1 AS `caso_envio`,
 1 AS `caso_envio_md5`,
 1 AS `tipo`,
 1 AS `estado`,
 1 AS `orden_envio`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_envio_contacto`;
/*!50001 DROP VIEW IF EXISTS `view_envio_contacto`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_envio_contacto` AS SELECT 
 1 AS `caso_envio`,
 1 AS `fecha_estado`,
 1 AS `estado`,
 1 AS `email`,
 1 AS `nombre`,
 1 AS `apellidos`,
 1 AS `mensaje`,
 1 AS `remitente`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_envio_destino_activos`;
/*!50001 DROP VIEW IF EXISTS `view_envio_destino_activos`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_envio_destino_activos` AS SELECT 
 1 AS `caso_envio`,
 1 AS `email`,
 1 AS `estado`,
 1 AS `nombre`,
 1 AS `apellidos`,
 1 AS `tratamiento`,
 1 AS `fecha_estado`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_envio_detalle_informe`;
/*!50001 DROP VIEW IF EXISTS `view_envio_detalle_informe`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_envio_detalle_informe` AS SELECT 
 1 AS `id_evento`,
 1 AS `id_noticia`,
 1 AS `fecha_inicio`,
 1 AS `fecha_termino`,
 1 AS `info_completa`,
 1 AS `nombre`,
 1 AS `tipo_evento`,
 1 AS `total_inscritos_presencial`,
 1 AS `total_inscritos_online`,
 1 AS `total_asistencia`,
 1 AS `institucion_co_organizadora`,
 1 AS `link_inscripcion`,
 1 AS `id_inscripcion`,
 1 AS `inscripcion_opcion_menu`,
 1 AS `inscripcion_fecha_cierre`,
 1 AS `inscripcion_cupos_maximo`,
 1 AS `email`,
 1 AS `ubicacion`,
 1 AS `ubicacion_email`,
 1 AS `ubicacion_email_online`,
 1 AS `date_texto`,
 1 AS `date_texto_email`,
 1 AS `programa`,
 1 AS `costo_texto_extras`,
 1 AS `listas`,
 1 AS `logos`,
 1 AS `tipo_formulario_confirmacion`,
 1 AS `mensaje_extra_notificacion`,
 1 AS `link_online`,
 1 AS `certificado_encabezado_fech`,
 1 AS `certificado_fec`,
 1 AS `certificado_horas`,
 1 AS `certificado_ubicacion`,
 1 AS `certificado_organizadores`,
 1 AS `caso_envio`,
 1 AS `fecha_actualizacion`,
 1 AS `estado`,
 1 AS `orden_envio`,
 1 AS `asunto`,
 1 AS `tipo_remitente`,
 1 AS `reply`,
 1 AS `cc_1`,
 1 AS `cc_2`,
 1 AS `bcc_1`,
 1 AS `bcc_2`,
 1 AS `contenido`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_envio_estados`;
/*!50001 DROP VIEW IF EXISTS `view_envio_estados`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_envio_estados` AS SELECT 
 1 AS `caso_envio`,
 1 AS `estado`,
 1 AS `total`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_envio_estados_no_enviados`;
/*!50001 DROP VIEW IF EXISTS `view_envio_estados_no_enviados`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_envio_estados_no_enviados` AS SELECT 
 1 AS `caso_envio`,
 1 AS `total_no_enviado`,
 1 AS `estado_caso`,
 1 AS `orden_envio`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_envio_estados_no_enviados_inactivos`;
/*!50001 DROP VIEW IF EXISTS `view_envio_estados_no_enviados_inactivos`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_envio_estados_no_enviados_inactivos` AS SELECT 
 1 AS `caso_envio`,
 1 AS `email`,
 1 AS `estado_envio`,
 1 AS `email_md5`,
 1 AS `estado_email`,
 1 AS `nombre`,
 1 AS `apellidos`,
 1 AS `comentario`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_envio_estados_no_enviados_total`;
/*!50001 DROP VIEW IF EXISTS `view_envio_estados_no_enviados_total`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_envio_estados_no_enviados_total` AS SELECT 
 1 AS `total_no_enviados`*/;
SET character_set_client = @saved_cs_client;
DROP TABLE IF EXISTS `view_envio_remitentes`;
/*!50001 DROP VIEW IF EXISTS `view_envio_remitentes`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `view_envio_remitentes` AS SELECT 
 1 AS `remitente`,
 1 AS `total`*/;
SET character_set_client = @saved_cs_client;

USE `ciaecl_correoweb`;
/*!50001 DROP VIEW IF EXISTS `view_bases_activos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_bases_activos` AS select `base_datos_email`.`email` AS `email`,`base_datos_email`.`nombre` AS `nombre`,`base_datos_email`.`apellidos` AS `apellidos`,`base_datos_email`.`estado` AS `estado`,`base_datos_email`.`fecha_actualizacion` AS `fecha_actualizacion`,`base_datos_email`.`creacion_fecha` AS `creacion_fecha`,`base_datos_email`.`creacion_lista` AS `creacion_lista` from `base_datos_email` where (`base_datos_email`.`estado` like _latin1'activo') order by `base_datos_email`.`fecha_actualizacion` desc,`base_datos_email`.`email` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_bases_creacion`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_bases_creacion` AS select `base_datos_email`.`email` AS `email`,`base_datos_email`.`estado` AS `estado`,`base_datos_email`.`fecha_actualizacion` AS `fecha_actualizacion`,`base_datos_email`.`creacion_fecha` AS `creacion_fecha`,`base_datos_email`.`creacion_lista` AS `creacion_lista` from `base_datos_email` where (`base_datos_email`.`estado` = _latin1'activo') order by `base_datos_email`.`fecha_actualizacion` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_bases_creacion_total`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_bases_creacion_total` AS select count(`view_bases_creacion`.`creacion_lista`) AS `total`,`view_bases_creacion`.`creacion_lista` AS `creacion_lista` from `view_bases_creacion` group by `view_bases_creacion`.`creacion_lista` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_bases_datos_email`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_bases_datos_email` AS select trim(`a`.`email`) AS `email`,`a`.`nombre` AS `nombre`,`a`.`apellidos` AS `apellidos`,`b`.`tipo_base` AS `tipo_base`,`a`.`creacion_fecha` AS `creacion_fecha` from (`view_bases_activos` `a` join `base_datos_email_tipo` `b`) where (`a`.`email` = `b`.`email`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_bases_datos_inscripciones`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_bases_datos_inscripciones` AS select `ciaecl_ciae`.`site_inscripcion`.`email` AS `email`,`ciaecl_ciae`.`site_inscripcion`.`tipo_inscripcion` AS `tipo_inscripcion`,`ciaecl_ciae`.`site_inscripcion`.`fecha_actualizacion` AS `fecha_actualizacion`,`ciaecl_ciae`.`site_inscripcion`.`tratamiento` AS `tratamiento`,`ciaecl_ciae`.`site_inscripcion`.`nombre` AS `nombre`,`ciaecl_ciae`.`site_inscripcion`.`apellidos` AS `apellidos`,`ciaecl_ciae`.`site_inscripcion`.`edad` AS `edad`,`ciaecl_ciae`.`site_inscripcion`.`institucion` AS `institucion`,`ciaecl_ciae`.`site_inscripcion`.`cargo` AS `cargo`,`ciaecl_ciae`.`site_inscripcion`.`cargo_otro` AS `cargo_otro`,`ciaecl_ciae`.`site_inscripcion`.`actividad` AS `actividad`,`ciaecl_ciae`.`site_inscripcion`.`telefono` AS `telefono`,`ciaecl_ciae`.`site_inscripcion`.`telefono_movil` AS `telefono_movil`,`ciaecl_ciae`.`site_inscripcion`.`direccion` AS `direccion`,`ciaecl_ciae`.`site_inscripcion`.`comuna` AS `comuna`,`ciaecl_ciae`.`site_inscripcion`.`ciudad` AS `ciudad`,`ciaecl_ciae`.`site_inscripcion`.`region` AS `region`,`ciaecl_ciae`.`site_inscripcion`.`pais` AS `pais`,`ciaecl_ciae`.`site_inscripcion`.`rut` AS `rut`,`ciaecl_ciae`.`site_inscripcion`.`rut_dv` AS `rut_dv`,`ciaecl_ciae`.`site_inscripcion`.`rbd` AS `rbd`,`ciaecl_ciae`.`site_inscripcion`.`rbd_dv` AS `rbd_dv`,`ciaecl_ciae`.`site_inscripcion`.`fecha_nacimiento` AS `fecha_nacimiento`,`ciaecl_ciae`.`site_inscripcion`.`nacionalidad` AS `nacionalidad`,`ciaecl_ciae`.`site_inscripcion`.`genero` AS `genero`,`ciaecl_ciae`.`site_inscripcion`.`profesion` AS `profesion`,`ciaecl_ciae`.`site_inscripcion`.`comentario` AS `comentario`,`ciaecl_ciae`.`site_inscripcion`.`comentario_interno` AS `comentario_interno`,`ciaecl_ciae`.`site_inscripcion`.`campo_extra1` AS `campo_extra1`,`ciaecl_ciae`.`site_inscripcion`.`campo_extra2` AS `campo_extra2`,`ciaecl_ciae`.`site_inscripcion`.`campo_extra3` AS `campo_extra3`,`ciaecl_ciae`.`site_inscripcion`.`campo_extra4` AS `campo_extra4`,`ciaecl_ciae`.`site_inscripcion`.`campo_extra5` AS `campo_extra5`,`ciaecl_ciae`.`site_inscripcion`.`campo_extra6` AS `campo_extra6`,`ciaecl_ciae`.`site_inscripcion`.`archivo_extra1` AS `archivo_extra1`,`ciaecl_ciae`.`site_inscripcion`.`archivo_extra2` AS `archivo_extra2`,`ciaecl_ciae`.`site_inscripcion`.`archivo_extra3` AS `archivo_extra3`,`ciaecl_ciae`.`site_inscripcion`.`archivo_extra4` AS `archivo_extra4`,`ciaecl_ciae`.`site_inscripcion`.`archivo_extra5` AS `archivo_extra5`,`ciaecl_ciae`.`site_inscripcion`.`archivo_extra6` AS `archivo_extra6`,`ciaecl_ciae`.`site_inscripcion`.`campo_extra7` AS `campo_extra7`,`ciaecl_ciae`.`site_inscripcion`.`campo_extra8` AS `campo_extra8`,`ciaecl_ciae`.`site_inscripcion`.`campo_extra9` AS `campo_extra9`,`ciaecl_ciae`.`site_inscripcion`.`campo_extra10` AS `campo_extra10`,`ciaecl_ciae`.`site_inscripcion`.`campo_extra11` AS `campo_extra11`,`ciaecl_ciae`.`site_inscripcion`.`campo_extra12` AS `campo_extra12`,`ciaecl_ciae`.`site_inscripcion`.`campo_extra13` AS `campo_extra13`,`ciaecl_ciae`.`site_inscripcion`.`campo_extra14` AS `campo_extra14`,`ciaecl_ciae`.`site_inscripcion`.`campo_extra15` AS `campo_extra15`,`ciaecl_ciae`.`site_inscripcion`.`campo_extra16` AS `campo_extra16`,`ciaecl_ciae`.`site_inscripcion`.`campo_extra17` AS `campo_extra17`,`ciaecl_ciae`.`site_inscripcion`.`campo_extra18` AS `campo_extra18`,`ciaecl_ciae`.`site_inscripcion`.`campo_extra19` AS `campo_extra19`,`ciaecl_ciae`.`site_inscripcion`.`campo_extra20` AS `campo_extra20`,`ciaecl_ciae`.`site_inscripcion`.`inicia_situacion_academica` AS `inicia_situacion_academica`,`ciaecl_ciae`.`site_inscripcion`.`inicia_situacion_academica_carrera` AS `inicia_situacion_academica_carrera`,`ciaecl_ciae`.`site_inscripcion`.`inicia_situacion_academica_agno_egreso` AS `inicia_situacion_academica_agno_egreso`,`ciaecl_ciae`.`site_inscripcion`.`inicia_situacion_academica_agno_ingreso` AS `inicia_situacion_academica_agno_ingreso`,`ciaecl_ciae`.`site_inscripcion`.`inicia_situacion_academica_agno_titulo` AS `inicia_situacion_academica_agno_titulo`,`ciaecl_ciae`.`site_inscripcion`.`inicia_situacion_academica_institucion` AS `inicia_situacion_academica_institucion`,`ciaecl_ciae`.`site_inscripcion`.`inicia_situacion_laboral` AS `inicia_situacion_laboral`,`ciaecl_ciae`.`site_inscripcion`.`inicia_situacion_laboral_colegio` AS `inicia_situacion_laboral_colegio`,`ciaecl_ciae`.`site_inscripcion`.`inicia_situacion_laboral_colegio_telefono` AS `inicia_situacion_laboral_colegio_telefono`,`ciaecl_ciae`.`site_inscripcion`.`inicia_situacion_laboral_colegio_tipo` AS `inicia_situacion_laboral_colegio_tipo`,`ciaecl_ciae`.`site_inscripcion`.`inicia_transferencia_titular` AS `inicia_transferencia_titular`,`ciaecl_ciae`.`site_inscripcion`.`inicia_transferencia_banco` AS `inicia_transferencia_banco`,`ciaecl_ciae`.`site_inscripcion`.`inicia_transferencia_tipo` AS `inicia_transferencia_tipo`,`ciaecl_ciae`.`site_inscripcion`.`inicia_transferencia_rut` AS `inicia_transferencia_rut`,`ciaecl_ciae`.`site_inscripcion`.`inicia_transferencia_cuenta` AS `inicia_transferencia_cuenta`,`ciaecl_ciae`.`site_inscripcion`.`inicia_rendicion_sede` AS `inicia_rendicion_sede`,`ciaecl_ciae`.`site_inscripcion`.`inicia_rendicion_fecha` AS `inicia_rendicion_fecha`,`ciaecl_ciae`.`site_inscripcion`.`inicia_rendicion_fecha_extra` AS `inicia_rendicion_fecha_extra`,`ciaecl_ciae`.`site_inscripcion`.`inicia_rendicion_forma_1` AS `inicia_rendicion_forma_1`,`ciaecl_ciae`.`site_inscripcion`.`inicia_rendicion_folio_1` AS `inicia_rendicion_folio_1`,`ciaecl_ciae`.`site_inscripcion`.`inicia_rendicion_forma_2` AS `inicia_rendicion_forma_2`,`ciaecl_ciae`.`site_inscripcion`.`inicia_rendicion_folio_2` AS `inicia_rendicion_folio_2`,`ciaecl_ciae`.`site_inscripcion`.`inicia_rendicion_forma_3` AS `inicia_rendicion_forma_3`,`ciaecl_ciae`.`site_inscripcion`.`inicia_rendicion_folio_3` AS `inicia_rendicion_folio_3`,`ciaecl_ciae`.`site_inscripcion`.`inicia_rendicion_forma_4` AS `inicia_rendicion_forma_4`,`ciaecl_ciae`.`site_inscripcion`.`inicia_rendicion_folio_4` AS `inicia_rendicion_folio_4`,`ciaecl_ciae`.`site_inscripcion`.`inicia_rendicion_folio_pendiente_1` AS `inicia_rendicion_folio_pendiente_1`,`ciaecl_ciae`.`site_inscripcion`.`inicia_rendicion_folio_pendiente_2` AS `inicia_rendicion_folio_pendiente_2`,`ciaecl_ciae`.`site_inscripcion`.`inicia_rendicion_estado_asistencia` AS `inicia_rendicion_estado_asistencia`,`ciaecl_ciae`.`site_inscripcion`.`inicia_rendicion_pago_version` AS `inicia_rendicion_pago_version`,`ciaecl_ciae`.`site_inscripcion`.`inicia_rendicion_pago_monto` AS `inicia_rendicion_pago_monto`,`ciaecl_ciae`.`site_inscripcion`.`inicia_honorario_calidad` AS `inicia_honorario_calidad`,`ciaecl_ciae`.`site_inscripcion`.`inicia_honorario_agno` AS `inicia_honorario_agno`,`ciaecl_ciae`.`site_inscripcion`.`inicia_honorario_dia` AS `inicia_honorario_dia`,`ciaecl_ciae`.`site_inscripcion`.`inicia_honorario_mes` AS `inicia_honorario_mes`,`ciaecl_ciae`.`site_inscripcion`.`inicia_honorario_grado_academico` AS `inicia_honorario_grado_academico`,`ciaecl_ciae`.`site_inscripcion`.`inicia_honorario_grado_academico_institucion` AS `inicia_honorario_grado_academico_institucion`,`ciaecl_ciae`.`site_inscripcion`.`inicia_honorario_grado_academico_agno` AS `inicia_honorario_grado_academico_agno`,`ciaecl_ciae`.`site_inscripcion`.`inicia_honorario_grado_academico_mes` AS `inicia_honorario_grado_academico_mes`,`ciaecl_ciae`.`site_inscripcion`.`inicia_honorario_grado_academico_dia` AS `inicia_honorario_grado_academico_dia`,`ciaecl_ciae`.`site_inscripcion`.`inicia_honorario_institucion_publica` AS `inicia_honorario_institucion_publica`,`ciaecl_ciae`.`site_inscripcion`.`inicia_honorario_inst_publica_cargo` AS `inicia_honorario_inst_publica_cargo`,`ciaecl_ciae`.`site_inscripcion`.`inicia_honorario_tipo_contrato` AS `inicia_honorario_tipo_contrato`,`ciaecl_ciae`.`site_inscripcion`.`inicia_honorario_renta` AS `inicia_honorario_renta`,`ciaecl_ciae`.`site_inscripcion`.`inicia_honorario_honorario` AS `inicia_honorario_honorario`,`ciaecl_ciae`.`site_inscripcion`.`inicia_honorario_honorario_cargo` AS `inicia_honorario_honorario_cargo`,`ciaecl_ciae`.`site_inscripcion`.`inicia_honorario_honorario_periodo` AS `inicia_honorario_honorario_periodo`,`ciaecl_ciae`.`site_inscripcion`.`inicia_honorario_honorario_monto` AS `inicia_honorario_honorario_monto`,`ciaecl_ciae`.`site_inscripcion`.`inicia_honorario_nacionalidad` AS `inicia_honorario_nacionalidad`,`ciaecl_ciae`.`site_inscripcion`.`fecha` AS `fecha`,`ciaecl_ciae`.`site_inscripcion`.`preinscripcion` AS `preinscripcion`,`ciaecl_ciae`.`site_inscripcion`.`asistencia` AS `asistencia`,`ciaecl_ciae`.`site_inscripcion`.`activo` AS `activo`,`ciaecl_ciae`.`site_inscripcion`.`confirmacion` AS `confirmacion`,`ciaecl_ciae`.`site_inscripcion`.`egresado_diplomado` AS `egresado_diplomado`,`ciaecl_ciae`.`site_inscripcion`.`egresado_curso` AS `egresado_curso` from `ciaecl_ciae`.`site_inscripcion` order by `ciaecl_ciae`.`site_inscripcion`.`fecha_actualizacion` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_bases_datos_tipo`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_bases_datos_tipo` AS select `base_datos_email_tipo`.`tipo_base` AS `tipo_base`,count(`base_datos_email_tipo`.`tipo_base`) AS `total` from `base_datos_email_tipo` group by `base_datos_email_tipo`.`tipo_base` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_bases_inactivos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_bases_inactivos` AS select `base_datos_email`.`email` AS `email`,`base_datos_email`.`estado` AS `estado`,`base_datos_email`.`fecha_actualizacion` AS `fecha_actualizacion`,`base_datos_email`.`creacion_fecha` AS `creacion_fecha`,`base_datos_email`.`comentario` AS `comentario` from `base_datos_email` where (`base_datos_email`.`estado` like _latin1'inactivo') order by `base_datos_email`.`fecha_actualizacion` desc,`base_datos_email`.`email` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_bases_inactivos_nuevos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_bases_inactivos_nuevos` AS select `base_datos_email`.`email` AS `email`,`base_datos_email`.`fecha_actualizacion` AS `fecha_actualizacion`,`base_datos_email`.`creacion_fecha` AS `creacion_fecha`,`base_datos_email`.`comentario` AS `comentario` from `base_datos_email` where (`base_datos_email`.`comentario` like '%nuevo') order by `base_datos_email`.`email` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_bases_inactivos_suscripcion`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`ciaecl`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_bases_inactivos_suscripcion` AS select `view_bases_inactivos`.`email` AS `email`,`view_bases_inactivos`.`estado` AS `estado`,`view_bases_inactivos`.`fecha_actualizacion` AS `fecha_actualizacion`,`view_bases_inactivos`.`creacion_fecha` AS `creacion_fecha`,`view_bases_inactivos`.`comentario` AS `comentario` from `view_bases_inactivos` where (`view_bases_inactivos`.`comentario` like _latin1'%suscripcion') order by `view_bases_inactivos`.`fecha_actualizacion` desc,`view_bases_inactivos`.`email` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_bases_masivos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_bases_masivos` AS select count(`base_datos_email`.`grupo_masivo`) AS `total`,`base_datos_email`.`estado` AS `estado`,`base_datos_email`.`grupo_masivo` AS `grupo_masivo` from `base_datos_email` group by `base_datos_email`.`grupo_masivo`,`base_datos_email`.`estado` order by `base_datos_email`.`estado`,`base_datos_email`.`grupo_masivo` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_common_correos_enviados_con_rebote`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_common_correos_enviados_con_rebote` AS select count(`destino`.`email`) AS `total_enviados`,`detalle`.`caso_envio` AS `caso_envio`,`detalle`.`asunto` AS `asunto`,`detalle`.`tipo_remitente` AS `tipo_remitente`,`detalle`.`reply` AS `reply`,`detalle`.`contenido` AS `contenido`,`detalle`.`fecha_actualizacion` AS `fecha_actualizacion` from (`envio_email_destino` `destino` join `envio_email_detalle` `detalle`) where (convert(`destino`.`caso_envio` using utf8) = `detalle`.`caso_envio`) group by `detalle`.`caso_envio` order by `detalle`.`fecha_actualizacion` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_common_correos_enviados_no_rebote`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_common_correos_enviados_no_rebote` AS select count(`destino`.`email`) AS `total_enviados`,`detalle`.`caso_envio` AS `caso_envio`,`detalle`.`asunto` AS `asunto`,`detalle`.`tipo_remitente` AS `tipo_remitente`,`detalle`.`reply` AS `reply`,`detalle`.`contenido` AS `contenido`,`detalle`.`fecha_actualizacion` AS `fecha_actualizacion` from (`envio_email_destino` `destino` join `envio_email_detalle` `detalle`) where ((convert(`destino`.`caso_envio` using utf8) = `detalle`.`caso_envio`) and (`destino`.`estado` <> 'rebote')) group by `detalle`.`caso_envio` order by `detalle`.`fecha_actualizacion` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_common_logs_imagen`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_common_logs_imagen` AS select `ciaecl_backup`.`common_logs_imagen_2023`.`id_visita` AS `id_visita`,`ciaecl_backup`.`common_logs_imagen_2023`.`sitio` AS `sitio`,`ciaecl_backup`.`common_logs_imagen_2023`.`fecha` AS `fecha`,`ciaecl_backup`.`common_logs_imagen_2023`.`tipo_visita` AS `tipo_visita`,`ciaecl_backup`.`common_logs_imagen_2023`.`email` AS `email`,`ciaecl_backup`.`common_logs_imagen_2023`.`caso_envio` AS `caso_envio`,`ciaecl_backup`.`common_logs_imagen_2023`.`ip_address` AS `ip_address`,`ciaecl_backup`.`common_logs_imagen_2023`.`url` AS `url`,`ciaecl_backup`.`common_logs_imagen_2023`.`fecha_completa` AS `fecha_completa` from `ciaecl_backup`.`common_logs_imagen_2023` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_envio_caso_email`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_envio_caso_email` AS select `e`.`caso_envio` AS `caso_envio`,`e`.`caso_envio_md5` AS `caso_envio_md5`,`e`.`fecha_actualizacion` AS `fecha_actualizacion`,`e`.`tipo` AS `tipo`,`e`.`estado` AS `estado`,`e`.`orden_envio` AS `orden_envio`,`e`.`asunto` AS `asunto`,`e`.`tipo_remitente` AS `tipo_remitente`,`e`.`reply` AS `reply`,`e`.`cc_1` AS `cc_1`,`e`.`cc_2` AS `cc_2`,`e`.`bcc_1` AS `bcc_1`,`e`.`bcc_2` AS `bcc_2`,`e`.`contenido` AS `contenido`,`d`.`fecha_estado` AS `fecha_envio`,`d`.`email` AS `email`,`d`.`email_md5` AS `email_md5`,`d`.`estado` AS `estado_email`,`d`.`nombre` AS `nombre`,`d`.`apellidos` AS `apellidos` from (`envio_email_destino` `d` join `envio_email_detalle` `e`) where (convert(`d`.`caso_envio` using utf8) = `e`.`caso_envio`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_envio_caso_email_vista`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_envio_caso_email_vista` AS select distinct `a`.`asunto` AS `asunto`,`b`.`fecha_completa` AS `fecha_vista`,`a`.`fecha_envio` AS `fecha_envio`,`a`.`email` AS `email`,`a`.`email_md5` AS `email_md5`,`a`.`estado_email` AS `estado_email`,`a`.`nombre` AS `nombre`,`a`.`apellidos` AS `apellidos`,`a`.`caso_envio` AS `caso_envio`,`a`.`caso_envio_md5` AS `caso_envio_md5`,`a`.`tipo` AS `tipo`,`a`.`estado` AS `estado`,`a`.`orden_envio` AS `orden_envio` from (`ciaecl_correoweb`.`view_envio_caso_email` `a` join `ciaecl_ciae`.`common_logs_imagen` `b`) where ((convert(`b`.`email` using utf8) = convert(`a`.`email_md5` using utf8)) and (convert(`b`.`caso_envio` using utf8) = `a`.`caso_envio_md5`)) order by `b`.`fecha_completa` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_envio_contacto`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_envio_contacto` AS select `envio_email_destino`.`caso_envio` AS `caso_envio`,`envio_email_destino`.`fecha_estado` AS `fecha_estado`,`envio_email_destino`.`estado` AS `estado`,`envio_email_destino`.`email` AS `email`,`envio_email_destino`.`nombre` AS `nombre`,`envio_email_destino`.`apellidos` AS `apellidos`,`envio_email_destino`.`mensaje` AS `mensaje`,`envio_email_destino`.`remitente` AS `remitente` from `envio_email_destino` where ((`envio_email_destino`.`caso_envio` like '%contacto%') and (`envio_email_destino`.`estado` = 'no_enviado')) order by `envio_email_destino`.`estado`,`envio_email_destino`.`fecha_estado` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_envio_destino_activos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_envio_destino_activos` AS select distinct `envio_email_destino`.`caso_envio` AS `caso_envio`,`envio_email_destino`.`email` AS `email`,`envio_email_destino`.`estado` AS `estado`,`envio_email_destino`.`nombre` AS `nombre`,`envio_email_destino`.`apellidos` AS `apellidos`,`envio_email_destino`.`tratamiento` AS `tratamiento`,`envio_email_destino`.`fecha_estado` AS `fecha_estado` from `envio_email_destino` where ((`envio_email_destino`.`estado` <> 'rebote') and (not((`envio_email_destino`.`email` like '%@ciae.uchile.cl')))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_envio_detalle_informe`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_envio_detalle_informe` AS select `ei`.`id_evento` AS `id_evento`,`ei`.`id_noticia` AS `id_noticia`,`ei`.`fecha_inicio` AS `fecha_inicio`,`ei`.`fecha_termino` AS `fecha_termino`,`ei`.`info_completa` AS `info_completa`,`ei`.`nombre` AS `nombre`,`ei`.`tipo_evento` AS `tipo_evento`,`ei`.`total_inscritos_presencial` AS `total_inscritos_presencial`,`ei`.`total_inscritos_online` AS `total_inscritos_online`,`ei`.`total_asistencia` AS `total_asistencia`,`ei`.`institucion_co_organizadora` AS `institucion_co_organizadora`,`ei`.`link_inscripcion` AS `link_inscripcion`,`ei`.`id_inscripcion` AS `id_inscripcion`,`ei`.`inscripcion_opcion_menu` AS `inscripcion_opcion_menu`,`ei`.`inscripcion_fecha_cierre` AS `inscripcion_fecha_cierre`,`ei`.`inscripcion_cupos_maximo` AS `inscripcion_cupos_maximo`,`ei`.`email` AS `email`,`ei`.`ubicacion` AS `ubicacion`,`ei`.`ubicacion_email` AS `ubicacion_email`,`ei`.`ubicacion_email_online` AS `ubicacion_email_online`,`ei`.`date_texto` AS `date_texto`,`ei`.`date_texto_email` AS `date_texto_email`,`ei`.`programa` AS `programa`,`ei`.`costo_texto_extras` AS `costo_texto_extras`,`ei`.`listas` AS `listas`,`ei`.`logos` AS `logos`,`ei`.`tipo_formulario_confirmacion` AS `tipo_formulario_confirmacion`,`ei`.`mensaje_extra_notificacion` AS `mensaje_extra_notificacion`,`ei`.`link_online` AS `link_online`,`ei`.`certificado_encabezado_fech` AS `certificado_encabezado_fech`,`ei`.`certificado_fec` AS `certificado_fec`,`ei`.`certificado_horas` AS `certificado_horas`,`ei`.`certificado_ubicacion` AS `certificado_ubicacion`,`ei`.`certificado_organizadores` AS `certificado_organizadores`,`de`.`caso_envio` AS `caso_envio`,`de`.`fecha_actualizacion` AS `fecha_actualizacion`,`de`.`estado` AS `estado`,`de`.`orden_envio` AS `orden_envio`,`de`.`asunto` AS `asunto`,`de`.`tipo_remitente` AS `tipo_remitente`,`de`.`reply` AS `reply`,`de`.`cc_1` AS `cc_1`,`de`.`cc_2` AS `cc_2`,`de`.`bcc_1` AS `bcc_1`,`de`.`bcc_2` AS `bcc_2`,`de`.`contenido` AS `contenido` from ((`ciaecl_correoweb`.`envio_email_detalle` `de` join `ciaecl_correoweb`.`envio_email_destino_inscripciones` `di`) join `ciaecl_ciae`.`view_site_eventos_informe` `ei`) where ((`di`.`caso_envio` = `de`.`caso_envio`) and (`di`.`tipo_inscripcion` = convert(`ei`.`id_inscripcion` using utf8))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_envio_estados`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_envio_estados` AS select `envio_email_destino`.`caso_envio` AS `caso_envio`,`envio_email_destino`.`estado` AS `estado`,count(0) AS `total` from `envio_email_destino` group by `envio_email_destino`.`caso_envio`,`envio_email_destino`.`estado` order by `envio_email_destino`.`caso_envio` desc,`envio_email_destino`.`estado` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_envio_estados_no_enviados`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_envio_estados_no_enviados` AS select `a`.`caso_envio` AS `caso_envio`,count(`a`.`caso_envio`) AS `total_no_enviado`,`a`.`estado` AS `estado_caso`,`a`.`orden_envio` AS `orden_envio` from (select `a`.`caso_envio` AS `caso_envio`,`a`.`caso_envio_md5` AS `caso_envio_md5`,`a`.`fecha_actualizacion` AS `fecha_actualizacion`,`a`.`tipo` AS `tipo`,`a`.`estado` AS `estado`,`a`.`orden_envio` AS `orden_envio`,`a`.`asunto` AS `asunto`,`a`.`tipo_remitente` AS `tipo_remitente`,`a`.`reply` AS `reply`,`a`.`cc_1` AS `cc_1`,`a`.`cc_2` AS `cc_2`,`a`.`bcc_1` AS `bcc_1`,`a`.`bcc_2` AS `bcc_2`,`a`.`contenido` AS `contenido`,`b`.`email` AS `email` from (`ciaecl_correoweb`.`envio_email_destino` `b` join `ciaecl_correoweb`.`envio_email_detalle` `a`) where ((`a`.`caso_envio` = convert(`b`.`caso_envio` using utf8)) and (`a`.`estado` = 'activo') and (`b`.`estado` = 'no_enviado')) order by `a`.`orden_envio`) `a` group by `a`.`caso_envio` order by `a`.`orden_envio`,`a`.`caso_envio` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_envio_estados_no_enviados_inactivos`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_envio_estados_no_enviados_inactivos` AS select `b`.`caso_envio` AS `caso_envio`,`b`.`email` AS `email`,`b`.`estado` AS `estado_envio`,`b`.`email_md5` AS `email_md5`,`o`.`estado` AS `estado_email`,`b`.`nombre` AS `nombre`,`b`.`apellidos` AS `apellidos`,`o`.`comentario` AS `comentario` from ((`envio_email_destino` `b` join `envio_email_detalle` `a`) join `base_datos_email` `o`) where ((`a`.`caso_envio` = convert(`b`.`caso_envio` using utf8)) and (`a`.`estado` = 'activo') and (`o`.`email` = `b`.`email`) and (`o`.`estado` = 'inactivo') and (`b`.`estado` = 'no_enviado')) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_envio_estados_no_enviados_total`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_envio_estados_no_enviados_total` AS select sum(`view_envio_estados_no_enviados`.`total_no_enviado`) AS `total_no_enviados` from `ciaecl_correoweb`.`view_envio_estados_no_enviados` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!50001 DROP VIEW IF EXISTS `view_envio_remitentes`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_unicode_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_envio_remitentes` AS select `envio_email_destino`.`remitente` AS `remitente`,count(`envio_email_destino`.`remitente`) AS `total` from `envio_email_destino` where (`envio_email_destino`.`remitente` like '%@%') group by `envio_email_destino`.`remitente` order by `total` desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

